import { StructuredPanel, ActionButton } from "../../../lib/components/structured-panel";

// Re-export both components for backward compatibility
export const Pane = StructuredPanel;
export { ActionButton };

// TODO: Delete this file once all the files are updated to use StructuredPanel