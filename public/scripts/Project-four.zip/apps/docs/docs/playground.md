## Try an example chat in the playground

### Chat with the assistant

The playground is intended to test out the assistant as you build it. The User and Assistant messages represent the conversation that your end-user will have if your assistant is deployed in production. The playground also has debug elements which show the flow of control between different agents in your system, as well as which agent finally responded to the user.

![Try Chat](img/chat-delivery.png)