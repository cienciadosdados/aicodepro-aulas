from flask import Flask, request, jsonify
import os
import requests
from datetime import datetime

app = Flask(__name__)

# Definição das ferramentas disponíveis
@app.route('/tools', methods=['GET'])
def list_tools():
    return jsonify({
        "tools": [
            {
                "name": "get_weather",
                "description": "Obtém a previsão do tempo para uma localização",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {
                            "type": "string",
                            "description": "A localização para obter a previsão do tempo"
                        }
                    },
                    "required": ["location"]
                }
            },
            {
                "name": "get_time",
                "description": "Obtém a hora atual em um formato específico",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "format": {
                            "type": "string",
                            "description": "Formato da hora (default, iso, ou custom)"
                        }
                    },
                    "required": []
                }
            }
        ]
    })

# Implementação da ferramenta de clima
@app.route('/tools/get_weather', methods=['POST'])
def get_weather():
    data = request.json
    location = data.get('location', '')
    
    # Simulação de dados de clima - em produção você usaria uma API real
    weather_data = {
        "São Paulo": {"temperature": "24°C", "condition": "Parcialmente nublado"},
        "Rio de Janeiro": {"temperature": "30°C", "condition": "Ensolarado"},
        "Brasília": {"temperature": "22°C", "condition": "Céu limpo"},
        "Salvador": {"temperature": "28°C", "condition": "Chuvoso"}
    }
    
    # Retorna dados do local solicitado ou uma mensagem padrão
    if location in weather_data:
        result = weather_data[location]
        result["location"] = location
    else:
        result = {
            "temperature": "25°C", 
            "condition": "Informação não disponível para localização específica",
            "location": location
        }
    
    return jsonify(result)

# Implementação da ferramenta de hora
@app.route('/tools/get_time', methods=['POST'])
def get_time():
    data = request.json
    time_format = data.get('format', 'default')
    
    now = datetime.now()
    
    if time_format == 'iso':
        formatted_time = now.isoformat()
    elif time_format == 'custom':
        formatted_time = now.strftime("%d/%m/%Y %H:%M:%S")
    else:  # default
        formatted_time = now.strftime("%H:%M:%S")
    
    return jsonify({
        "current_time": formatted_time,
        "format": time_format
    })

# Rota para verificação de saúde do servidor
@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy", "server": "MCP Example Server"})

if __name__ == '__main__':
    # Executar o servidor na porta 5000
    print("Iniciando servidor MCP na porta 5000...")
    app.run(host='0.0.0.0', port=5000, debug=True)
