import os
from openai import OpenAI

# Obter a chave da API do arquivo .env
with open('.env', 'r') as f:
    for line in f:
        if line.startswith('OPENAI_API_KEY='):
            api_key = line.strip().split('=', 1)[1]
            if api_key.startswith('"') and api_key.endswith('"'):
                api_key = api_key[1:-1]
            break

print(f"Chave da API encontrada: {api_key[:10]}...{api_key[-5:]}")

# Inicializar o cliente OpenAI
client = OpenAI(api_key=api_key)

# Testar a chave com uma solicitação simples
try:
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "Você é um assistente útil."},
            {"role": "user", "content": "Diga olá!"}
        ]
    )
    print("Teste bem-sucedido! Resposta da API:")
    print(response.choices[0].message.content)
    print("\nA chave da API é válida e está funcionando corretamente.")
except Exception as e:
    print(f"Erro ao testar a chave da API: {e}")
