import os
from dotenv import load_dotenv
import requests

load_dotenv(override=True)

api_key = os.environ.get('OPENAI_API_KEY')

print("=== Verificação da OpenAI API Key ===\n")
print(f"API Key: {api_key[:20]}...{api_key[-10:]}\n")

# Testar a API key fazendo uma chamada simples
headers = {
    'Authorization': f'Bearer {api_key}',
    'Content-Type': 'application/json'
}

print("Testando API key...\n")

# 1. Verificar se a key é válida (listar modelos)
try:
    response = requests.get(
        'https://api.openai.com/v1/models',
        headers=headers,
        timeout=10
    )
    
    if response.status_code == 200:
        print("✅ API Key VÁLIDA!")
        models = response.json()
        print(f"   Total de modelos disponíveis: {len(models.get('data', []))}")
        
        # Verificar se tem acesso aos modelos necessários
        model_ids = [m['id'] for m in models.get('data', [])]
        
        required_models = ['gpt-4o-realtime-preview', 'text-embedding-3-small', 'whisper-1']
        print("\n📋 Modelos necessários:")
        for model in required_models:
            # Verificar se o modelo ou variações dele existem
            has_model = any(model in m for m in model_ids)
            status = "✅" if has_model else "❌"
            print(f"   {status} {model}")
            
    elif response.status_code == 401:
        print("❌ API Key INVÁLIDA!")
        error_data = response.json()
        print(f"\nErro: {error_data.get('error', {}).get('message', 'Desconhecido')}")
        print("\n💡 Possíveis causas:")
        print("   1. API key expirada ou revogada")
        print("   2. API key copiada incorretamente")
        print("   3. Projeto da API key foi deletado")
        print("\n🔧 Solução:")
        print("   - Gere uma nova API key em: https://platform.openai.com/api-keys")
        
    elif response.status_code == 429:
        print("⚠️  Rate limit atingido ou sem créditos!")
        print("\n💡 Verifique:")
        print("   - Saldo em: https://platform.openai.com/usage")
        print("   - Limites em: https://platform.openai.com/account/limits")
        
    else:
        print(f"⚠️  Erro inesperado: {response.status_code}")
        print(f"   Resposta: {response.text}")
        
except requests.exceptions.RequestException as e:
    print(f"❌ Erro de conexão: {e}")
    print("\n💡 Verifique sua conexão com a internet")

# 2. Tentar verificar billing (pode não funcionar com todas as keys)
print("\n=== Verificando Informações de Billing ===\n")
try:
    billing_response = requests.get(
        'https://api.openai.com/v1/dashboard/billing/subscription',
        headers=headers,
        timeout=10
    )
    
    if billing_response.status_code == 200:
        billing_data = billing_response.json()
        print("✅ Informações de billing acessíveis")
        print(f"   Dados: {billing_data}")
    else:
        print("⚠️  Não foi possível acessar informações de billing")
        print("   (Isso é normal para algumas API keys)")
        
except Exception as e:
    print(f"⚠️  Erro ao verificar billing: {e}")

print("\n" + "="*50)
print("\n🔗 Links úteis:")
print("   • API Keys: https://platform.openai.com/api-keys")
print("   • Usage: https://platform.openai.com/usage")
print("   • Billing: https://platform.openai.com/account/billing/overview")
