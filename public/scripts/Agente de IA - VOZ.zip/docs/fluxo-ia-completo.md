# Fluxo Completo de IA - Voice Agent

## Diagrama de Arquitetura com Modelos de IA

```mermaid
graph TB
    subgraph "Frontend - Navegador"
        A[👤 Usuário Fala]
        B[🎙️ Audio Worklet Processor]
        C[📡 WebSocket Client]
        Z[🔊 Audio Worklet Playback]
        AA[👤 Usuário Escuta]
    end

    subgraph "Backend - Python/Starlette"
        D[⚡ Starlette WebSocket Server]
        E[🤖 OpenAI Voice React Agent]
    end

    subgraph "OpenAI Realtime API - WebSocket"
        F[🎯 GPT-4o Realtime]
        G[🎤 Whisper-1<br/>Speech-to-Text]
        H[🔊 TTS Model<br/>Text-to-Speech]
        I[🧠 Function Calling<br/>Tool Decision]
    end

    subgraph "LangChain Tools"
        J[🔍 rentlas_search_tool]
        K[📝 create_booking]
        L[👤 get_booking_by_name]
    end

    subgraph "OpenAI Embeddings API"
        M[🔢 text-embedding-3-small<br/>1536 dimensões]
    end

    subgraph "MongoDB Atlas"
        N[(🗄️ Rentals Collection<br/>Embeddings Pré-calculados)]
        O[(📋 Bookings Collection)]
        P[🔍 Vector Search Index<br/>Cosine Similarity]
    end

    %% Fluxo de Entrada - Voz para Processamento
    A -->|Áudio Raw| B
    B -->|Float32 → Int16| C
    C -->|WebSocket| D
    D -->|Stream| E
    E -->|Audio Stream| F
    
    %% Processamento OpenAI Realtime
    F -->|1. Transcrição| G
    G -->|Texto: "casa na praia"| I
    I -->|2. Decide Tool| J
    
    %% Busca Vetorial
    J -->|Query Text| M
    M -->|Vetor [1536d]| P
    P -->|Similarity Search| N
    N -->|Top 5 Resultados| J
    
    %% Outras Tools
    I -.->|Se criar reserva| K
    K -.->|Insert| O
    I -.->|Se buscar reserva| L
    L -.->|Fuzzy Search| O
    O -.->|Resultado| L
    
    %% Retorno das Tools
    J -->|Resultados| I
    K -.->|Confirmação| I
    L -.->|Dados Reserva| I
    
    %% Geração de Resposta
    I -->|3. Gera Resposta| F
    F -->|Texto Resposta| H
    H -->|4. Síntese Áudio| E
    
    %% Fluxo de Saída - Áudio para Usuário
    E -->|Audio Stream| D
    D -->|WebSocket| C
    C -->|Int16 → Float32| Z
    Z -->|Áudio Raw| AA

    %% Estilos
    style F fill:#ff6b6b,stroke:#c92a2a,stroke-width:3px,color:#fff
    style G fill:#4dabf7,stroke:#1971c2,stroke-width:2px,color:#fff
    style H fill:#4dabf7,stroke:#1971c2,stroke-width:2px,color:#fff
    style M fill:#51cf66,stroke:#2f9e44,stroke-width:2px,color:#fff
    style I fill:#ff6b6b,stroke:#c92a2a,stroke-width:2px,color:#fff
    style P fill:#ffd43b,stroke:#f59f00,stroke-width:2px,color:#000
    style N fill:#e7f5ff,stroke:#339af0,stroke-width:2px
    style O fill:#e7f5ff,stroke:#339af0,stroke-width:2px
    style J fill:#d0bfff,stroke:#7950f2,stroke-width:2px
    style K fill:#d0bfff,stroke:#7950f2,stroke-width:2px
    style L fill:#d0bfff,stroke:#7950f2,stroke-width:2px
```

## Legenda dos Modelos de IA

### 🔴 Modelos OpenAI Realtime (Integrados)
- **GPT-4o Realtime**: Modelo principal multimodal
- **Whisper-1**: Transcrição de áudio para texto (STT)
- **TTS**: Síntese de texto para áudio (TTS)

### 🟢 Modelo OpenAI Embeddings (Separado)
- **text-embedding-3-small**: Converte texto em vetores de 1536 dimensões

### 🟣 LangChain Tools (Lógica de Negócio)
- **rentlas_search_tool**: Busca semântica usando Vector Search
- **create_booking**: Cria reservas no MongoDB
- **get_booking_by_name**: Busca reservas por nome

### 🟡 MongoDB Vector Search (Busca Inteligente)
- Índice vetorial com similaridade cosine
- Compara embeddings em tempo real

---

## Fluxo Detalhado por Etapa

### 📥 Etapa 1: Captura de Voz
```
Usuário fala → Audio Worklet → WebSocket → Servidor
```

### 🎤 Etapa 2: Transcrição (Whisper-1)
```
Áudio → Whisper-1 → Texto: "Quero uma casa na praia"
```

### 🧠 Etapa 3: Decisão de Tool (GPT-4o Realtime)
```
GPT-4o analisa → Decide chamar rentlas_search_tool
```

### 🔢 Etapa 4: Conversão para Vetor (text-embedding-3-small)
```
"casa na praia" → text-embedding-3-small → [0.123, -0.456, ..., 0.789]
                                            (1536 números)
```

### 🔍 Etapa 5: Busca Vetorial (MongoDB Vector Search)
```
Vetor query → Compara com embeddings armazenados → Top 5 resultados
```

### 💬 Etapa 6: Geração de Resposta (GPT-4o Realtime)
```
Resultados → GPT-4o formata → "Encontrei 3 casas na praia..."
```

### 🔊 Etapa 7: Síntese de Voz (TTS)
```
Texto resposta → TTS → Áudio
```

### 📤 Etapa 8: Reprodução
```
Áudio → WebSocket → Audio Worklet → Alto-falante → Usuário escuta
```

---

## Comparação: Onde Cada IA Atua

| Componente IA | Entrada | Saída | Quando Executa |
|---------------|---------|-------|----------------|
| **Whisper-1** | Áudio | Texto | Toda interação de voz |
| **GPT-4o Realtime** | Texto + Contexto | Decisão + Texto | Toda interação |
| **text-embedding-3-small** | Query texto | Vetor [1536d] | Apenas em buscas |
| **TTS** | Texto | Áudio | Toda resposta |
| **Vector Search** | Vetor query | Documentos similares | Apenas em buscas |

---

## Observações Importantes

### ⚡ OpenAI Realtime API = Pipeline Integrado
- Whisper, GPT-4o e TTS trabalham juntos em um único WebSocket
- Não precisa chamar APIs separadas
- Latência mínima entre os modelos

### 🔢 text-embedding-3-small = Único Modelo "Externo"
- Chamado apenas quando a tool `rentlas_search_tool` é executada
- Não faz parte do Realtime API
- Usado exclusivamente para busca semântica

### 🗄️ MongoDB = Armazenamento + Busca Inteligente
- Armazena embeddings pré-calculados (do dataset)
- Executa busca de similaridade cosine
- Retorna resultados ranqueados por relevância
