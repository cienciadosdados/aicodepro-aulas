# Como Funcionam os Audio Worklets - Explicação para Leigos

## O que são Audio Worklets?

Imagine que você tem um sistema de som muito sofisticado que precisa processar áudio em tempo real, sem travamentos ou atrasos. Os **Audio Worklets** são como "funcionários especializados" que trabalham nos bastidores do navegador, dedicados exclusivamente a processar áudio de forma super eficiente.

## Os Dois "Funcionários" do Sistema

Na pasta `static` temos dois arquivos JavaScript que representam dois tipos diferentes de "funcionários" especializados:

### 1. 📤 Audio Processor Worklet (`audio-processor-worklet.js`)
**Função:** Capturar e converter áudio do microfone

#### O que ele faz (em linguagem simples):

**Imagine um tradutor simultâneo:**
- Você fala no microfone em "português" (formato Float32)
- Ele traduz instantaneamente para "inglês" (formato Int16) 
- Envia a tradução para quem precisa processar

**Como funciona tecnicamente:**

1. **Captura o som:** Recebe o áudio que vem do seu microfone
2. **Converte o formato:** Transforma de Float32 (números decimais) para Int16 (números inteiros)
   - Float32: números como 0.5, -0.8, 1.2
   - Int16: números como 16384, -26214, 32767
3. **Envia os dados:** Manda o áudio convertido para o servidor processar

**Controles disponíveis:**
- `stop`: Para de processar áudio
- `resume`: Volta a processar áudio

### 2. 🔊 Audio Playback Worklet (`audio-playback-worklet.js`)
**Função:** Reproduzir áudio recebido do servidor

#### O que ele faz (em linguagem simples):

**Imagine um DJ profissional:**
- Recebe músicas (dados de áudio) de várias fontes
- Organiza tudo numa playlist (buffer)
- Toca as músicas na ordem certa, sem cortes ou falhas

**Como funciona tecnicamente:**

1. **Recebe dados:** Pega os dados de áudio que chegam do servidor
2. **Organiza numa fila:** Coloca tudo num "buffer" (como uma playlist)
3. **Reproduz suavemente:** Toca o áudio de forma contínua, sem travamentos
4. **Converte o formato:** Transforma Int16 de volta para Float32 para o alto-falante

**Controles disponíveis:**
- `null`: Para tudo e limpa a fila
- `resume`: Volta a tocar
- Recebe dados: Adiciona novo áudio na fila

## Como os Dois Trabalham Juntos

```
[Microfone] → [Audio Processor] → [Servidor] → [Audio Playback] → [Alto-falante]
     ↓              ↓                ↓              ↓              ↓
  Sua voz      Converte para     Processa      Converte de     Você escuta
              formato Int16      a voz        volta Float32    a resposta
```

## Por Que Usar Worklets?

### Vantagens:

1. **Performance:** Processam áudio em thread separada, sem travar a página
2. **Tempo Real:** Latência muito baixa (sem atrasos perceptíveis)
3. **Controle Fino:** Permitem manipular cada amostra de áudio individualmente
4. **Estabilidade:** Não são afetados por outras operações da página

### Analogia do Restaurante:

- **Página Web = Salão do restaurante** (onde clientes interagem)
- **Audio Worklets = Cozinha** (onde o trabalho pesado acontece)
- **Main Thread = Garçom** (leva pedidos e traz pratos)

Assim como a cozinha trabalha independente do salão, os worklets processam áudio sem afetar a interface da página.

## Detalhes Técnicos Importantes

### Conversão de Formatos:

**Float32 → Int16 (Processor):**
```javascript
// Multiplica por 32767 e converte para inteiro
val = Math.floor(float32Value * 32767)
```

**Int16 → Float32 (Playback):**
```javascript
// Divide por 32768 para voltar ao formato original
floatValue = intValue / 32768
```

### Buffer Management:

O **Audio Playback** usa um sistema inteligente de buffer:
- Se tem mais dados que o necessário: usa só o que precisa
- Se tem menos dados: usa tudo e espera mais chegar
- Se não está tocando: enche com silêncio (zeros)

## Casos de Uso

Este sistema é ideal para:
- 🎙️ **Assistentes de voz** (como este projeto)
- 📞 **Chamadas de voz em tempo real**
- 🎵 **Aplicações de música online**
- 🎮 **Jogos com chat de voz**
- 📻 **Streaming de áudio**

## Resumo Final

Os dois worklets formam um sistema completo de áudio bidirecional:

- **Processor:** "Ouve" você e prepara sua voz para envio
- **Playback:** "Fala" com você reproduzindo as respostas

Juntos, eles criam uma experiência de conversação natural e fluida, como se você estivesse falando com uma pessoa real, mas na verdade está interagindo com uma inteligência artificial através do navegador.
---

## 🗄️ Banco de Dados e Busca Vetorial

### MongoDB Atlas - O Cérebro do Sistema

Este projeto utiliza o **MongoDB Atlas** como banco de dados principal, mas não é um banco comum - ele tem superpoderes!

#### Serviços MongoDB Utilizados:

**1. 📊 MongoDB Atlas (Banco Principal)**
- **Função:** Armazena dados estruturados (reservas, informações de usuários)
- **Localização:** Nuvem (Atlas)
- **Collections utilizadas:**
  - `ai_airbnb.rentals` - Propriedades para aluguel
  - `ai_airbnb.bookings` - Reservas dos usuários

**2. 🔍 MongoDB Atlas Vector Search (Busca Inteligente)**
- **Função:** Busca semântica usando embeddings
- **É o banco vetorial:** SIM! O Vector Search é a funcionalidade de banco vetorial
- **Como funciona:** Converte texto em vetores matemáticos para busca por similaridade

### Como Funciona a Busca Vetorial

#### Processo Detalhado - Quando Acontece a Conversão:

**🔄 Fluxo Completo com Momentos Exatos:**

```
1. [Usuário fala] → "Quero uma casa na praia"
2. [Audio Worklet] → Converte voz para texto
3. [OpenAI Realtime] → Entende a intenção e chama ferramenta
4. [rentlas_search_tool] → Recebe query: "casa na praia"
5. 🎯 AQUI ACONTECE: OpenAI Embeddings converte "casa na praia" → [0.1, 0.8, -0.3...]
6. [Vector Search] → Busca vetores similares no MongoDB
7. [Retorna resultados] → Propriedades encontradas
```

**📍 Momento Exato da Conversão (Linha 62 do tools.py):**

```python
# tools.py - linha 62
vector_search_results = vector_store.similarity_search_with_score(query=query, k=k)
```

**O que acontece internamente nesta linha:**

1. **Recebe a query:** `"casa na praia"` (texto puro)
2. **Chama OpenAI Embeddings:** Automaticamente converte o texto
3. **Gera vetor:** `[0.1234, -0.5678, 0.9012, ...]` (1536 dimensões)
4. **Busca no MongoDB:** Compara com vetores armazenados
5. **Retorna resultados:** Com scores de similaridade

**🔍 Processo Simplificado Visual:**

```
[Pergunta] → [Ferramenta] → [Embedding] → [Vector Search] → [Resultados]
     ↓            ↓            ↓              ↓              ↓
"Casa na     rentlas_    OpenAI converte   MongoDB busca   "Beach House"
 praia"      search_tool  para vetor       similaridades   + score: 0.85
```

#### Detalhes Técnicos:

**1. Modelo de Embeddings:**
- **Modelo usado:** `text-embedding-3-small` (OpenAI)
- **Função:** Converte texto em vetores de 1536 dimensões

**2. Configuração do Vector Search:**
```javascript
// Configuração no código
namespace: "ai_airbnb.rentals"
embedding_key: "text_embeddings"  // Campo onde ficam os vetores
text_key: "description"           // Campo de texto original
index_name: "vector_index"        // Nome do índice vetorial
```

**3. Tipos de Busca Disponíveis:**

**Busca Vetorial (Semântica):**
- Entende o **significado** das palavras
- Exemplo: "casa na praia" encontra "villa oceânica"
- Usa: `similarity_search_with_score()`

**Busca Textual (Tradicional):**
- Busca por **palavras exatas**
- Exemplo: busca por nome específico
- Usa: `$search` com `fuzzy` matching

### Fluxo Completo do Sistema

```
[Usuário fala] → [Audio Worklets] → [OpenAI Realtime] → [Ferramentas] → [MongoDB]
      ↓               ↓                    ↓                ↓            ↓
   "Quero uma     Converte para      Processa a         Busca no     Retorna
   casa na praia"    texto           linguagem         Vector DB     resultados
```

### Ferramentas Disponíveis

**1. 🔍 `rentlas_search_tool`**
- Busca propriedades usando Vector Search
- Retorna até 5 resultados mais similares
- Inclui score de similaridade

**2. 📝 `create_booking`**
- Cria nova reserva no MongoDB
- Valida dados usando Pydantic
- Adiciona timestamp automático

**3. 👤 `get_booking_by_name`**
- Busca reservas por nome
- Usa busca textual com fuzzy matching
- Suporta nomes aproximados

### Por Que Vector Search?

**Vantagens sobre busca tradicional:**

1. **Entende contexto:** "casa luxuosa" encontra "villa premium"
2. **Multilíngue:** Funciona em diferentes idiomas
3. **Tolerante a erros:** Encontra resultados mesmo com typos
4. **Busca semântica:** Entende sinônimos e conceitos relacionados

### Configuração Necessária

**Variáveis de ambiente (.env):**
```
OPENAI_API_KEY=sua_chave_openai
MONGODB_ATLAS_URI=sua_conexao_mongodb_atlas
```

**Índice Vector Search no MongoDB Atlas:**
- Deve ser criado manualmente no painel do Atlas
- Nome: `vector_index`
- Campo: `text_embeddings`
- Dimensões: 1536 (para text-embedding-3-small)

### Resumo da Arquitetura

O sistema combina:
- **Audio Worklets:** Interface de voz
- **OpenAI Realtime:** Processamento de linguagem
- **MongoDB Atlas:** Armazenamento de dados
- **Vector Search:** Busca inteligente
- **OpenAI Embeddings:** Conversão texto→vetor

Resultado: Um assistente de voz que entende suas perguntas e encontra informações relevantes usando busca semântica avançada!
### ⚡ Quando NÃO Acontece a Conversão

**Importante:** A conversão texto→vetor **NÃO acontece** em:

- ❌ **Audio Worklets:** Só processam áudio
- ❌ **OpenAI Realtime:** Só processa linguagem natural
- ❌ **create_booking:** Só salva dados estruturados
- ❌ **get_booking_by_name:** Usa busca textual tradicional

**✅ SÓ acontece quando:**
- A ferramenta `rentlas_search_tool` é chamada
- Especificamente na linha `similarity_search_with_score()`
- Para converter a query de busca em vetor

### 🕐 Timeline Completa do Sistema

```
Tempo | Ação                    | Onde acontece
------|-------------------------|------------------
T1    | Usuário fala           | Microfone
T2    | Voz → Texto            | Audio Worklets
T3    | Entende intenção       | OpenAI Realtime
T4    | Chama ferramenta       | OpenAI Realtime
T5    | 🎯 Texto → Vetor       | OpenAI Embeddings (automático)
T6    | Busca similaridade     | MongoDB Vector Search
T7    | Retorna resultados     | MongoDB → OpenAI
T8    | Resposta em voz        | OpenAI → Audio Worklets
```

**Resultado:** Um assistente de voz que entende suas perguntas e encontra informações relevantes usando busca semântica avançada, onde a conversão para vetor acontece automaticamente e apenas quando uma busca vetorial é solicitada!