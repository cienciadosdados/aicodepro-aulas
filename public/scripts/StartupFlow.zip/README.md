# StartupFlow Multi Agents - Sistema Inteligente de Validação de Startups
https://github.com/cienciadosdados/startupflow/blob/main/README.md


![Logo do Projeto](https://i.imgur.com/1QgrNNf.png)

## 📋 Índice

- [Sobre o Projeto](#sobre-o-projeto)
- [Arquitetura do Sistema](#arquitetura-do-sistema)
- [Requisitos](#requisitos)
- [Configuração Passo a Passo](#configuração-passo-a-passo)
- [Como Executar](#como-executar)
- [Componentes Detalhados](#componentes-detalhados)
- [Solução de Problemas](#solução-de-problemas)
- [Exemplos de Uso](#exemplos-de-uso)
- [FAQ](#faq)

## 📖 Sobre o Projeto

O StartupFlow Multi Agents é um sistema inteligente de validação de startups que utiliza múltiplos agentes de IA especializados trabalhando em conjunto para automatizar a análise e validação de ideias de negócio. O sistema é capaz de:

- **Classificar startups** por vertical de mercado (FinTech, EdTech, HealthTech, E-commerce, SaaS, Marketplace, Gaming, Social)
- **Avaliar potencial** (Alto, Médio, Baixo)
- **Realizar análise de mercado** detalhada com competidores e oportunidades
- **Criar plano de execução** com estratégias e roadmap de desenvolvimento
- **Gerar business plan** completo com pitch deck em formato Markdown e HTML

Os agentes trabalham de forma colaborativa, como uma equipe real de consultores de negócios, para validar e analisar startups com eficiência e precisão, permitindo que empreendedores e investidores tomem decisões mais assertivas.

## 🏗️ Arquitetura do Sistema

### Diagrama de Fluxo

```
┌─────────────────┐     ┌──────────────────────────────────────────────────────┐
│                 │     │                                                      │
│  Banco de Dados │◄────┤                  Sistema de Agentes                  │
│   (Neon DB)     │     │                                                      │
│                 │     │  ┌─────────┐   ┌─────────┐   ┌─────────┐   ┌─────┐  │
└────────┬────────┘     │  │         │   │         │   │         │   │     │  │
         │              │  │  AG1:   │   │  AG2:   │   │  AG3:   │   │     │  │
         │              │  │ Classi- │   │ Avalia- │   │ Análise │   │ ... │  │
         │              │  │ ficador │──►│ dor de  │──►│ de      │──►│     │  │
         │              │  │Vertical │   │Potencial│   │Mercado  │   │     │  │
┌────────▼────────┐     │  │         │   │         │   │         │   │     │  │
│                 │     │  └─────────┘   └─────────┘   └─────────┘   └─────┘  │
│    Pinecone     │◄────┤                                                      │
│ (Vector Store)  │     └──────────────────────────────────────────────────────┘
│                 │
└─────────────────┘
```

### Fluxo de Processamento

1. O sistema obtém ideias de startup submetidas do banco de dados Neon
2. Cada startup passa por uma sequência de agentes especializados:
   - **AG1**: Classifica a startup por vertical de mercado (FinTech, EdTech, HealthTech, etc.)
   - **AG2**: Avalia o potencial de sucesso da startup (Alto, Médio, Baixo)
   - **AG3**: Realiza análise de mercado detalhada com competidores e oportunidades
   - **AG4**: Cria estratégia de execução e roadmap de desenvolvimento
   - **AG5**: Gera business plan completo e pitch deck
3. Os resultados de cada etapa são armazenados no banco de dados
4. Os vetores de embeddings são armazenados no Pinecone para busca semântica de startups similares

## 🛠️ Requisitos

### Serviços Externos

- Conta na [OpenAI](https://platform.openai.com) (para acesso aos modelos GPT)
- Conta no [Neon DB](https://neon.tech) (banco de dados PostgreSQL serverless)
- Conta no [Pinecone](https://www.pinecone.io) (armazenamento de vetores)

### Requisitos Técnicos

- Python 3.9+
- Ambiente virtual (venv)
- Dependências listadas em `requirements.txt`

## 🚀 Configuração Passo a Passo

### 1. Preparação do Ambiente Local


```

#### 1.2. Configure o Ambiente Virtual

**Windows:**
```powershell
# Criar ambiente virtual
python -m venv .venv

# Ativar ambiente virtual
.venv\Scripts\Activate.ps1

# Instalar dependências
uv pip install --system -r requirements.txt
```

**Linux/Mac:**
```bash
# Criar ambiente virtual
python -m venv .venv

# Ativar ambiente virtual
source .venv/bin/activate

# Instalar dependências
uv pip install --system -r requirements.txt
```

### 2. Configuração dos Serviços Externos

#### 2.1. Configuração do Neon DB

1. **Criar uma Conta no Neon DB**
   - Acesse [https://neon.tech](https://neon.tech)
   - Registre-se para uma nova conta
   - Faça login na sua conta

2. **Criar um Novo Projeto**
   - No painel do Neon, clique em "New Project"
   - Dê um nome ao projeto (ex: "ai-hackagents")
   - Selecione uma região próxima à sua localização

   ![Neon DB - Criar Projeto](https://i.imgur.com/lM8T1JD.png)

3. **Obter a URL de Conexão**
   - Após a criação do projeto, clique em "Connection Details"
   - Selecione "Connection String"
   - Copie a string de conexão completa

   ![Neon DB - Connection String](https://i.imgur.com/6rjDGLP.png)

#### 2.2. Configuração do Pinecone

1. **Criar uma Conta no Pinecone**
   - Acesse [https://www.pinecone.io](https://www.pinecone.io)
   - Registre-se para uma nova conta
   - Faça login na sua conta

2. **Criar um Novo Índice**
   - No painel do Pinecone, clique em "Create Index"
   - Preencha os campos:
     - **Nome do índice**: "startupflow"
     - **Dimensão**: 1536 (para embeddings da OpenAI)
     - **Métrica**: "cosine"
     - **Ambiente**: "us-east-1"

   ![Pinecone - Criar Índice](https://i.imgur.com/sB5XE6e.png)

3. **Obter a API Key**
   - No painel do Pinecone, vá para "API Keys"
   - Copie a API Key

#### 2.3. Configuração da OpenAI

1. **Obter uma API Key da OpenAI**
   - Acesse [https://platform.openai.com](https://platform.openai.com)
   - Crie uma conta ou faça login
   - Vá para "API Keys"
   - Clique em "Create new secret key"
   - Dê um nome à chave e copie-a

   ![OpenAI - API Key](https://i.imgur.com/DIdQNdh.png)

### 3. Configuração do Projeto

#### 3.1. Criar o Arquivo .env

Crie um arquivo `.env` na raiz do projeto com o seguinte conteúdo:

```
OPENAI_API_KEY=sua_chave_da_openai
PINECONE_API_KEY=sua_chave_do_pinecone
NEON_DB_URL=sua_url_do_neon_db
OPENAI_API_BASE=https://api.openai.com/v1
```

Substitua os valores pelos que você obteve nas etapas anteriores.

### 4. Preparação do Banco de Dados

#### 4.1. Criar e Popular o Banco de Dados

Execute o script de migração para StartupFlow:

```powershell
python tools/migrar_para_startupflow.py
```

Este script irá:
- Fazer backup das tabelas antigas
- Criar o novo schema StartupFlow
- Configurar as tabelas para validação de startups

> **Nota:** Certifique-se de que a conexão com o Neon DB está funcionando corretamente. Verifique os logs para confirmar que as tabelas foram criadas com sucesso.

#### 4.2. Popular com Dados Demo

Popule o banco com startups de demonstração:

```powershell
python tools/popular_startups_demo.py
```

Isso criará todas as tabelas necessárias para o sistema:
- `ideias_startup`: Armazena as ideias de startup submetidas
- `classificacao_vertical`: Armazena a classificação por vertical de mercado
- `classificacao_potencial`: Armazena a avaliação de potencial
- `analise_mercado`: Armazena a análise de mercado detalhada
- `plano_execucao`: Armazena os planos de execução
- `business_plan`: Armazena os business plans completos

### 5. Processamento dos Agentes

Execute o script para processar as startups com os agentes:

```powershell
python agents/crewai_agents.py
```

Este script irá:
- Processar as startups com os 5 agentes especializados
- Armazenar os resultados no banco de dados
- Criar embeddings no Pinecone para busca semântica

## ▶️ Como Executar

Há duas maneiras principais de usar o sistema:

### Opção 1: Interface Web Interativa

```powershell
python chat_interface/flask_app.py
```

Este comando iniciará a interface web onde você pode:
- Fazer perguntas sobre startups via chat
- Filtrar por vertical e potencial
- Ver startups similares em tempo real
- Acesse: http://localhost:5000

### Opção 2: Processar Novas Startups

```powershell
# Processar todas as startups pendentes
python agents/crewai_agents.py
```

Isso processará todas as startups com status "Submetida" e gerará business plans completos para cada uma.

## 🧩 Componentes Detalhados

### Agentes e suas Funções

#### AG1: Classificador de Vertical
- **Função**: Analisa a startup e identifica sua vertical de mercado
- **Comportamento**: Examina a descrição e classifica em FinTech, EdTech, HealthTech, E-commerce, SaaS, Marketplace, Gaming ou Social
- **Resultado**: Vertical identificada + justificativa detalhada da classificação

#### AG2: Avaliador de Potencial
- **Função**: Avalia o potencial de sucesso da startup
- **Comportamento**: Analisa o modelo de negócio, mercado-alvo e proposta de valor para classificar como Alto, Médio ou Baixo
- **Resultado**: Nível de potencial + justificativa detalhada

#### AG3: Analista de Mercado
- **Função**: Fornece análise de mercado detalhada da startup
- **Comportamento**: Identifica competidores, oportunidades, riscos e validações de mercado
- **Resultado**: Análise de mercado estruturada com concorrentes, oportunidades e validações

#### AG4: Estrategista de Execução
- **Função**: Cria estratégia de execução e roadmap
- **Comportamento**: Define marcos, estratégias de go-to-market e plano de desenvolvimento
- **Resultado**: Roadmap detalhado com marcos, estratégias e plano de ação

#### AG5: Gerador de Business Plan
- **Função**: Cria business plan completo e pitch deck
- **Comportamento**: Integra todas as análises em um business plan estruturado com pitch deck
- **Resultado**: Business plan completo em formatos Markdown e HTML (`startup_X_business_plan.md` e `startup_X_business_plan.html`)

### Arquitetura de Bancos de Dados

#### Banco de Dados Relacional (Neon DB)

```
┈────────────┈       ┈───────────────────┈       ┈──────────────────────┈
│             │       │                     │       │                        │
│    bugs     │──┈    │ classificacao_componente │       │ classificacao_severidade│
│             │  │    │                     │       │                        │
└─────────────┐  │    └───────────────────┐       └──────────────────────┐──┘
                 │                 ▲                              ▲
                 │                 │                              │
                 └─────────────────┴──────────────────────────────┘
                                   │
                                   │
                 ┌────────────────┐│┌────────────────┐    ┌──────────────┐
                 │                ││││                │    │              │
                 │analise_tecnica ││││andamento_chamados   │relatorio_final
                 │                ││││                │    │              │
                 └────────────────┘│└────────────────┘    └──────────────┘
                                   │                              ▲
                                   │                              │
                                   └──────────────────────────────┘
```

#### Banco de Vetores (Pinecone)
- Armazena embeddings de startups para busca semântica
- Permite encontrar startups similares rapidamente
- Utiliza embeddings da OpenAI para representação vetorial

### Fluxo dos Dados

```
┈──────────────┈     ┈─────────┈     ┈─────────┈     ┈─────────┈
│   Startup    │────┐│          │────┐│          │────┐│          │
│  Submetida  │     │   AG1    │     │   AG2    │     │   AG3    │
│             │     │          │     │          │     │          │
└──────────────┐     └─────────┐     └─────────┐     └─────────┐
                     Classificar      Avaliar         Análise de
                     Vertical       Potencial         Mercado
                         │               │                │
                         ▼               ▼                ▼
                    ┌─────────────────────────────────────────┐
                    │                                         │
                    │               Banco de                  │
                    │                Dados                    │
                    │                                         │
                    └─────────────────────────────────────────┘
                              ▲                ▲
                              │                │
                      ┈─────────┈      ┈────────────┈
                      │            │      │             │
                      │    AG4     │      │    AG5      │
                      │            │      │             │
                      └──────────┐      └────────────┐
                       Estratégia        Business
                       Execução           Plan
```

## 🔧 Solução de Problemas

### Problemas com a Conexão ao Neon DB

**Sintoma**: Erros como "could not connect to server" ou "timeout expired"

**Solução**:
1. Verifique se a string de conexão está correta no arquivo .env
2. Certifique-se de que seu IP está permitido no firewall do Neon DB
3. Verifique se o banco de dados está ativo (não em modo suspenso)

### Problemas com a API da OpenAI

**Sintoma**: Erros como "API key invalid" ou "Rate limit exceeded"

**Solução**:
1. Verifique se a API key está correta no arquivo .env
2. Verifique se há créditos disponíveis na sua conta
3. Implemente backoff exponencial para lidar com limites de taxa

### Problemas com o Pinecone

**Sintoma**: Erros ao conectar ou ao realizar operações no índice

**Solução**:
1. Verifique se a API key está correta
2. Confirme se o nome do índice está correto (deve ser "startupflow")
3. Verifique se o índice está ativo e configurado com a dimensão correta (1536)

## 📊 Exemplos de Uso

### Exemplo de Bug Processado

#### Entrada: Bug Original
```
"Erro 500 na API de autenticação após atualização. Ocorre apenas após o último deploy."
```

#### Processamento por Agentes

**AG1: Classificador de Componente**
```
Backend - O problema está relacionado à API de autenticação, que é um componente de backend do sistema.
```

**AG2: Classificador de Severidade**
```
Critico - Um erro 500 na API de autenticação impede os usuários de acessar o sistema, bloqueando funcionalidades essenciais.
```

**AG3: Analista Técnico**
```
Causa Raiz: Incompatibilidade entre a versão atualizada da API e a configuração do servidor.
Impacto: Falha na autenticação de usuários, impedindo acesso ao sistema.
Solução: Reverter para a versão anterior ou corrigir a configuração do servidor para compatibilidade.
```

**AG4: Gerenciador de Resolução**
```
Status: Em desenvolvimento
Responsável: João Silva
Prazo: 2 dias
Prioridade: Alta - Bloqueia acesso ao sistema
```

**AG5: Documentador de Bugs**
```markdown
# Bug #1234 - Erro 500 na API de Autenticação após Atualização

## Descrição
O sistema apresenta erro 500 na API de autenticação após a última atualização, impedindo que os usuários façam login no sistema.

## Componente Afetado
Backend - O problema está relacionado à API de autenticação, que é um componente de backend do sistema.

## Severidade
Critico - Este erro impede o acesso ao sistema, bloqueando completamente a utilização por parte dos usuários.

## Análise Técnica
- Causa Raiz: Incompatibilidade entre a versão atualizada da API e a configuração do servidor.
- Impacto: Falha na autenticação de usuários, impedindo acesso ao sistema.
- Solução: Reverter para a versão anterior ou corrigir a configuração do servidor para compatibilidade.

## Resolução
- Desenvolvedor: João Silva
- Prazo: 2 dias
- Status: Em desenvolvimento

## Lições Aprendidas
Implementar testes de integração mais abrangentes antes de realizar deploys em produção e estabelecer um processo de rollback automático em caso de falhas críticas.
```

Além do relatório em Markdown, o sistema também gera um relatório em HTML com um diagrama Mermaid interativo mostrando o fluxo de resolução do bug.

## ❓ FAQ

### Posso usar outros modelos além do GPT-4?

Sim, você pode configurar outros modelos no arquivo de agentes. Para isso, altere o parâmetro `model` na configuração do LLM:

```python
llm = ChatOpenAI(
    api_key=OPENAI_API_KEY,
    base_url=OPENAI_API_BASE,
    model="gpt-4o-mini",  # Altere para o modelo desejado
    temperature=0.7
)
```

### Como adicionar novos agentes ao sistema?

Para adicionar um novo agente:

1. Defina o agente no arquivo `agents/crewai_agents.py`:
```python
AG6 = Agent(
    name="Nome do Agente",
    role="Papel do Agente",
    goal="Objetivo do Agente",
    backstory="História e comportamento do agente",
    llm=llm
)
```

2. Crie uma tarefa para o agente:
```python
Task_AG6 = Task(
    description="Descrição da tarefa",
    expected_output="Formato esperado de saída",
    agent=AG6
)
```

3. Adicione o agente à equipe:
```python
crew = Crew(
    agents=[AG1, AG2, AG3, AG4, AG5, AG6],  # Adicione o novo agente
    tasks=[Task_AG1, Task_AG2, Task_AG3, Task_AG4, Task_AG5, Task_AG6],  # Adicione a nova tarefa
    verbose=True,
    max_iter=15,
    memory=True
)
```

### Como personalizar as classificações de componentes?

Para alterar os componentes disponíveis, você precisa modificar:

1. O backstory do AG1 (Classificador de Componente):

```python
backstory="""Especialista em triagem de bugs para diferentes componentes de software.
Analiso o conteúdo do bug report e classifico baseado nas seguintes regras:
- Frontend: Problemas de UI, renderização, JavaScript, CSS, responsividade
- Backend: Problemas em APIs, processamento de dados, lógica de negócio
- Database: Problemas com banco de dados, queries, inconsistências
[adicione ou modifique outros componentes conforme necessário]"""
```

2. A função de normalização de componentes:

```python
def normalizar_componente(componente):
    # Valores permitidos exatos conforme a restrição CHECK na tabela
    valores_permitidos = ['Frontend', 'Backend', 'Database', 'DevOps', 'Security', 'Integration', 'UI/UX', 'Infrastructure']
    # Adicione ou modifique os valores permitidos conforme necessário
```

3. A restrição CHECK na tabela `classificacao_setor` no banco de dados:

```sql
CREATE TABLE classificacao_setor (
    id SERIAL PRIMARY KEY,
    chamado_id INT REFERENCES bugs(id),
    setor VARCHAR(50) NOT NULL CHECK (setor IN ('Frontend', 'Backend', 'Database', 'DevOps', 'Security', 'Integration', 'UI/UX', 'Infrastructure')),
    data_classificacao TIMESTAMP DEFAULT NOW()
);
```

---

## 📜 Licença

[MIT License](LICENSE) - Sinta-se livre para usar, modificar e distribuir conforme as regras da licença.

## 🛠️ Melhorias Recentes

1. **Normalização Robusta de Dados**: Implementação de funções de normalização para garantir que os valores gerados pelos agentes estejam em conformidade com as restrições do banco de dados.

2. **Persistência Redundante**: Os relatórios agora são salvos tanto no banco de dados quanto como arquivos locais, garantindo que os dados não sejam perdidos mesmo em caso de problemas com o banco de dados.

3. **Tratamento de Erros Aprimorado**: Cada operação de banco de dados agora tem seu próprio tratamento de erros, permitindo que o sistema continue funcionando mesmo se uma parte falhar.

4. **Documentação Visual**: Adição de diagramas Mermaid interativos nos relatórios HTML para melhor visualização do fluxo de resolução de bugs.

## 📮 Contato

Para dúvidas ou sugestões, entre em contato através de [email@exemplo.com](mailto:email@exemplo.com).
