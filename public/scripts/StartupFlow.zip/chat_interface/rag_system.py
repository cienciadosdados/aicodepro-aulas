#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Sistema RAG para consulta de startups usando Pinecone - StartupFlow
Permite busca semântica e geração de respostas contextualizadas sobre startups
"""

import os
import logging
import sys
from openai import OpenAI
from dotenv import load_dotenv
from typing import List, Dict, Any, Optional

# Adicionar diretório pai ao path para importar pinecone_config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from pinecone_config import get_pinecone_index
    PINECONE_AVAILABLE = True
except ImportError as e:
    print(f"Erro ao importar pinecone_config: {e}")
    PINECONE_AVAILABLE = False
    get_pinecone_index = None

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class StartupRAGSystem:
    def __init__(self):
        """Inicializa o sistema StartupRAG"""
        # Corrigir problema de conflito de variáveis de ambiente OpenAI
        if 'OPENAI_API_KEY' in os.environ:
            del os.environ['OPENAI_API_KEY']
        
        load_dotenv(override=True)
        
        # Configurações
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        self.index_name = "startupflow"
        
        # Inicializar clientes
        self.index = None
        self.openai_client = None
        
        # Memória conversacional
        self.conversation_history = []
        self.max_history_length = 10  # Manter últimas 10 interações
        
        self._initialize_clients()
    
    def _initialize_clients(self):
        """Inicializa os clientes Pinecone e OpenAI"""
        if not PINECONE_AVAILABLE:
            raise Exception("Pinecone não está disponível")
            
        try:
            # Inicializar Pinecone usando função centralizada
            self.index = get_pinecone_index()
            
            # OpenAI - passar chave explicitamente
            self.openai_client = OpenAI(api_key=self.openai_api_key)
            
            logger.info("✅ Clientes inicializados com sucesso")
            
        except Exception as e:
            logger.error(f"❌ Erro ao inicializar clientes: {str(e)}")
            raise
    
    def create_query_embedding(self, query: str) -> List[float]:
        """Cria embedding da query do usuário usando o mesmo modelo do índice"""
        try:
            response = self.openai_client.embeddings.create(
                input=query,
                model="text-embedding-3-small",  # Mesmo modelo do índice Pinecone
                dimensions=1536  # Mesma dimensão do índice
            )
            return response.data[0].embedding
        except Exception as e:
            logger.error(f"❌ Erro ao criar embedding: {str(e)}")
            return []
    
    def _enrich_query_with_context(self, query: str) -> str:
        """Enriquece a query com contexto conversacional"""
        if not self.conversation_history:
            return query
            
        # Pegar últimas interações relevantes
        recent_context = self.conversation_history[-3:]  # Últimas 3 interações
        context_text = " ".join(recent_context)
        
        # Enriquecer query com contexto
        enriched = f"{query} {context_text}"
        logger.info(f"Query enriquecida: {enriched[:100]}...")
        return enriched
    
    def _update_conversation_history(self, query: str, response: str, bugs_found: List[Dict]):
        """Atualiza o histórico conversacional"""
        # Extrair informações relevantes dos bugs encontrados
        bug_context = ""
        if bugs_found:
            bug_ids = [bug['id'] for bug in bugs_found[:3]]  # Top 3 bugs
            bug_context = f" (bugs relevantes: {', '.join(bug_ids)})"
        
        # Adicionar ao histórico
        interaction = f"Q: {query} A: {response[:100]}...{bug_context}"
        self.conversation_history.append(interaction)
        
        # Manter apenas as últimas interações
        if len(self.conversation_history) > self.max_history_length:
            self.conversation_history = self.conversation_history[-self.max_history_length:]
        
        logger.info(f"Histórico atualizado. Total de interações: {len(self.conversation_history)}")
    
    def clear_conversation_history(self):
        """Limpa o histórico conversacional"""
        self.conversation_history = []
        logger.info("Histórico conversacional limpo")
    
    def get_conversation_summary(self) -> str:
        """Retorna resumo do histórico conversacional"""
        if not self.conversation_history:
            return "Nenhuma conversa anterior"
        
        return f"Histórico: {len(self.conversation_history)} interações. Últimas: {self.conversation_history[-2:]}"
    
    def search_similar_startups(self, query: str, top_k: int = 5, filters: Optional[Dict] = None) -> List[Dict]:
        """Busca startups similares usando embedding semântico com contexto conversacional"""
        try:
            # Enriquecer query com contexto conversacional
            enriched_query = self._enrich_query_with_context(query)
            
            # Criar embedding da query enriquecida
            query_embedding = self.create_query_embedding(enriched_query)
            if not query_embedding:
                return []
            
            # Preparar filtros
            filter_dict = {}
            if filters:
                if filters.get('vertical'):
                    filter_dict['vertical'] = filters['vertical']
                if filters.get('potencial'):
                    filter_dict['potencial'] = filters['potencial']
                if filters.get('empreendedor'):
                    filter_dict['empreendedor'] = filters['empreendedor']
            
            # Buscar no Pinecone
            search_params = {
                'vector': query_embedding,
                'top_k': top_k,
                'include_metadata': True
            }
            
            if filter_dict:
                search_params['filter'] = filter_dict
            
            results = self.index.query(**search_params)
            
            # Processar resultados
            startups_encontradas = []
            for match in results.matches:
                startup_info = {
                    'id': match.id,
                    'score': match.score,
                    'metadata': match.metadata or {}
                }
                startups_encontradas.append(startup_info)
            
            logger.info(f"✅ Encontradas {len(startups_encontradas)} startups similares")
            return startups_encontradas
            
        except Exception as e:
            logger.error(f"❌ Erro na busca: {str(e)}")
            return []
    
    def build_context(self, startups: List[Dict], max_tokens: int = 3000) -> str:
        """Constrói contexto para o LLM baseado nas startups encontradas"""
        if not startups:
            return "Nenhuma startup relevante encontrada na base de dados."
        
        context_parts = ["=== STARTUPS RELEVANTES ENCONTRADAS ===\n"]
        current_tokens = 0
        
        for i, startup in enumerate(startups, 1):
            metadata = startup.get('metadata', {})
            score = startup.get('score', 0)
            
            startup_context = f"""
Startup #{startup['id']} (Relevância: {score:.2f})
- Título: {metadata.get('titulo', 'N/A')}
- Vertical: {metadata.get('vertical', 'N/A')}
- Potencial: {metadata.get('potencial', 'N/A')}
- Empreendedor: {metadata.get('empreendedor', 'N/A')}
- Modelo de Negócio: {metadata.get('modelo_negocio', 'N/A')}
- Conteúdo: {metadata.get('conteudo_completo', 'N/A')[:500]}...

"""
            
            # Estimativa simples de tokens (4 chars ≈ 1 token)
            estimated_tokens = len(startup_context) // 4
            
            if current_tokens + estimated_tokens > max_tokens:
                break
                
            context_parts.append(startup_context)
            current_tokens += estimated_tokens
        
        return "\n".join(context_parts)
    
    def generate_response(self, query: str, context: str) -> str:
        """Gera resposta usando OpenAI com o contexto das startups"""
        try:
            system_prompt = """Você é um assistente especializado em análise de startups e validação de negócios. 
            
Sua função é ajudar empreendedores, investidores e consultores a entender e avaliar startups baseado no histórico de validações da empresa.

INSTRUÇÕES:
1. Use APENAS as informações fornecidas no contexto das startups
2. Seja preciso e estratégico nas suas respostas sobre negócios
3. Cite sempre os IDs das startups relevantes (ex: "Startup #123")
4. Se não houver informação suficiente, diga claramente
5. Forneça insights de negócio e recomendações estratégicas
6. Mantenha um tom profissional mas acessível para empreendedores
7. IMPORTANTE: Quando o usuário usar referências como "essa startup", "esse negócio", "essa ideia", conecte com as startups mencionadas anteriormente
8. Se a pergunta for sobre "quem", "empreendedor", "founder", foque nas informações dos responsáveis pelas startups

REFERÊNCIAS CONTEXTUAIS:
- "essa startup" = startup mencionada anteriormente
- "o negócio" = ideia de negócio em discussão
- "quem está tocando" = empreendedor responsável
- "essa ideia" = conceito de startup em questão

FORMATO DE RESPOSTA:
- Resposta direta à pergunta
- Startups relevantes citadas
- Insights de mercado ou recomendações estratégicas (se aplicável)"""

            user_prompt = f"""
PERGUNTA DO USUÁRIO: {query}

CONTEXTO DAS STARTUPS:
{context}

Por favor, responda à pergunta baseado exclusivamente nas informações das startups fornecidas acima.
"""

            response = self.openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.1,
                max_tokens=1000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"❌ Erro ao gerar resposta: {str(e)}")
            return f"Desculpe, ocorreu um erro ao processar sua pergunta: {str(e)}"
    
    def chat(self, query: str, filters: Optional[Dict] = None, top_k: int = 5) -> Dict[str, Any]:
        """Função principal do chat RAG para startups com memória conversacional"""
        try:
            # 1. Buscar startups similares (já usa contexto conversacional)
            startups_similares = self.search_similar_startups(query, top_k, filters)
            
            # 2. Construir contexto
            context = self.build_context(startups_similares)
            
            # 3. Gerar resposta
            response = self.generate_response(query, context)
            
            # 4. Atualizar histórico conversacional
            self._update_conversation_history(query, response, startups_similares)
            
            return {
                'response': response,
                'startups_encontradas': startups_similares,
                'context_used': context,
                'conversation_history_size': len(self.conversation_history),
                'success': True
            }
            
        except Exception as e:
            logger.error(f"❌ Erro no chat: {str(e)}")
            return {
                'response': f"Desculpe, ocorreu um erro: {str(e)}",
                'startups_encontradas': [],
                'context_used': "",
                'success': False
            }
    
    def get_index_stats(self) -> Dict[str, Any]:
        """Obtém estatísticas do índice Pinecone"""
        try:
            stats = self.index.describe_index_stats()
            return {
                'total_vectors': stats.total_vector_count,
                'dimension': stats.dimension,
                'index_fullness': stats.index_fullness
            }
        except Exception as e:
            logger.error(f"❌ Erro ao obter estatísticas: {str(e)}")
            return {}

# Função para criar instância do sistema StartupRAG
def get_startup_rag_system():
    """Cria e retorna instância do sistema StartupRAG"""
    return StartupRAGSystem()
