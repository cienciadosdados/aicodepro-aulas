#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Interface Flask para o sistema RAG de startups - StartupFlow
Integrado com agentes CrewAI melhorados para processamento de startups
"""

from flask import Flask, render_template, request, jsonify
import os
import sys
import subprocess
import psycopg2
from datetime import datetime
from dotenv import load_dotenv
from rag_system import StartupRAGSystem

# Adicionar diretório pai para importar agentes
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

app = Flask(__name__)

# Carregar variáveis de ambiente
load_dotenv()
NEON_DB_URL = os.getenv("NEON_DB_URL")

# Inicializar sistema RAG
try:
    rag_system = StartupRAGSystem()
    print("✅ Sistema StartupRAG inicializado com sucesso!")
except Exception as e:
    print(f"❌ Erro ao inicializar sistema StartupRAG: {str(e)}")
    rag_system = None

@app.route('/')
def index():
    """Página principal"""
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    """Endpoint para chat"""
    if not rag_system:
        return jsonify({
            'success': False,
            'response': 'Sistema StartupRAG não está disponível',
            'startups_encontradas': []
        })
    
    data = request.json
    query = data.get('query', '')
    filters = data.get('filters', {})
    top_k = data.get('top_k', 5)
    
    if not query:
        return jsonify({
            'success': False,
            'response': 'Por favor, digite uma pergunta sobre startups',
            'startups_encontradas': []
        })
    
    # Processar query
    result = rag_system.chat(query, filters, top_k)
    
    return jsonify(result)

@app.route('/clear-history', methods=['POST'])
def clear_history():
    """Endpoint para limpar histórico conversacional"""
    if not rag_system:
        return jsonify({
            'success': False,
            'message': 'Sistema StartupRAG não está disponível'
        })
    
    rag_system.clear_conversation_history()
    return jsonify({
        'success': True,
        'message': 'Histórico conversacional limpo com sucesso'
    })

@app.route('/stats')
def stats():
    """Endpoint para estatísticas"""
    if not rag_system:
        return jsonify({'error': 'Sistema StartupRAG não disponível'})
    
    stats = rag_system.get_index_stats()
    
    # Adicionar estatísticas do banco de dados
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Contar startups por status
        cur.execute("SELECT status, COUNT(*) FROM ideias_startup GROUP BY status")
        status_counts = dict(cur.fetchall())
        
        # Contar por vertical
        cur.execute("""
            SELECT cv.vertical, COUNT(*)
            FROM classificacao_vertical cv
            JOIN ideias_startup i ON cv.ideia_id = i.id
            WHERE i.status = 'Processado'
            GROUP BY cv.vertical
        """)
        vertical_counts = dict(cur.fetchall())
        
        # Contar por potencial
        cur.execute("""
            SELECT cp.potencial, COUNT(*)
            FROM classificacao_potencial cp
            JOIN ideias_startup i ON cp.ideia_id = i.id
            WHERE i.status = 'Processado'
            GROUP BY cp.potencial
        """)
        potencial_counts = dict(cur.fetchall())
        
        cur.close()
        conn.close()
        
        stats.update({
            'database_stats': {
                'status_counts': status_counts,
                'vertical_counts': vertical_counts,
                'potencial_counts': potencial_counts
            }
        })
        
    except Exception as e:
        stats['database_error'] = str(e)
    
    return jsonify(stats)

@app.route('/process-startups', methods=['POST'])
def process_startups():
    """Endpoint para processar startups com agentes CrewAI melhorados"""
    try:
        # Verificar se há startups submetidas
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM ideias_startup WHERE status = 'Submetida'")
        total_submetidas = cur.fetchone()[0]
        cur.close()
        conn.close()
        
        if total_submetidas == 0:
            return jsonify({
                'success': False,
                'message': 'Nenhuma startup submetida encontrada para processar'
            })
        
        # Executar processamento dos agentes em background
        result = subprocess.run([
            'python', '../agents/crewai_agents.py'
        ], capture_output=True, text=True, cwd=os.path.dirname(__file__))
        
        if result.returncode == 0:
            return jsonify({
                'success': True,
                'message': f'Processamento iniciado para {total_submetidas} startups',
                'output': result.stdout[-500:] if result.stdout else 'Processamento concluído'
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Erro no processamento',
                'error': result.stderr[-500:] if result.stderr else 'Erro desconhecido'
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao processar startups: {str(e)}'
        })

@app.route('/reset-startups', methods=['POST'])
def reset_startups():
    """Endpoint para resetar status das startups"""
    try:
        result = subprocess.run([
            'python', '../tools/resetar_status_startups.py'
        ], capture_output=True, text=True, cwd=os.path.dirname(__file__))
        
        if result.returncode == 0:
            return jsonify({
                'success': True,
                'message': 'Status das startups resetado com sucesso'
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Erro ao resetar startups',
                'error': result.stderr if result.stderr else 'Erro desconhecido'
            })
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao resetar startups: {str(e)}'
        })

@app.route('/startup-details/<int:startup_id>')
def startup_details(startup_id):
    """Endpoint para obter detalhes completos de uma startup"""
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Buscar dados completos da startup
        cur.execute("""
            SELECT i.id, i.titulo, i.descricao, i.empreendedor, i.problema_resolve,
                   i.publico_alvo, i.modelo_negocio, i.status, i.data_submissao,
                   cv.vertical, cv.justificativa as vertical_just,
                   cp.potencial, cp.score_viabilidade, cp.fatores_positivos,
                   am.tamanho_mercado, am.principais_concorrentes, am.diferencial_competitivo,
                   pe.perfil_equipe_ideal, pe.investimento_necessario, pe.tempo_desenvolvimento,
                   bp.viavel, bp.recomendacao_final
            FROM ideias_startup i
            LEFT JOIN classificacao_vertical cv ON i.id = cv.ideia_id
            LEFT JOIN classificacao_potencial cp ON i.id = cp.ideia_id
            LEFT JOIN analise_mercado am ON i.id = am.ideia_id
            LEFT JOIN plano_execucao pe ON i.id = pe.ideia_id
            LEFT JOIN business_plan bp ON i.id = bp.ideia_id
            WHERE i.id = %s
        """, (startup_id,))
        
        startup = cur.fetchone()
        cur.close()
        conn.close()
        
        if not startup:
            return jsonify({
                'success': False,
                'message': 'Startup não encontrada'
            })
        
        # Estruturar dados
        startup_data = {
            'id': startup[0],
            'titulo': startup[1],
            'descricao': startup[2],
            'empreendedor': startup[3],
            'problema_resolve': startup[4],
            'publico_alvo': startup[5],
            'modelo_negocio': startup[6],
            'status': startup[7],
            'data_submissao': startup[8].isoformat() if startup[8] else None,
            'classificacao': {
                'vertical': startup[9],
                'vertical_justificativa': startup[10],
                'potencial': startup[11],
                'score_viabilidade': startup[12],
                'fatores_positivos': startup[13]
            },
            'analise_mercado': {
                'tamanho_mercado': startup[14],
                'principais_concorrentes': startup[15],
                'diferencial_competitivo': startup[16]
            },
            'plano_execucao': {
                'perfil_equipe_ideal': startup[17],
                'investimento_necessario': startup[18],
                'tempo_desenvolvimento': startup[19]
            },
            'business_plan': {
                'viavel': startup[20],
                'recomendacao_final': startup[21]
            }
        }
        
        # Verificar se existem arquivos gerados
        business_plan_file = f'../startup_{startup_id}_business_plan.md'
        pitch_deck_file = f'../startup_{startup_id}_pitch_deck.html'
        
        startup_data['arquivos_gerados'] = {
            'business_plan': os.path.exists(business_plan_file),
            'pitch_deck': os.path.exists(pitch_deck_file)
        }
        
        return jsonify({
            'success': True,
            'startup': startup_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao buscar detalhes da startup: {str(e)}'
        })

@app.route('/list-startups')
def list_startups():
    """Endpoint para listar todas as startups com resumo"""
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        cur.execute("""
            SELECT i.id, i.titulo, i.empreendedor, i.status, i.data_submissao,
                   cv.vertical, cp.potencial, cp.score_viabilidade, bp.viavel
            FROM ideias_startup i
            LEFT JOIN classificacao_vertical cv ON i.id = cv.ideia_id
            LEFT JOIN classificacao_potencial cp ON i.id = cp.ideia_id
            LEFT JOIN business_plan bp ON i.id = bp.ideia_id
            ORDER BY i.id DESC
        """)
        
        startups = []
        for row in cur.fetchall():
            startups.append({
                'id': row[0],
                'titulo': row[1],
                'empreendedor': row[2],
                'status': row[3],
                'data_submissao': row[4].isoformat() if row[4] else None,
                'vertical': row[5],
                'potencial': row[6],
                'score_viabilidade': row[7],
                'viavel': row[8]
            })
        
        cur.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'startups': startups,
            'total': len(startups)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Erro ao listar startups: {str(e)}'
        })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
