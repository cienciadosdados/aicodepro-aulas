https://www.mermaidchart.com/app/projects/1711aea4-a22f-4159-802e-bc109a7e9938/diagrams/34f78ac0-500c-470a-b54c-57808990a352/version/v0.1/edit

```mermaid
flowchart TD
    A[Ideia Submetida] --> B[Banco de Dados Neon]
    B --> C[Indexação Pinecone]
    B --> D[Processamento Agentes]
    
    subgraph "Validação de Startup"
        D --> E[AG1: Classificador de Vertical]
        E --> F[AG2: Avaliador de Potencial]
        F --> G[AG3: Analista de Mercado]
        G --> H[AG4: Estrategista de Execução]
        H --> I[AG5: Gerador Business Plan]
    end
    
    C -.-> G
    I --> J[Business Plan Final]
    
    subgraph "Base de Conhecimento"
        K[OpenAI API]
        L[Vector Store - Pinecone]
        M[DB Relacional - Neon]
    end
    
    K -.-> E
    K -.-> F
    K -.-> G
    K -.-> H
    K -.-> I
    L -.-> G
    M --> B
    
    style A fill:#e8f5e8,stroke:#333,stroke-width:2px
    style J fill:#fff3cd,stroke:#333,stroke-width:2px
    style K fill:#f0ad4e,stroke:#333,stroke-width:2px
    style L fill:#5bc0de,stroke:#333,stroke-width:2px
    style M fill:#5cb85c,stroke:#333,stroke-width:2px
```

## Explicação do Fluxo de Validação de Startups

1. **Ideia Submetida**: Empreendedor submete nova ideia de startup no sistema.

2. **Banco de Dados Neon**: Dados da ideia são armazenados no PostgreSQL da Neon, incluindo título, descrição, empreendedor e outras informações relevantes.

3. **Indexação Pinecone**: Paralelamente, o conteúdo da startup é convertido em embeddings e indexado no Pinecone para busca semântica de ideias similares.

4. **Processamento por Agentes Especializados**:
   - **AG1 (Classificador de Vertical)**: Identifica vertical de mercado (FinTech, EdTech, HealthTech, etc.).
   - **AG2 (Avaliador de Potencial)**: Avalia potencial de sucesso (Alto, Médio, Baixo) baseado no modelo de negócio e mercado-alvo.
   - **AG3 (Analista de Mercado)**: Análise competitiva e identificação de oportunidades, consultando base vetorial para startups similares.
   - **AG4 (Estrategista de Execução)**: Cria roadmap e estratégia de execução com marcos e plano de ação.
   - **AG5 (Gerador Business Plan)**: Compila todas as análises e gera business plan completo e pitch deck.

5. **Business Plan Final**: 
   - **Documentação Completa**: Business plan estruturado incluindo análise de mercado, projeções financeiras e estratégia de go-to-market, salvo como arquivo local (`startup_X_business_plan.md` e `.html`).

O diagrama também mostra as interações com:
- **OpenAI API**: Fornece os modelos de IA para todos os agentes.
- **Vector Store (Pinecone)**: Armazena embeddings para consulta semântica e identificação de startups similares.
- **DB Relacional (Neon)**: Armazena todos os dados estruturados das startups e suas validações.

## Persistência Redundante

Uma característica importante do sistema é a persistência redundante:

1. **Banco de Dados**: Todas as validações são armazenadas nas tabelas do banco de dados Neon.
2. **Arquivos Locais**: Os business plans são também salvos como arquivos locais, garantindo que mesmo em caso de falha no banco de dados, os resultados não sejam perdidos.

Esta abordagem garante maior robustez ao sistema, permitindo que ele continue funcionando mesmo em cenários de falha parcial.
