# verificacao_completa.py
import psycopg2
import os
from dotenv import load_dotenv

def verificar_ambiente():
    print("🔍 VERIFICAÇÃO COMPLETA DO AMBIENTE NEON")
    print("=" * 50)
    
    # Carregar variáveis
    load_dotenv()
    neon_url = os.getenv('NEON_DB_URL')
    
    if not neon_url:
        print("❌ NEON_DB_URL não encontrada no .env")
        return False
    
    try:
        # Conectar
        conn = psycopg2.connect(neon_url)
        cur = conn.cursor()
        print("✅ Conexão estabelecida")
        
        # Verificar versão do PostgreSQL
        cur.execute("SELECT version();")
        version = cur.fetchone()[0]
        print(f"📊 Versão: {version.split(',')[0]}")
        
        # Verificar tabelas
        cur.execute("""
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        ORDER BY table_name;
        """)
        
        tabelas = [row[0] for row in cur.fetchall()]
        tabelas_esperadas = [
            'ideias_startup', 'classificacao_vertical', 
            'classificacao_potencial', 'analise_mercado', 
            'plano_execucao', 'business_plan'
        ]
        
        print(f"✅ Tabelas encontradas: {len(tabelas)}")
        
        # Verificar dados
        print("\n📊 DADOS POR TABELA:")
        total_registros = 0
        for tabela in tabelas_esperadas:
            if tabela in tabelas:
                cur.execute(f'SELECT COUNT(*) FROM {tabela};')
                count = cur.fetchone()[0]
                total_registros += count
                status = "✅" if count > 0 else "⚠️"
                print(f"  {status} {tabela}: {count} registros")
            else:
                print(f"  ❌ {tabela}: TABELA NÃO ENCONTRADA")
        
        print(f"\n📈 Total de registros: {total_registros}")
        
        # Teste de query complexa
        print("\n🧪 TESTE DE QUERY COMPLEXA:")
        cur.execute("""
        SELECT
            i.titulo,
            cv.vertical,
            cp.potencial
        FROM ideias_startup i
        LEFT JOIN classificacao_vertical cv ON i.id = cv.ideia_id
        LEFT JOIN classificacao_potencial cp ON i.id = cp.ideia_id
        LIMIT 3;
        """)
        
        resultados = cur.fetchall()
        if resultados:
            print("✅ Query complexa executada com sucesso")
            for row in resultados:
                nome = row[0] if row[0] else "N/A"
                vertical = row[1] if row[1] else "N/A"
                potencial = row[2] if row[2] else "N/A"
                print(f"  - {nome} | {vertical} | {potencial}")
        else:
            print("⚠️ Query retornou vazia")
        
        # Verificar estrutura de uma tabela
        print("\n🏗️ ESTRUTURA DA TABELA ideias_startup:")
        cur.execute("""
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns
        WHERE table_name = 'ideias_startup'
        ORDER BY ordinal_position;
        """)
        
        colunas = cur.fetchall()
        for coluna in colunas:
            nullable = "NULL" if coluna[2] == "YES" else "NOT NULL"
            print(f"  - {coluna[0]}: {coluna[1]} ({nullable})")
        
        # Teste de inserção (rollback)
        print("\n🧪 TESTE DE INSERÇÃO (ROLLBACK):")
        try:
            cur.execute("BEGIN;")
            cur.execute("""
            INSERT INTO ideias_startup (titulo, descricao, empreendedor, problema_resolve, publico_alvo, modelo_negocio)
            VALUES ('Teste Startup', 'Descrição de teste', 'Empreendedor Teste', 'Problema de teste', 'Público teste', 'B2C');
            """)
            cur.execute("SELECT COUNT(*) FROM ideias_startup WHERE titulo = 'Teste Startup';")
            count = cur.fetchone()[0]
            cur.execute("ROLLBACK;")
            
            if count == 1:
                print("✅ Inserção funcionando (teste com rollback)")
            else:
                print("⚠️ Problema na inserção")
                
        except Exception as e:
            print(f"❌ Erro no teste de inserção: {e}")
            cur.execute("ROLLBACK;")
        
        cur.close()
        conn.close()
        
        print("\n" + "=" * 50)
        print("🎉 VERIFICAÇÃO CONCLUÍDA COM SUCESSO!")
        print("✅ Banco Neon está funcionando perfeitamente")
        print("✅ Todas as tabelas estão criadas")
        print("✅ Dados estão inseridos")
        print("✅ Queries complexas funcionando")
        print("=" * 50)
        
        return True
        
    except Exception as e:
        print(f"❌ Erro durante verificação: {e}")
        print("\n🔧 POSSÍVEIS SOLUÇÕES:")
        print("1. Verifique se NEON_DB_URL está correta no .env")
        print("2. Confirme se o projeto Neon não foi pausado")
        print("3. Teste a conexão manualmente no console Neon")
        print("4. Verifique se as tabelas foram criadas")
        return False

def teste_conexao_simples():
    """Teste básico de conexão"""
    print("🔌 TESTE SIMPLES DE CONEXÃO")
    print("-" * 30)
    
    load_dotenv()
    neon_url = os.getenv('NEON_DB_URL')
    
    if not neon_url:
        print("❌ NEON_DB_URL não encontrada")
        return False
    
    try:
        conn = psycopg2.connect(neon_url)
        print("✅ Conexão estabelecida com sucesso!")
        conn.close()
        print("🔒 Conexão fechada")
        return True
    except Exception as e:
        print(f"❌ Erro na conexão: {e}")
        return False

if __name__ == "__main__":
    print("🚀 INICIANDO VERIFICAÇÃO DO NEON DATABASE")
    print()
    
    # Primeiro teste simples
    if teste_conexao_simples():
        print()
        # Se conexão OK, fazer verificação completa
        verificar_ambiente()
    else:
        print("\n❌ Falha na conexão básica. Verifique suas configurações.")