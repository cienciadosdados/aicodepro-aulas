# 🚀 Guia Completo para Recriação do Ambiente - StartupFlow

## 📋 Pré-requisitos

### Contas Necessárias
- [x] **OpenAI** - Para modelos GPT ([platform.openai.com](https://platform.openai.com))
- [x] **Neon DB** - PostgreSQL serverless ([neon.tech](https://neon.tech))
- [x] **Pinecone** - Banco vetorial ([pinecone.io](https://pinecone.io))

### Ambiente Local
- [x] **Python 3.9+** instalado
- [x] **Git** para controle de versão
- [x] **Editor de código** (VS Code recomendado)

## 🗑️ PASSO 1: Limpeza Completa (OPCIONAL)

Se você já tem tabelas no Neon DB e quer começar do zero:

```bash
# Execute o script de limpeza
python tools/deletar_tabelas_neon.py
```

⚠️ **ATENÇÃO**: Este comando deleta TODAS as tabelas e dados do Neon DB!

## 🔧 PASSO 2: Configuração do Ambiente Local

### 2.1 Clonar/Preparar o Repositório
```bash
# Se ainda não tem o projeto
git clone <url-do-repositorio>
cd "Project Three"

# Ou navegue até o diretório existente
cd "c:/aicodepro/Project 03/Project Three"
```

### 2.2 Criar Ambiente Virtual
```bash
# Windows
python -m venv .venv
.venv\Scripts\Activate.ps1

# Linux/Mac
python -m venv .venv
source .venv/bin/activate
```

### 2.3 Instalar Dependências
```bash
# Instalar uv (gerenciador rápido)
pip install uv

# Instalar todas as dependências
uv pip install --system -r requirements.txt

# Instalar ferramentas adicionais do CrewAI
uv pip install "crewai[tools]"
```

## 🔑 PASSO 3: Configuração das APIs

### 3.1 OpenAI API Key
1. Acesse [platform.openai.com](https://platform.openai.com)
2. Vá em **API Keys**
3. Clique em **Create new secret key**
4. Copie a chave gerada

### 3.2 Neon DB Setup
1. Acesse [neon.tech](https://neon.tech)
2. Crie uma nova conta ou faça login
3. Clique em **New Project**
4. Configure:
   - **Nome**: `startupflow-db`
   - **Região**: Escolha a mais próxima
5. Após criação, vá em **Connection Details**
6. Copie a **Connection String** completa

### 3.3 Pinecone Setup
1. Acesse [pinecone.io](https://pinecone.io)
2. Crie conta ou faça login
3. Clique em **Create Index**
4. Configure:
   - **Nome**: `startupflow`
   - **Dimensões**: `1536`
   - **Métrica**: `cosine`
   - **Região**: `us-east-1`
5. Vá em **API Keys** e copie sua chave

### 3.4 Criar Arquivo .env
Crie o arquivo `.env` na raiz do projeto:

```env
# APIs
OPENAI_API_KEY=sk-proj-sua_chave_aqui
PINECONE_API_KEY=pcsk_sua_chave_aqui
NEON_DB_URL=postgresql://user:pass@host/db?sslmode=require
OPENAI_API_BASE=https://api.openai.com/v1
```

## 🗄️ PASSO 4: Configuração do Banco de Dados

### 4.1 Testar Conexão
```bash
python -c "
import psycopg2
import os
from dotenv import load_dotenv
load_dotenv()
conn = psycopg2.connect(os.getenv('NEON_DB_URL'))
print('✅ Conexão com Neon DB funcionando!')
conn.close()
"
```

### 4.2 Criar Schema StartupFlow
```bash
# Executar migração completa
python tools/migrar_para_startupflow.py
```

Este script irá:
- ✅ Fazer backup de tabelas existentes
- ✅ Criar todas as tabelas do StartupFlow
- ✅ Inserir dados de exemplo (5 startups)
- ✅ Limpar índice Pinecone

### 4.3 Verificar Criação das Tabelas
```bash
python -c "
import psycopg2
import os
from dotenv import load_dotenv
load_dotenv()
conn = psycopg2.connect(os.getenv('NEON_DB_URL'))
cur = conn.cursor()
cur.execute(\"SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name;\")
tabelas = [row[0] for row in cur.fetchall()]
print('📋 Tabelas criadas:', ', '.join(tabelas))
cur.execute('SELECT COUNT(*) FROM ideias_startup;')
total = cur.fetchone()[0]
print(f'📊 Total de startups: {total}')
conn.close()
"
```

## 🤖 PASSO 5: Executar os Agentes

### 5.1 Processar Startups com Agentes
```bash
# Executar todos os 5 agentes especializados
python agents/crewai_agents.py
```

Este processo irá:
- 🔄 Processar cada startup com os 5 agentes
- 📊 Classificar por vertical e potencial
- 📈 Realizar análise de mercado
- 🎯 Criar plano de execução
- 📋 Gerar business plan completo
- 🔍 Criar embeddings no Pinecone

**Tempo estimado**: 5-10 minutos (depende da API da OpenAI)

### 5.2 Verificar Processamento
```bash
python -c "
import psycopg2
import os
from dotenv import load_dotenv
load_dotenv()
conn = psycopg2.connect(os.getenv('NEON_DB_URL'))
cur = conn.cursor()
cur.execute('SELECT COUNT(*) FROM business_plan;')
total = cur.fetchone()[0]
print(f'📋 Business plans gerados: {total}')
conn.close()
"
```

## 🌐 PASSO 6: Testar Interface Web

### 6.1 Iniciar Servidor Flask
```bash
# Navegar para o diretório da interface
cd chat_interface

# Iniciar aplicação
python flask_app.py
```

### 6.2 Acessar Interface
- Abra o navegador em: **http://localhost:5000**
- Teste o chat interativo
- Experimente filtros por vertical e potencial
- Verifique busca semântica de startups similares

## ✅ PASSO 7: Verificação Final

### 7.1 Checklist de Funcionamento
- [ ] Conexão com Neon DB funcionando
- [ ] Tabelas StartupFlow criadas
- [ ] Dados de exemplo inseridos
- [ ] Agentes processaram startups
- [ ] Business plans gerados
- [ ] Pinecone com embeddings
- [ ] Interface web funcionando
- [ ] Chat respondendo perguntas

### 7.2 Comandos de Verificação
```bash
# Verificar tabelas
python -c "
import psycopg2, os
from dotenv import load_dotenv
load_dotenv()
conn = psycopg2.connect(os.getenv('NEON_DB_URL'))
cur = conn.cursor()
tabelas = ['ideias_startup', 'classificacao_vertical', 'classificacao_potencial', 'analise_mercado', 'plano_execucao', 'business_plan']
for tabela in tabelas:
    cur.execute(f'SELECT COUNT(*) FROM {tabela};')
    count = cur.fetchone()[0]
    print(f'{tabela}: {count} registros')
conn.close()
"

# Verificar Pinecone
python -c "
import pinecone, os
from dotenv import load_dotenv
load_dotenv()
pc = pinecone.Pinecone(api_key=os.getenv('PINECONE_API_KEY'))
index = pc.Index('startupflow')
stats = index.describe_index_stats()
print(f'Pinecone: {stats.total_vector_count} vetores')
"
```

## 🔧 Solução de Problemas Comuns

### Erro de Conexão Neon DB
```bash
# Verificar se a URL está correta
echo $NEON_DB_URL

# Testar conexão manual
python -c "import psycopg2; psycopg2.connect('sua_url_aqui')"
```

### Erro na API OpenAI
```bash
# Verificar se a chave está correta
python -c "
import openai, os
from dotenv import load_dotenv
load_dotenv()
client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
print('✅ OpenAI API funcionando!')
"
```

### Erro no Pinecone
```bash
# Verificar índice
python -c "
import pinecone, os
from dotenv import load_dotenv
load_dotenv()
pc = pinecone.Pinecone(api_key=os.getenv('PINECONE_API_KEY'))
print('Índices disponíveis:', pc.list_indexes())
"
```

## 📚 Próximos Passos

### Para Desenvolvimento
1. **Adicionar novas startups**: Insira diretamente na tabela `ideias_startup`
2. **Customizar agentes**: Modifique [`agents/crewai_agents.py`](agents/crewai_agents.py)
3. **Melhorar interface**: Edite [`chat_interface/templates/index.html`](chat_interface/templates/index.html)

### Para Produção
1. **Containerização**: Criar Dockerfile
2. **Deploy**: Heroku, Railway, ou similar
3. **Monitoramento**: Logs e métricas
4. **Backup**: Estratégia de backup automático

## 📞 Suporte

Se encontrar problemas:
1. Verifique os logs de erro
2. Confirme todas as variáveis de ambiente
3. Teste conexões individuais (DB, APIs)
4. Consulte a documentação oficial das ferramentas

---

**🎉 Parabéns! Seu ambiente StartupFlow está pronto para uso!**