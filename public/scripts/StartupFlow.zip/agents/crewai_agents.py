# -*- coding: utf-8 -*-
import os
import logging
import json
import re
import psycopg2
import openai
import litellm
import html
import pinecone
from datetime import datetime
from urllib.parse import urlparse
from pathlib import Path
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from openai import OpenAI

# Importacoes para LangChain
from langchain_openai import ChatOpenAI
from langchain.tools import tool
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.agents import AgentType, initialize_agent, load_tools
from langchain.memory import ConversationBufferMemory
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.callbacks.manager import CallbackManager
from langchain.schema import HumanMessage, AIMessage
from langchain.prompts.chat import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    HumanMessagePromptTemplate,
)

# Configuracao de logs
logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

# Limpar qualquer variável de ambiente global da OpenAI
if 'OPENAI_API_KEY' in os.environ:
    del os.environ['OPENAI_API_KEY']

# Carregar variaveis do .env forçadamente
load_dotenv(override=True)
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
PINECONE_API_KEY = os.getenv("PINECONE_API_KEY")
NEON_DB_URL = os.getenv("NEON_DB_URL")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE", "https://api.openai.com/v1")

# Configuracao explicita do OpenAI
openai.api_key = OPENAI_API_KEY
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# Configuracao explicita do LiteLLM
litellm.api_key = OPENAI_API_KEY
litellm.set_verbose = True  # Ativar logs para debug do GPT-5

# Configurar o modelo LLM base para todos os agentes
llm = ChatOpenAI(
    model="gpt-4o",
    temperature=0.1,
    api_key=OPENAI_API_KEY,
    base_url=OPENAI_API_BASE,
    max_tokens=2500,  # Aumentado para respostas mais detalhadas
    timeout=300,
    request_timeout=300,
    max_retries=3
)

# Criar os agentes
AG1 = Agent(
    name="Classificador de Vertical",
    role="Classificacao de startups por vertical de mercado",
    goal="Classificar corretamente as ideias nos verticais adequados do mercado usando dados específicos da startup.",
    backstory="""Especialista em análise de mercado e categorização de startups.
    Analiso ESPECIFICAMENTE a ideia fornecida e classifico baseado nas seguintes regras:
    - FinTech: Soluções financeiras, pagamentos, investimentos, banking
    - EdTech: Educação, treinamento, e-learning, plataformas educacionais
    - HealthTech: Saúde, telemedicina, bem-estar, dispositivos médicos
    - E-commerce: Marketplaces, vendas online, retail, comércio eletrônico
    - SaaS: Software como serviço, ferramentas B2B, plataformas de produtividade
    - Marketplace: Plataformas de conexão entre oferta/demanda, intermediação
    - Gaming: Jogos, entretenimento digital, esports, streaming
    - Social: Redes sociais, comunicação, comunidades, networking
    
    IMPORTANTE: Sempre uso os dados específicos fornecidos (título, descrição, problema, público-alvo) para fazer a classificação.""",
    llm=llm
)

AG2 = Agent(
    name="Avaliador de Potencial",
    role="Classificacao de ideias por potencial de sucesso",
    goal="Definir o potencial de sucesso das ideias de startup baseado nos dados específicos fornecidos.",
    backstory="""Avaliador de potencial como Alto, Médio ou Baixo.
    Analiso ESPECIFICAMENTE os dados da startup fornecidos:
    - Alto: Mercado grande e crescente, problema real e validado, solução inovadora, modelo de negócio escalável, poucos competidores diretos
    - Médio: Mercado adequado, problema relevante, solução competitiva, modelo viável, competição moderada, necessita validação adicional
    - Baixo: Mercado pequeno ou saturado, problema não validado, solução similar a existentes, modelo difícil de escalar, muita competição estabelecida
    
    IMPORTANTE: Sempre considero o título, descrição, problema que resolve, público-alvo e modelo de negócio específicos da startup.""",
    llm=llm
)

AG3 = Agent(
    name="Analista de Mercado",
    role="Análise competitiva e de mercado",
    goal="Fornecer análise detalhada do mercado e competição baseada nos dados específicos da startup.",
    backstory="""Especialista em pesquisa de mercado e análise competitiva.
    Para cada ideia ESPECÍFICA fornecida, devo:
    1. Identificar principais competidores e soluções existentes no mercado baseado na descrição e problema que resolve
    2. Avaliar tamanho do mercado, crescimento e oportunidades para o público-alvo específico
    3. Mapear gaps não atendidos e oportunidades de diferenciação baseado no modelo de negócio
    4. Identificar barreiras de entrada e vantagens competitivas possíveis
    5. Apontar riscos de mercado, ameaças e tendências do setor específico
    6. Validar se existe demanda real pelo produto/serviço proposto
    
    IMPORTANTE: Sempre uso os dados específicos da startup (título, descrição, empreendedor, problema, público, modelo) na análise.""",
    llm=llm
)

AG4 = Agent(
    name="Estrategista de Execução",
    role="Planejamento estratégico de execução",
    goal="Criar roadmap e estratégia de execução personalizada para a startup específica.",
    backstory="""Consultor estratégico especializado em planejamento de startups.
    Minhas responsabilidades incluem criar um plano ESPECÍFICO baseado nos dados fornecidos:
    1. Definir perfil ideal da equipe fundadora e competências necessárias para o modelo de negócio específico
    2. Estimar investimento necessário baseado no tipo de solução e mercado
    3. Criar cronograma de desenvolvimento com milestones claros para o problema específico
    4. Mapear canais de aquisição de clientes mais eficazes para o público-alvo específico
    5. Propor modelo de receita otimizado e estratégia de pricing baseada no modelo de negócio
    6. Recomendar próximos passos (MVP, validação, testes de mercado) específicos
    7. Identificar riscos de execução e planos de contingência
    
    IMPORTANTE: Sempre personalizo as recomendações baseado no título, descrição, empreendedor, problema, público-alvo e modelo de negócio específicos.""",
    llm=llm
)

AG5 = Agent(
    name="Gerador de Business Plan",
    role="Criação de business plan completo personalizado",
    goal="Gerar documentação completa de business plan e pitch deck usando TODOS os dados específicos da startup.",
    backstory="""Especialista em business plans e pitch decks para startups.
    Minha documentação deve ser COMPLETAMENTE PERSONALIZADA usando os dados específicos fornecidos:
    1. Executive summary com o título real, descrição real e proposta de valor específica
    2. Análise de mercado e competição detalhada baseada no problema e público-alvo reais
    3. Modelo de negócio e estratégia de receita baseados no modelo específico fornecido
    4. Projeções financeiras realistas (3-5 anos) adequadas ao tipo de negócio
    5. Estratégia de go-to-market e canais de aquisição para o público-alvo específico
    6. Time necessário e estrutura organizacional adequada ao empreendedor
    7. Cronograma de execução e milestones importantes para o problema específico
    8. Riscos identificados e planos de contingência
    9. Recomendações finais sobre viabilidade
    
    CRÍTICO: NUNCA uso placeholders genéricos como [Título da Startup]. SEMPRE substituo pelos dados reais:
    - {titulo} para o título real
    - {descricao} para a descrição real
    - {empreendedor} para o nome real do empreendedor
    - {problema_resolve} para o problema específico
    - {publico_alvo} para o público-alvo específico
    - {modelo_negocio} para o modelo de negócio específico
    
    O documento deve ser profissional e específico, adequado para apresentação a investidores.""",
    llm=llm
)

# Criar as tasks com expected_output
Task_AG1 = Task(
    description="""Analise a startup específica com os seguintes dados:
    - Título: {titulo}
    - Descrição: {descricao}
    - Empreendedor: {empreendedor}
    - Problema que resolve: {problema_resolve}
    - Público-alvo: {publico_alvo}
    - Modelo de negócio: {modelo_negocio}
    
    Classifique esta startup ESPECÍFICA em um dos verticais: FinTech, EdTech, HealthTech, E-commerce, SaaS, Marketplace, Gaming, Social.
    
    Use o formato exato:
    Thought: Analisando especificamente a startup "{titulo}" que resolve "{problema_resolve}" para "{publico_alvo}"...
    Final Answer: [VERTICAL] - Justificativa baseada nos dados específicos da startup""",
    expected_output="VERTICAL (em maiúsculo) seguido de justificativa específica baseada nos dados reais",
    agent=AG1
)

Task_AG2 = Task(
    description="""Avalie o potencial da startup específica:
    - Título: {titulo}
    - Descrição: {descricao}
    - Empreendedor: {empreendedor}
    - Problema que resolve: {problema_resolve}
    - Público-alvo: {publico_alvo}
    - Modelo de negócio: {modelo_negocio}
    
    Defina o potencial desta startup ESPECÍFICA como Alto, Médio ou Baixo.
    
    Use o formato exato:
    Thought: Considerando especificamente que "{titulo}" resolve "{problema_resolve}" para "{publico_alvo}" com modelo "{modelo_negocio}"...
    Final Answer: [POTENCIAL] - Justificativa específica com score de 1-10 baseado nos dados reais""",
    expected_output="POTENCIAL (em maiúsculo) seguido de justificativa específica e score",
    agent=AG2
)

Task_AG3 = Task(
    description="""Faça uma análise de mercado detalhada da startup específica:
    - Título: {titulo}
    - Descrição: {descricao}
    - Empreendedor: {empreendedor}
    - Problema que resolve: {problema_resolve}
    - Público-alvo: {publico_alvo}
    - Modelo de negócio: {modelo_negocio}
    
    Use o formato exato:
    Thought: Analisando o mercado específico para "{titulo}" que atende "{publico_alvo}" resolvendo "{problema_resolve}"...
    Final Answer:
    Tamanho do Mercado: [estimativa específica para o público-alvo e problema]
    Principais Concorrentes: [competidores específicos para este tipo de solução]
    Diferencial Competitivo: [vantagens únicas baseadas na descrição específica]
    Barreiras de Entrada: [dificuldades específicas para este modelo de negócio]
    Oportunidades: [gaps específicos identificados para este público]
    Ameaças: [riscos específicos para este setor e modelo]""",
    expected_output="Análise de mercado estruturada com dados específicos da startup",
    agent=AG3
)

Task_AG4 = Task(
    description="""Crie um plano de execução estratégico para a startup específica:
    - Título: {titulo}
    - Descrição: {descricao}
    - Empreendedor: {empreendedor}
    - Problema que resolve: {problema_resolve}
    - Público-alvo: {publico_alvo}
    - Modelo de negócio: {modelo_negocio}
    
    Use o formato exato:
    Thought: Desenvolvendo estratégia específica para "{empreendedor}" executar "{titulo}" com modelo "{modelo_negocio}"...
    Final Answer:
    Perfil da Equipe: [competências específicas necessárias para este modelo de negócio]
    Investimento Necessário: [estimativa específica baseada no tipo de solução]
    Tempo de Desenvolvimento: [cronograma específico para este problema]
    Milestones: [marcos específicos para esta startup]
    Canais de Aquisição: [estratégias específicas para este público-alvo]
    Modelo de Receita: [detalhamento específico do modelo de negócio]
    Status Recomendado: [MVP, Validação, Investimento, Pivot, Abandon]
    Observações: [considerações específicas para esta startup]""",
    expected_output="Plano de execução personalizado para a startup específica",
    agent=AG4
)

Task_AG5 = Task(
    description="""Gere um business plan completo PERSONALIZADO para a startup específica:
    - Título: {titulo}
    - Descrição: {descricao}
    - Empreendedor: {empreendedor}
    - Problema que resolve: {problema_resolve}
    - Público-alvo: {publico_alvo}
    - Modelo de negócio: {modelo_negocio}
    - ID: {ID}
    
    CRÍTICO: Use SEMPRE os dados reais, NUNCA placeholders genéricos!
    
    Use o formato exato:
    Thought: Consolidando informações específicas para business plan de "{titulo}" do empreendedor "{empreendedor}"...
    Final Answer:
    === BUSINESS PLAN DA STARTUP ===
    ## Markdown:
    ```markdown
    # Startup #{ID} - {titulo}
    
    ## Executive Summary
    {titulo} é uma startup criada por {empreendedor} que resolve {problema_resolve} para {publico_alvo} através de {modelo_negocio}. [Continuar com resumo específico baseado na descrição]
    
    ## Vertical de Mercado
    [Vertical específico] - [Justificativa baseada no problema e público específicos]
    
    ## Potencial de Sucesso
    [Potencial específico] - [Justificativa baseada nos dados reais da startup]
    
    ## Análise de Mercado
    - Tamanho do Mercado: [estimativa específica para o público-alvo]
    - Concorrentes: [competidores específicos para este problema]
    - Diferencial: [vantagem específica baseada na descrição]
    
    ## Estratégia de Execução
    - Equipe: [perfil específico para {empreendedor} e este modelo]
    - Investimento: [capital específico para este tipo de solução]
    - Timeline: [cronograma específico para este problema]
    - Receita: [detalhamento específico do {modelo_negocio}]
    
    ## Recomendação Final
    [Recomendação específica sobre viabilidade e próximos passos para {titulo}]
    ```
    
    ## HTML (com diagrama Mermaid personalizado):
    ```html
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pitch Deck - {titulo}</title>
        <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
        <style>
            body {{ font-family: 'Segoe UI', sans-serif; margin: 0; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #333; }}
            .container {{ max-width: 1200px; margin: 0 auto; background-color: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); }}
            h1 {{ color: #2c3e50; text-align: center; margin-bottom: 10px; font-size: 2.5em; }}
            .subtitle {{ text-align: center; color: #7f8c8d; font-size: 1.2em; margin-bottom: 40px; }}
            .section {{ margin: 30px 0; padding: 25px; border-radius: 10px; background: #f8f9fa; border-left: 5px solid #3498db; }}
            .section h2 {{ color: #2c3e50; margin-top: 0; font-size: 1.8em; }}
            .mermaid {{ display: flex; justify-content: center; margin: 30px 0; background: white; padding: 20px; border-radius: 10px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Pitch Deck - {titulo}</h1>
            <div class="subtitle">Criado por {empreendedor} • {modelo_negocio}</div>
            
            <div class="section">
                <h2>📊 Executive Summary</h2>
                <p><strong>{titulo}</strong> foi criada por <strong>{empreendedor}</strong> para resolver <strong>{problema_resolve}</strong> atendendo <strong>{publico_alvo}</strong>.</p>
                <p><strong>Descrição:</strong> {descricao}</p>
                <p><strong>Modelo de Negócio:</strong> {modelo_negocio}</p>
            </div>
            
            <div class="section">
                <h2>🎯 Análise de Mercado Específica</h2>
                <p><strong>Problema Específico:</strong> {problema_resolve}</p>
                <p><strong>Público-Alvo:</strong> {publico_alvo}</p>
            </div>
            
            <div class="section">
                <h2>🚀 Estratégia de Execução Personalizada</h2>
                <p><strong>Empreendedor:</strong> {empreendedor}</p>
                <p><strong>Modelo de Receita:</strong> {modelo_negocio}</p>
            </div>
            
            <div class="footer">
                <p>© 2025 StartupFlow - Pitch Deck Personalizado para {titulo} por {empreendedor}</p>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
        <script>mermaid.initialize({{ startOnLoad: true }});</script>
    </body>
    </html>
    ```
    """,
    expected_output="Business plan completo personalizado em Markdown e HTML com dados específicos da startup",
    agent=AG5
)

def processar_startups():
    # Definir db_params no início da função para evitar erro de escopo
    db_params = None
    
    try:
        # Verificar se a variável de ambiente está configurada
        if not NEON_DB_URL:
            logger.error("Erro: NEON_DB_URL não está configurado no arquivo .env")
            return
            
        # Obter a URL do banco de dados e configurar db_params no início
        db_url = NEON_DB_URL
        url = urlparse(db_url)
        db_params = {
            'dbname': url.path[1:],
            'user': url.username,
            'password': url.password,
            'host': url.hostname,
            'port': url.port
        }
            
        logger.info(f"Tentando conectar ao banco de dados...")
        # Conectar ao NeonDB
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        logger.info("Conexão com o banco de dados estabelecida com sucesso.")
        
        # Verificar se há startups submetidas
        cur.execute("SELECT COUNT(*) FROM ideias_startup WHERE status = 'Submetida';")
        total_submetidas = cur.fetchone()[0]
        
        if total_submetidas == 0:
            logger.info("Info: Nenhuma startup submetida encontrada")
            return

        logger.info(f"Estatísticas: Total de startups submetidas: {total_submetidas}")
        
        # Criar a equipe com configuracoes mais robustas
        crew = Crew(
            agents=[AG1, AG2, AG3, AG4, AG5],
            tasks=[Task_AG1, Task_AG2, Task_AG3, Task_AG4, Task_AG5],
            verbose=True,
            memory=False,  # Desabilitar memória para evitar o erro do ChromaDB
            process=Process.sequential,  # Processo sequencial para evitar conflitos
            max_iter=3,  # Limitar iterações para evitar loops infinitos
            max_execution_time=300  # Timeout de 5 minutos por startup
        )

        # Processar cada startup
        cur.execute("SELECT id, titulo, descricao, empreendedor, problema_resolve, publico_alvo, modelo_negocio FROM ideias_startup WHERE status = 'Submetida';")
        startups = cur.fetchall()
        
        for startup in startups:
            startup_id = startup[0]
            startup_data = {
                "titulo": startup[1],
                "descricao": startup[2],
                "empreendedor": startup[3],
                "problema_resolve": startup[4] if startup[4] else "",
                "publico_alvo": startup[5] if startup[5] else "",
                "modelo_negocio": startup[6] if startup[6] else "",
                "ID": str(startup_id)
            }
            
            logger.info(f"\nINICIANDO STARTUP {startup_id}")
            logger.info(f"TITULO: {startup_data['titulo']}")
            logger.info(f"DESCRICAO: {startup_data['descricao']}")
            logger.info(f"EMPREENDEDOR: {startup_data['empreendedor']}")
            logger.info(f"PROBLEMA: {startup_data['problema_resolve']}")
            logger.info(f"PUBLICO: {startup_data['publico_alvo']}")
            logger.info(f"MODELO: {startup_data['modelo_negocio']}")
            
            try:
                # Executar com timeout de 3 minutos
                try:
                    logger.info("Iniciando processamento com CrewAI...")
                    resultado = crew.kickoff(
                        inputs=startup_data
                    )
                    logger.info("CrewAI concluiu o processamento com sucesso.")
                except Exception as e:
                    import traceback
                    logger.error(f"Erro no processamento do CrewAI: {str(e)}")
                    logger.error(f"Tipo do erro: {type(e).__name__}")
                    logger.error(traceback.format_exc())
                    
                    # Log específico para problemas de modelo
                    if "model" in str(e).lower() or "gpt" in str(e).lower():
                        logger.error("ERRO RELACIONADO AO MODELO GPT-5:")
                        logger.error("Possíveis causas:")
                        logger.error("1. GPT-5 pode não estar disponível na sua conta")
                        logger.error("2. Modelo pode estar em beta limitado")
                        logger.error("3. Problema de rate limiting")
                        logger.error("4. Erro de autenticação específico do modelo")
                    
                    raise
                logger.info(f"Processamento da startup {startup_id} concluido!")
                logger.info(f"Resultado final da startup: {resultado}")
                
                # Iniciar uma nova transação para cada bug
                conn.rollback()  # Garantir que não há transação pendente
                
                # Criar uma nova conexão para cada operação para evitar problemas de transação abortada
                
                # Obter a URL do banco de dados do ambiente
                db_url = os.environ.get('NEON_DB_URL')
                if not db_url:
                    logger.error("NEON_DB_URL não está definida no ambiente")
                    raise ValueError("NEON_DB_URL não está definida no ambiente")
                    
                # Analisar a URL do banco de dados
                url = urlparse(db_url)
                db_params = {
                    'dbname': url.path[1:],
                    'user': url.username,
                    'password': url.password,
                    'host': url.hostname,
                    'port': url.port
                }
                
                # Processar resultados dos agentes
                try:
                    # Resultado do AG1 (Classificador de Vertical)
                    vertical_match = None
                    for linha in str(resultado).split('\n'):
                        if '[VERTICAL]' in linha or 'FINTECH' in linha.upper() or 'EDTECH' in linha.upper() or 'HEALTHTECH' in linha.upper() or 'E-COMMERCE' in linha.upper() or 'SAAS' in linha.upper() or 'MARKETPLACE' in linha.upper() or 'GAMING' in linha.upper() or 'SOCIAL' in linha.upper():
                            vertical_match = linha
                            break
                    
                    if vertical_match:
                        # Extrair vertical e justificativa
                        vertical_parts = vertical_match.split('-', 1)
                        vertical = vertical_parts[0].replace('[VERTICAL]', '').strip()
                        if not vertical:
                            for vert in ['FINTECH', 'EDTECH', 'HEALTHTECH', 'E-COMMERCE', 'SAAS', 'MARKETPLACE', 'GAMING', 'SOCIAL']:
                                if vert in vertical_match.upper():
                                    vertical = vert
                                    break
                        justificativa = vertical_parts[1].strip() if len(vertical_parts) > 1 else ''
                        
                        # Usar a função de normalização para vertical
                        vertical_normalizado = normalizar_vertical(vertical)
                        logger.info(f"Vertical normalizado: '{vertical_normalizado}'")
                        
                        # Inserir na tabela classificacao_vertical
                        try:
                            # Criar uma nova conexão para esta operação
                            with psycopg2.connect(**db_params) as conn_vertical, conn_vertical.cursor() as cur_vertical:
                                cur_vertical.execute(
                                    "INSERT INTO classificacao_vertical (ideia_id, vertical, justificativa) VALUES (%s, %s, %s)",
                                    (startup_id, vertical_normalizado, justificativa)
                                )
                                conn_vertical.commit()
                                logger.info(f"Classificacao de vertical salva: {vertical_normalizado}")
                        except Exception as e:
                            logger.error(f"Erro ao inserir na tabela classificacao_vertical: {str(e)}")
                            # Continuar com as próximas operações
                        # Já logado dentro do bloco try
                    
                    # Resultado do AG2 (Avaliador de Potencial)
                    potencial_match = None
                    for linha in str(resultado).split('\n'):
                        if '[POTENCIAL]' in linha or 'ALTO' in linha.upper() or 'MÉDIO' in linha.upper() or 'BAIXO' in linha.upper():
                            potencial_match = linha
                            break
                    
                    if potencial_match:
                        # Extrair potencial e score
                        potencial_parts = potencial_match.split('-', 1)
                        potencial = potencial_parts[0].replace('[POTENCIAL]', '').strip()
                        if not potencial:
                            for pot in ['ALTO', 'MÉDIO', 'BAIXO']:
                                if pot in potencial_match.upper():
                                    potencial = pot
                                    break
                        justificativa = potencial_parts[1].strip() if len(potencial_parts) > 1 else ''
                        
                        # Extrair score se existir na justificativa
                        score = 5  # valor padrão
                        import re
                        score_match = re.search(r'score.*?([0-9]+)', justificativa.lower())
                        if score_match:
                            score = min(10, max(1, int(score_match.group(1))))
                        
                        # Usar a função de normalização para potencial
                        potencial_normalizado = normalizar_potencial(potencial)
                        logger.info(f"Potencial normalizado: '{potencial_normalizado}'")
                                
                        # Inserir na tabela classificacao_potencial
                        try:
                            # Criar uma nova conexão para esta operação
                            with psycopg2.connect(**db_params) as conn_potencial, conn_potencial.cursor() as cur_potencial:
                                cur_potencial.execute(
                                    "INSERT INTO classificacao_potencial (ideia_id, potencial, score_viabilidade, fatores_positivos) VALUES (%s, %s, %s, %s)",
                                    (startup_id, potencial_normalizado, score, justificativa)
                                )
                                conn_potencial.commit()
                                logger.info(f"Classificacao de potencial salva: {potencial_normalizado} (Score: {score})")
                        except Exception as e:
                            logger.error(f"Erro ao inserir na tabela classificacao_potencial: {str(e)}")
                            # Tentar novamente com um valor fixo literal
                            try:
                                with psycopg2.connect(**db_params) as conn_retry, conn_retry.cursor() as cur_retry:
                                    cur_retry.execute(
                                        "INSERT INTO classificacao_potencial (ideia_id, potencial, score_viabilidade) VALUES (%s, 'Médio', 5)",
                                        (startup_id,)
                                    )
                                    conn_retry.commit()
                                    logger.info("Classificacao de potencial salva com valor padrão 'Médio'")
                            except Exception as retry_error:
                                logger.error(f"Erro ao inserir na tabela classificacao_potencial (retry): {str(retry_error)}")
                            # Continuar com as próximas operações
                        # Já logado dentro do bloco try
                    
                    # Resultado do AG3 (Analista de Mercado)
                    tamanho_mercado = ''
                    principais_concorrentes = ''
                    diferencial_competitivo = ''
                    barreiras_entrada = ''
                    oportunidades = ''
                    ameacas = ''
                    
                    linhas = str(resultado).split('\n')
                    for i, linha in enumerate(linhas):
                        if 'Tamanho do Mercado:' in linha and i+1 < len(linhas):
                            tamanho_mercado = linhas[i].replace('Tamanho do Mercado:', '').strip()
                        elif 'Principais Concorrentes:' in linha and i+1 < len(linhas):
                            principais_concorrentes = linhas[i].replace('Principais Concorrentes:', '').strip()
                        elif 'Diferencial Competitivo:' in linha and i+1 < len(linhas):
                            diferencial_competitivo = linhas[i].replace('Diferencial Competitivo:', '').strip()
                        elif 'Barreiras de Entrada:' in linha and i+1 < len(linhas):
                            barreiras_entrada = linhas[i].replace('Barreiras de Entrada:', '').strip()
                        elif 'Oportunidades:' in linha and i+1 < len(linhas):
                            oportunidades = linhas[i].replace('Oportunidades:', '').strip()
                        elif 'Ameaças:' in linha and i+1 < len(linhas):
                            ameacas = linhas[i].replace('Ameaças:', '').strip()
                    
                    # Inserir na tabela analise_mercado
                    try:
                        with psycopg2.connect(**db_params) as conn_mercado, conn_mercado.cursor() as cur_mercado:
                            cur_mercado.execute(
                                "INSERT INTO analise_mercado (ideia_id, tamanho_mercado, principais_concorrentes, diferencial_competitivo, barreiras_entrada, oportunidades, ameacas) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                                (startup_id, tamanho_mercado, principais_concorrentes, diferencial_competitivo, barreiras_entrada, oportunidades, ameacas)
                            )
                            conn_mercado.commit()
                            logger.info("Análise de mercado salva com sucesso")
                    except Exception as e:
                        logger.error(f"Erro ao inserir na tabela analise_mercado: {str(e)}")
                    
                    # Armazenar informações da análise de mercado no relatório final
                    analise_mercado_texto = f"""Análise de Mercado:
- Tamanho do Mercado: {tamanho_mercado or 'Não especificado'}
- Principais Concorrentes: {principais_concorrentes}
- Diferencial Competitivo: {diferencial_competitivo}
- Barreiras de Entrada: {barreiras_entrada}
- Oportunidades: {oportunidades}
- Ameaças: {ameacas}
"""
                    
                    logger.info("Informações da análise de mercado processadas")
                    
                    # Resultado do AG4 (Estrategista de Execução)
                    perfil_equipe = ''
                    investimento_necessario = ''
                    tempo_desenvolvimento = ''
                    milestones = ''
                    canais_aquisicao = ''
                    modelo_receita = ''
                    status_recomendado = 'MVP'
                    
                    for linha in str(resultado).split('\n'):
                        if 'Perfil da Equipe:' in linha:
                            perfil_equipe = linha.replace('Perfil da Equipe:', '').strip()
                        elif 'Investimento Necessário:' in linha:
                            investimento_necessario = linha.replace('Investimento Necessário:', '').strip()
                        elif 'Tempo de Desenvolvimento:' in linha:
                            tempo_desenvolvimento = linha.replace('Tempo de Desenvolvimento:', '').strip()
                        elif 'Milestones:' in linha:
                            milestones = linha.replace('Milestones:', '').strip()
                        elif 'Canais de Aquisição:' in linha:
                            canais_aquisicao = linha.replace('Canais de Aquisição:', '').strip()
                        elif 'Modelo de Receita:' in linha:
                            modelo_receita = linha.replace('Modelo de Receita:', '').strip()
                        elif 'Status Recomendado:' in linha:
                            status_str = linha.replace('Status Recomendado:', '').strip()
                            if any(word in status_str.upper() for word in ['MVP', 'VALIDAÇÃO', 'INVESTIMENTO', 'PIVOT', 'ABANDON']):
                                status_recomendado = normalizar_status_execucao(status_str)
                    
                    # Inserir na tabela plano_execucao
                    if perfil_equipe or investimento_necessario:
                        try:
                            # Criar uma nova conexão para esta operação
                            with psycopg2.connect(**db_params) as conn_execucao, conn_execucao.cursor() as cur_execucao:
                                cur_execucao.execute(
                                    "INSERT INTO plano_execucao (ideia_id, perfil_equipe_ideal, investimento_necessario, tempo_desenvolvimento, milestones, canais_aquisicao, modelo_receita, responsavel, status) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                                    (startup_id, perfil_equipe, investimento_necessario, tempo_desenvolvimento, milestones, canais_aquisicao, modelo_receita, startup_data['empreendedor'], status_recomendado)
                                )
                                conn_execucao.commit()
                                logger.info(f"Plano de execução salvo: {status_recomendado}")
                        except Exception as e:
                            logger.error(f"Erro ao inserir na tabela plano_execucao: {str(e)}")
                            # Tentar novamente com um valor fixo literal
                            try:
                                with psycopg2.connect(**db_params) as conn_retry, conn_retry.cursor() as cur_retry:
                                    cur_retry.execute(
                                        "INSERT INTO plano_execucao (ideia_id, responsavel, status) VALUES (%s, %s, 'MVP')",
                                        (startup_id, startup_data['empreendedor'])
                                    )
                                    conn_retry.commit()
                                    logger.info("Plano de execução salvo com valores padrão")
                            except Exception as retry_error:
                                logger.error(f"Erro ao inserir na tabela plano_execucao (retry): {str(retry_error)}")
                            # Continuar com as próximas operações
                        # Já logado dentro do bloco try
                    
                    # Resultado do AG5 (Gerador de Business Plan)
                    # Extrair business plan Markdown e HTML
                    markdown_doc = ''
                    html_doc = ''
                    
                    markdown_start = str(resultado).find('```markdown')
                    markdown_end = str(resultado).find('```', markdown_start + 10) if markdown_start > -1 else -1
                    
                    if markdown_start > -1 and markdown_end > -1:
                        markdown_doc = str(resultado)[markdown_start + 10:markdown_end].strip()
                    
                    html_start = str(resultado).find('## HTML')
                    if html_start > -1:
                        html_doc = str(resultado)[html_start:].strip()
                    
                    # Salvar o business plan Markdown diretamente na raiz do projeto
                    if markdown_doc:
                        # Salvar o business plan Markdown na raiz
                        business_plan_file = f'startup_{startup_id}_business_plan.md'
                        with open(business_plan_file, 'w', encoding='utf-8') as f:
                            f.write(markdown_doc)
                        logger.info(f"Business Plan Markdown salvo em: {business_plan_file}")
                        
                        # Atualizar Pinecone com o business plan processado
                        logger.info(f"🔄 Atualizando Pinecone para startup {startup_id}...")
                        if atualizar_pinecone_startup(startup_id, markdown_doc):
                            logger.info(f"✅ Pinecone atualizado com sucesso para startup {startup_id}")
                        else:
                            logger.warning(f"⚠️  Falha ao atualizar Pinecone para startup {startup_id}")
                        
                        # Salvar o HTML se existir
                        if html_doc:
                            html_file = f'startup_{startup_id}_pitch_deck.html'
                            # Extrair apenas o conteúdo HTML
                            html_content_start = html_doc.find('```html')
                            html_content_end = html_doc.find('```', html_content_start + 7) if html_content_start > -1 else -1
                            
                            if html_content_start > -1 and html_content_end > -1:
                                html_content = html_doc[html_content_start + 7:html_content_end].strip()
                                with open(html_file, 'w', encoding='utf-8') as f:
                                    f.write(html_content)
                                logger.info(f"Pitch Deck HTML salvo em: {html_file}")
                    
                    # Inserir na tabela business_plan
                    if markdown_doc or html_doc:
                        # Combinar markdown_doc com analise_mercado_texto
                        business_plan_completo = markdown_doc
                        if 'analise_mercado_texto' in locals() and analise_mercado_texto:
                            business_plan_completo += "\n\n" + analise_mercado_texto
                            
                        # Limitar o tamanho do business plan para evitar erros
                        business_plan_limpo = business_plan_completo  # Preservar formatação Markdown/HTML
                        business_plan_limitado = business_plan_limpo[:65000] if business_plan_limpo else "Business plan não gerado"
                        
                        # Determinar se a startup é viável baseado no potencial
                        viavel = False
                        if 'potencial_normalizado' in locals():
                            viavel = potencial_normalizado == 'Alto'
                        
                        try:
                            # Criar uma nova conexão para esta operação
                            with psycopg2.connect(**db_params) as conn_business, conn_business.cursor() as cur_business:
                                cur_business.execute(
                                    "INSERT INTO business_plan (ideia_id, pitch_deck, viavel, recomendacao_final) VALUES (%s, %s, %s, %s)",
                                    (startup_id, business_plan_limitado, viavel, f"Startup classificada como potencial {potencial_normalizado if 'potencial_normalizado' in locals() else 'Médio'}")
                                )
                                conn_business.commit()
                                logger.info("Business plan da startup salvo")
                        except Exception as e:
                            logger.error(f"Erro ao inserir na tabela business_plan: {str(e)}")
                            # Continuar com as próximas operações
                        # Já logado dentro do bloco try
                        
                        # 🔄 ATUALIZAR PINECONE COM O BUSINESS PLAN PROCESSADO
                        logger.info(f"Atualizando Pinecone para startup {startup_id}...")
                        try:
                            sucesso_pinecone = atualizar_pinecone_startup(startup_id, business_plan_limitado)
                            if sucesso_pinecone:
                                logger.info(f"✅ Pinecone atualizado com sucesso para startup {startup_id}")
                            else:
                                logger.warning(f"⚠️ Falha na atualização do Pinecone para startup {startup_id}")
                        except Exception as pinecone_error:
                            logger.error(f"❌ Erro ao atualizar Pinecone para startup {startup_id}: {str(pinecone_error)}")
                            # Não interromper o fluxo por erro no Pinecone
                
                except Exception as e:
                    logger.error(f"Erro ao salvar resultados no banco: {str(e)}")
                
                # Atualizar status da startup para 'Processado'
                try:
                    with psycopg2.connect(**db_params) as conn_update, conn_update.cursor() as cur_update:
                        cur_update.execute(
                            "UPDATE ideias_startup SET status = 'Processado' WHERE id = %s",
                            (startup_id,)
                        )
                        conn_update.commit()
                        logger.info(f"Startup {startup_id} marcada como 'Processado'")
                except Exception as e:
                    logger.error(f"Erro ao atualizar status da startup: {str(e)}")
                
                # Commit da transação se tudo correu bem
                try:
                    conn.commit()
                    logger.info(f"Transação concluída com sucesso para a startup {startup_id}")
                except Exception as e:
                    logger.error(f"Erro ao fazer commit da transação: {str(e)}")
                    conn.rollback()
            except Exception as e:
                logger.error(f"Erro no processamento da startup {startup_id}: {str(e)}")
                logger.error("Marcando startup como 'Rejeitada' para revisao manual")
                
                # Rollback da transação em caso de erro
                conn.rollback()
                
                # Marcar a startup como 'Rejeitada' para revisao manual em uma nova transação
                try:
                    # Usar uma nova conexão para esta operação
                    with psycopg2.connect(**db_params) as conn_erro, conn_erro.cursor() as cur_erro:
                        cur_erro.execute(
                            "UPDATE ideias_startup SET status = 'Rejeitada' WHERE id = %s",
                            (startup_id,)
                        )
                        conn_erro.commit()
                        logger.info(f"Startup {startup_id} marcada como 'Rejeitada' para revisao manual")
                except Exception as update_error:
                    logger.error(f"Erro ao marcar startup como 'Rejeitada': {str(update_error)}")

    except Exception as e:
        import traceback
        logger.error(f"Erro na conexao com o banco de dados: {str(e)}")
        logger.error(traceback.format_exc())
        logger.error("Verifique as configuracoes de conexao no arquivo .env")
    
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()
        logger.info("Processamento finalizado")

def limpar_texto(texto):
    """Remove tags HTML, espaços extras e caracteres especiais de um texto."""
    if not texto:
        return ""
    
    # Remover tags HTML
    texto_sem_html = re.sub(r'<[^>]+>', '', texto)
    
    # Remover espaços extras
    texto_limpo = re.sub(r'\s+', ' ', texto_sem_html).strip()
    
    # Decodificar entidades HTML
    texto_final = html.unescape(texto_limpo)
    
    # Remover caracteres especiais e marcadores de lista
    texto_final = re.sub(r'^[-\*\•\·\⁃\‣\⁌\⁍\⦾\⦿\⁃] *', '', texto_final)
    
    return texto_final

def normalizar_prioridade(prioridade):
    """Normaliza o valor de prioridade para um dos valores permitidos na tabela."""
    # Valores permitidos conforme constraint REAL: Urgente, Intermediário, Normal
    valores_permitidos = ['Urgente', 'Intermediário', 'Normal']
    
    # Limpar o texto primeiro
    prioridade_limpa = limpar_texto(prioridade).strip()
    
    # Verificar correspondência exata
    if prioridade_limpa in valores_permitidos:
        return prioridade_limpa
    
    # Normalizar baseado em substrings
    prioridade_lower = prioridade_limpa.lower()
    if 'crític' in prioridade_lower or 'urgent' in prioridade_lower or 'grave' in prioridade_lower or 'alto' in prioridade_lower:
        return 'Urgente'
    elif 'médio' in prioridade_lower or 'medio' in prioridade_lower or 'intermedi' in prioridade_lower:
        return 'Intermediário'
    elif 'menor' in prioridade_lower or 'baixo' in prioridade_lower or 'normal' in prioridade_lower or 'low' in prioridade_lower:
        return 'Normal'
    else:
        return 'Normal'

def normalizar_status(status):
    """Normaliza o valor de status para um dos valores permitidos na tabela."""
    # Valores permitidos conforme constraint REAL: Em andamento, Aguardando resposta, Concluído
    valores_permitidos = ['Em andamento', 'Aguardando resposta', 'Concluído']
    
    # Limpar o texto primeiro
    status_limpo = limpar_texto(status).strip()
    
    # Verificar correspondência exata
    if status_limpo in valores_permitidos:
        return status_limpo
    
    # Normalizar baseado em substrings
    status_lower = status_limpo.lower()
    if 'atri' in status_lower or 'aberto' in status_lower or 'desen' in status_lower or 'progr' in status_lower or 'andament' in status_lower:
        return 'Em andamento'
    elif 'aguard' in status_lower or 'review' in status_lower or 'revis' in status_lower or 'resposta' in status_lower:
        return 'Aguardando resposta'
    elif 'conclu' in status_lower or 'resolv' in status_lower or 'finaliz' in status_lower or 'fecha' in status_lower:
        return 'Concluído'
    else:
        return 'Em andamento'

def normalizar_vertical(vertical):
    """Normaliza o valor de vertical para um dos valores permitidos na tabela."""
    # Valores permitidos exatos conforme a restrição CHECK na tabela
    valores_permitidos = ['FinTech', 'EdTech', 'HealthTech', 'E-commerce', 'SaaS', 'Marketplace', 'Gaming', 'Social']
    
    # Limpar o texto primeiro
    vertical_limpo = limpar_texto(vertical).strip()
    
    # Verificar correspondência exata
    if vertical_limpo in valores_permitidos:
        return vertical_limpo
    
    # Normalizar baseado em substrings
    vertical_lower = vertical_limpo.lower()
    for valor in valores_permitidos:
        if valor.lower() in vertical_lower:
            return valor
    
    # Se não encontrar correspondência, usar um valor padrão seguro
    return 'SaaS'

def normalizar_potencial(potencial):
    """Normaliza o valor de potencial para um dos valores permitidos na tabela."""
    # Valores permitidos conforme constraint: Alto, Médio, Baixo
    valores_permitidos = ['Alto', 'Médio', 'Baixo']
    
    # Limpar o texto primeiro
    potencial_limpo = limpar_texto(potencial).strip()
    
    # Verificar correspondência exata
    if potencial_limpo in valores_permitidos:
        return potencial_limpo
    
    # Normalizar baseado em substrings
    potencial_lower = potencial_limpo.lower()
    if 'alto' in potencial_lower or 'high' in potencial_lower or 'excelente' in potencial_lower:
        return 'Alto'
    elif 'médio' in potencial_lower or 'medio' in potencial_lower or 'medium' in potencial_lower:
        return 'Médio'
    elif 'baixo' in potencial_lower or 'low' in potencial_lower or 'fraco' in potencial_lower:
        return 'Baixo'
    else:
        return 'Médio'

def normalizar_status_execucao(status):
    """Normaliza o valor de status de execução para um dos valores permitidos na tabela."""
    # Valores permitidos conforme constraint: MVP, Validação, Investimento, Pivot, Abandon
    valores_permitidos = ['MVP', 'Validação', 'Investimento', 'Pivot', 'Abandon']
    
    # Limpar o texto primeiro
    status_limpo = limpar_texto(status).strip()
    
    # Verificar correspondência exata
    if status_limpo in valores_permitidos:
        return status_limpo
    
    # Normalizar baseado em substrings
    status_lower = status_limpo.lower()
    if 'mvp' in status_lower or 'mínimo' in status_lower or 'protótipo' in status_lower:
        return 'MVP'
    elif 'validação' in status_lower or 'validacao' in status_lower or 'teste' in status_lower:
        return 'Validação'
    elif 'investimento' in status_lower or 'capital' in status_lower or 'funding' in status_lower:
        return 'Investimento'
    elif 'pivot' in status_lower or 'mudar' in status_lower or 'alterar' in status_lower:
        return 'Pivot'
    elif 'abandon' in status_lower or 'abandonar' in status_lower or 'desistir' in status_lower:
        return 'Abandon'
    else:
        return 'MVP'

def atualizar_pinecone_startup(startup_id, business_plan_markdown):
    """Atualiza o Pinecone com o business plan processado de uma startup específica"""
    try:
        # Inicializar conexões
        pc = pinecone.Pinecone(api_key=PINECONE_API_KEY)
        index = pc.Index("startupflow")
        client = OpenAI(api_key=OPENAI_API_KEY)
        
        # Criar embedding do business plan completo (mesmo modelo do RAG)
        response = client.embeddings.create(
            input=business_plan_markdown,
            model="text-embedding-3-small",
            dimensions=1536  # Mesma dimensão do índice
        )
        embedding = response.data[0].embedding
        
        # Extrair metadados do business plan
        metadados = extrair_metadados_business_plan(business_plan_markdown)
        
        # Buscar informações adicionais do banco para enriquecer metadados
        try:
            conn = psycopg2.connect(NEON_DB_URL)
            cur = conn.cursor()
            
            # Buscar dados da startup
            cur.execute("""
                SELECT i.titulo, i.descricao, i.empreendedor, i.modelo_negocio,
                       cv.vertical, cp.potencial, pe.status
                FROM ideias_startup i
                LEFT JOIN classificacao_vertical cv ON i.id = cv.ideia_id
                LEFT JOIN classificacao_potencial cp ON i.id = cp.ideia_id
                LEFT JOIN plano_execucao pe ON i.id = pe.ideia_id
                WHERE i.id = %s
            """, (startup_id,))
            
            startup_info = cur.fetchone()
            if startup_info:
                metadados.update({
                    'titulo': startup_info[0] or '',
                    'descricao_original': startup_info[1][:200] if startup_info[1] else '',
                    'empreendedor': startup_info[2] or '',
                    'modelo_negocio': startup_info[3] or '',
                    'vertical': startup_info[4] or '',
                    'potencial': startup_info[5] or '',
                    'status_execucao': startup_info[6] or ''
                })
            
            cur.close()
            conn.close()
            
        except Exception as db_error:
            logger.warning(f"Erro ao buscar metadados do banco para startup {startup_id}: {str(db_error)}")
        
        # Metadados finais
        metadados.update({
            'startup_id': str(startup_id),
            'tipo': 'business_plan_processado',
            'conteudo_completo': business_plan_markdown[:1000],  # Primeiros 1000 chars
            'processado_em': datetime.now().isoformat(),
            'status': 'processado'
        })
        
        # Atualizar vetor no Pinecone
        vector_id = f"startup_{startup_id}_processado"
        index.upsert(vectors=[(vector_id, embedding, metadados)])
        logger.info(f"✅ Startup {startup_id} atualizada no Pinecone com sucesso (ID: {vector_id})")
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro ao atualizar Pinecone para startup {startup_id}: {str(e)}")
        return False

def extrair_metadados_business_plan(conteudo_business_plan):
    """Extrai metadados estruturados do business plan"""
    metadados = {}
    
    linhas = conteudo_business_plan.split('\n')
    
    for i, linha in enumerate(linhas):
        # Extrair vertical de mercado
        if "## Vertical de Mercado" in linha and i+1 < len(linhas):
            vertical_linha = linhas[i+1].strip()
            if ' - ' in vertical_linha:
                metadados['vertical'] = vertical_linha.split(' - ')[0].strip()
        
        # Extrair potencial
        elif "## Potencial de Sucesso" in linha and i+1 < len(linhas):
            potencial_linha = linhas[i+1].strip()
            if ' - ' in potencial_linha:
                metadados['potencial'] = potencial_linha.split(' - ')[0].strip()
        
        # Extrair investimento
        elif "- Investimento:" in linha:
            metadados['investimento'] = linha.replace('- Investimento:', '').strip()
        
        # Extrair status de recomendação
        elif "## Recomendação Final" in linha and i+1 < len(linhas):
            metadados['recomendacao'] = linhas[i+1].strip()[:100]  # Primeiros 100 chars
    
    return metadados

def verificar_tabelas():
    """Verifica se as tabelas necessárias existem no banco de dados."""
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Verificar quais tabelas existem
        cur.execute("""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name IN ('ideias_startup', 'business_plan', 'plano_execucao', 'classificacao_potencial', 'classificacao_vertical')
        """)
        tabelas_existentes = [row[0] for row in cur.fetchall()]
        logger.info(f"Tabelas encontradas no banco de dados: {tabelas_existentes}")
        
        # Verificar se todas as tabelas necessárias existem
        tabelas_necessarias = ['ideias_startup', 'business_plan', 'plano_execucao', 'classificacao_potencial', 'classificacao_vertical']
        tabelas_faltando = [t for t in tabelas_necessarias if t not in tabelas_existentes]
        
        if tabelas_faltando:
            logger.error(f"As seguintes tabelas estão faltando no banco de dados: {tabelas_faltando}")
            logger.error("Execute o script de migração: python tools/migrar_para_startupflow.py para criar as tabelas necessárias.")
            return False
        
        return True
        
    except Exception as e:
        import traceback
        logger.error(f"Erro ao verificar tabelas: {str(e)}")
        logger.error(traceback.format_exc())
        return False
    finally:
        if 'cur' in locals():
            cur.close()
        if 'conn' in locals():
            conn.close()

if __name__ == "__main__":
    # Verificar se as tabelas necessárias existem
    if verificar_tabelas():
        processar_startups()
    else:
        logger.error("Não foi possível continuar devido a problemas com as tabelas do banco de dados.")
