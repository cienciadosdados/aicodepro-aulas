#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para popular o banco de dados com startups de demonstração
Cria 20+ ideias de startup diversificadas para demo do StartupFlow
"""

import os
import sys
import psycopg2
import logging
from datetime import datetime, timedelta
from urllib.parse import urlparse
from dotenv import load_dotenv

# Configurar logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Carregar variáveis do .env
load_dotenv()
NEON_DB_URL = os.getenv("NEON_DB_URL")

# Dados de startups para demonstração
STARTUPS_DEMO = [
    {
        'titulo': 'GreenLogistics',
        'descricao': 'Plataforma que otimiza rotas de entrega usando IA para reduzir emissões de carbono e custos logísticos',
        'empreendedor': 'Ana Sustainability',
        'problema_resolve': 'Empresas de logística têm rotas ineficientes que geram muito CO2 e custos altos',
        'publico_alvo': 'Empresas de e-commerce e transportadoras',
        'modelo_negocio': 'SaaS'
    },
    {
        'titulo': 'MedConnect',
        'descricao': 'Telemedicina especializada em consultas psicológicas com matching de profissionais por perfil do paciente',
        'empreendedor': 'Dr. Carlos Mental',
        'problema_resolve': 'Pacientes têm dificuldade para encontrar psicólogos compatíveis com seu perfil',
        'publico_alvo': 'Pessoas que precisam de apoio psicológico',
        'modelo_negocio': 'Marketplace'
    },
    {
        'titulo': 'EduGamify',
        'descricao': 'Plataforma de educação corporativa gamificada para treinamento de funcionários',
        'empreendedor': 'Maria GameDev',
        'problema_resolve': 'Treinamentos corporativos são chatos e funcionários não se engajam',
        'publico_alvo': 'Empresas com mais de 100 funcionários',
        'modelo_negocio': 'B2B'
    },
    {
        'titulo': 'CryptoSafe',
        'descricao': 'Carteira digital super segura para criptomoedas com autenticação biométrica múltipla',
        'empreendedor': 'João Blockchain',
        'problema_resolve': 'Pessoas perdem milhões em criptomoedas por falta de segurança adequada',
        'publico_alvo': 'Investidores em criptomoedas',
        'modelo_negocio': 'Freemium'
    },
    {
        'titulo': 'FoodRescue',
        'descricao': 'App que conecta restaurantes com excesso de comida a ONGs e pessoas em vulnerabilidade',
        'empreendedor': 'Lucia Solidariedade',
        'problema_resolve': 'Toneladas de comida são desperdiçadas enquanto pessoas passam fome',
        'publico_alvo': 'Restaurantes e ONGs sociais',
        'modelo_negocio': 'Marketplace'
    },
    {
        'titulo': 'AIRecruits',
        'descricao': 'Plataforma de recrutamento que usa IA para fazer match perfeito entre candidatos e vagas',
        'empreendedor': 'Pedro TechHR',
        'problema_resolve': 'RHs gastam muito tempo triando candidatos incompatíveis',
        'publico_alvo': 'Departamentos de RH de empresas médias e grandes',
        'modelo_negocio': 'SaaS'
    },
    {
        'titulo': 'VirtualOffice',
        'descricao': 'Escritório virtual em realidade aumentada para equipes remotas se reunirem',
        'empreendedor': 'Carla MetaWork',
        'problema_resolve': 'Trabalho remoto perde em colaboração e conexão humana',
        'publico_alvo': 'Empresas com equipes 100% remotas',
        'modelo_negocio': 'SaaS'
    },
    {
        'titulo': 'SmartFarm',
        'descricao': 'Sensores IoT para monitoramento inteligente de plantações com previsão de pragas',
        'empreendedor': 'Roberto AgroTech',
        'problema_resolve': 'Agricultores perdem safras por não detectar problemas cedo',
        'publico_alvo': 'Produtores rurais de médio e grande porte',
        'modelo_negocio': 'B2B'
    },
    {
        'titulo': 'SocialGaming',
        'descricao': 'Plataforma de jogos casuais onde players podem ganhar dinheiro real competindo',
        'empreendedor': 'Felipe GameMoney',
        'problema_resolve': 'Gamers casuais querem monetizar seu tempo jogando',
        'publico_alvo': 'Gamers casuais de 18-35 anos',
        'modelo_negocio': 'B2C'
    },
    {
        'titulo': 'CarShare+',
        'descricao': 'Compartilhamento de carros elétricos por subscription mensal com app super intuitivo',
        'empreendedor': 'Renata EcoMobile',
        'problema_resolve': 'Pessoas querem usar carro elétrico mas não querem comprar',
        'publico_alvo': 'Moradores de grandes centros urbanos',
        'modelo_negocio': 'Marketplace'
    },
    {
        'titulo': 'LearningPath',
        'descricao': 'IA que cria trilhas de aprendizado personalizadas baseadas no perfil e objetivos do aluno',
        'empreendedor': 'Sandra EduTech',
        'problema_resolve': 'Estudantes se perdem sem saber que curso fazer para atingir seus objetivos',
        'publico_alvo': 'Estudantes universitários e profissionais em transição',
        'modelo_negocio': 'Freemium'
    },
    {
        'titulo': 'HealthTracker',
        'descricao': 'Wearable que detecta sinais precoces de doenças cardíacas e alerta médicos',
        'empreendedor': 'Dr. Antonio CardioTech',
        'problema_resolve': 'Infartos matam por não serem detectados a tempo',
        'publico_alvo': 'Pessoas com risco cardíaco e seus médicos',
        'modelo_negocio': 'B2B'
    },
    {
        'titulo': 'EventosVR',
        'descricao': 'Plataforma para criar eventos corporativos em realidade virtual com networking real',
        'empreendedor': 'Bruno VirtualEvents',
        'problema_resolve': 'Eventos online são chatos e não geram networking efetivo',
        'publico_alvo': 'Empresas que fazem eventos corporativos',
        'modelo_negocio': 'SaaS'
    },
    {
        'titulo': 'MicroInvest',
        'descricao': 'App que permite investir troco de compras automaticamente em carteira diversificada',
        'empreendedor': 'Patricia FinanceAI',
        'problema_resolve': 'Pessoas querem investir mas não sabem por onde começar ou têm pouco dinheiro',
        'publico_alvo': 'Jovens de 20-35 anos que querem começar a investir',
        'modelo_negocio': 'Freemium'
    },
    {
        'titulo': 'PetCare24',
        'descricao': 'Veterinária online 24h com consultas por vídeo e entrega de medicamentos',
        'empreendedor': 'Dra. Mariana VetTech',
        'problema_resolve': 'Pets ficam doentes fora do horário comercial e donos entram em desespero',
        'publico_alvo': 'Donos de pets classe A e B',
        'modelo_negocio': 'Marketplace'
    },
    {
        'titulo': 'CodeMentor',
        'descricao': 'Plataforma que conecta devs iniciantes com mentores seniors para code reviews pagos',
        'empreendedor': 'Ricardo DevMaster',
        'problema_resolve': 'Devs iniciantes não têm feedback qualificado sobre seu código',
        'publico_alvo': 'Desenvolvedores iniciantes e intermediários',
        'modelo_negocio': 'Marketplace'
    },
    {
        'titulo': 'CleanSpace',
        'descricao': 'Marketplace de faxineiros especializados com garantia de qualidade e seguro',
        'empreendedor': 'Cleide ServicePro',
        'problema_resolve': 'Pessoas não confiam em contratar faxineiros sem referências',
        'publico_alvo': 'Famílias de classe média alta em centros urbanos',
        'modelo_negocio': 'Marketplace'
    },
    {
        'titulo': 'RetailPredict',
        'descricao': 'IA que prevê demanda de produtos para varejistas otimizarem estoque',
        'empreendedor': 'Amanda RetailTech',
        'problema_resolve': 'Lojistas perdem vendas por falta de estoque ou perdem dinheiro com excesso',
        'publico_alvo': 'Varejistas de porte médio',
        'modelo_negocio': 'SaaS'
    },
    {
        'titulo': 'MindfulWork',
        'descricao': 'App corporativo de mindfulness com sessões personalizadas para reduzir burnout',
        'empreendedor': 'Zen Wellness',
        'problema_resolve': 'Funcionários estão com burnout e empresas perdem produtividade',
        'publico_alvo': 'RHs de empresas preocupadas com bem-estar',
        'modelo_negocio': 'B2B'
    },
    {
        'titulo': 'DroneDeliver',
        'descricao': 'Entrega de medicamentos por drones para regiões remotas em até 30 minutos',
        'empreendedor': 'Rafael SkyLogistics',
        'problema_resolve': 'Pessoas em áreas remotas não têm acesso rápido a medicamentos urgentes',
        'publico_alvo': 'Farmácias e clínicas em cidades pequenas',
        'modelo_negocio': 'B2B'
    }
]

def popular_startups():
    """Popula o banco com as startups de demonstração"""
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Limpar tabela existente
        cur.execute("TRUNCATE TABLE ideias_startup RESTART IDENTITY CASCADE;")
        logger.info("🧹 Tabela ideias_startup limpa")
        
        # Inserir startups
        for i, startup in enumerate(STARTUPS_DEMO):
            try:
                cur.execute("""
                    INSERT INTO ideias_startup (titulo, descricao, empreendedor, problema_resolve, publico_alvo, modelo_negocio)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, (
                    startup['titulo'],
                    startup['descricao'], 
                    startup['empreendedor'],
                    startup['problema_resolve'],
                    startup['publico_alvo'],
                    startup['modelo_negocio']
                ))
                
                logger.info(f"✅ Startup {i+1}/20: {startup['titulo']} criada")
                
            except Exception as e:
                logger.error(f"❌ Erro ao criar startup {startup['titulo']}: {str(e)}")
        
        conn.commit()
        
        # Verificar resultado
        cur.execute("SELECT COUNT(*) FROM ideias_startup;")
        total = cur.fetchone()[0]
        
        logger.info(f"🎯 Total de startups criadas: {total}")
        
        cur.close()
        conn.close()
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro ao popular startups: {str(e)}")
        return False

def mostrar_estatisticas():
    """Mostra estatísticas das startups criadas"""
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Total geral
        cur.execute("SELECT COUNT(*) FROM ideias_startup;")
        total = cur.fetchone()[0]
        
        # Por modelo de negócio
        cur.execute("""
            SELECT modelo_negocio, COUNT(*) 
            FROM ideias_startup 
            GROUP BY modelo_negocio 
            ORDER BY COUNT(*) DESC;
        """)
        modelos = cur.fetchall()
        
        # Por status
        cur.execute("""
            SELECT status, COUNT(*) 
            FROM ideias_startup 
            GROUP BY status 
            ORDER BY COUNT(*) DESC;
        """)
        status = cur.fetchall()
        
        logger.info("📊 ESTATÍSTICAS DAS STARTUPS CRIADAS:")
        logger.info(f"   📈 Total: {total} startups")
        logger.info("   💼 Por modelo de negócio:")
        for modelo, count in modelos:
            logger.info(f"      - {modelo}: {count}")
        logger.info("   📋 Por status:")
        for stat, count in status:
            logger.info(f"      - {stat}: {count}")
        
        cur.close()
        conn.close()
        
    except Exception as e:
        logger.error(f"❌ Erro ao mostrar estatísticas: {str(e)}")

def main():
    """Função principal"""
    logger.info("🚀 Iniciando população do banco com startups demo")
    
    if not NEON_DB_URL:
        logger.error("❌ NEON_DB_URL não encontrada no arquivo .env")
        return False
    
    # Popular startups
    if not popular_startups():
        logger.error("❌ Falha ao popular startups")
        return False
    
    # Mostrar estatísticas
    mostrar_estatisticas()
    
    logger.info("🎉 POPULAÇÃO CONCLUÍDA COM SUCESSO!")
    logger.info("📋 Próximos passos:")
    logger.info("   1. Execute: python agents/crewai_agents.py")
    logger.info("   2. As startups serão processadas pelos agentes automaticamente")
    logger.info("   3. Execute: python chat_interface/flask_app.py para testar")
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)