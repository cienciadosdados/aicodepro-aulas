# deletar_neon_completo.py
"""
Script para deletar TODAS as tabelas do Neon Database
⚠️ ATENÇÃO: Este script deleta TODOS os dados permanentemente!
Use apenas se quiser começar completamente do zero.
"""

import psycopg2
import os
from dotenv import load_dotenv

def deletar_todas_tabelas():
    print("🗑️ DELETANDO TODAS AS TABELAS DO NEON")
    print("=" * 50)
    print("⚠️ ATENÇÃO: Isso deletará TODOS os dados!")
    
    # Confirmar ação
    confirmacao = input("Digite 'DELETAR TUDO' para confirmar: ")
    if confirmacao != "DELETAR TUDO":
        print("❌ Operação cancelada.")
        return False
    
    # Carregar variáveis
    load_dotenv()
    neon_url = os.getenv('NEON_DB_URL')
    
    if not neon_url:
        print("❌ NEON_DB_URL não encontrada no .env")
        return False
    
    try:
        # Conectar
        conn = psycopg2.connect(neon_url)
        cur = conn.cursor()
        print("✅ Conectado ao Neon DB")
        
        # Listar todas as tabelas
        cur.execute("""
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_type = 'BASE TABLE'
        ORDER BY table_name;
        """)
        
        tabelas = [row[0] for row in cur.fetchall()]
        
        if not tabelas:
            print("ℹ️ Nenhuma tabela encontrada para deletar")
            cur.close()
            conn.close()
            return True
        
        print(f"📋 Encontradas {len(tabelas)} tabelas:")
        for tabela in tabelas:
            print(f"  - {tabela}")
        
        print("\n🗑️ Deletando tabelas...")
        
        # Deletar cada tabela (com CASCADE para dependências)
        for tabela in tabelas:
            try:
                cur.execute(f"DROP TABLE IF EXISTS {tabela} CASCADE;")
                print(f"  ✅ {tabela} deletada")
            except Exception as e:
                print(f"  ❌ Erro ao deletar {tabela}: {e}")
        
        # Commit das mudanças
        conn.commit()
        
        # Verificar se todas foram deletadas
        cur.execute("""
        SELECT COUNT(*) 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_type = 'BASE TABLE';
        """)
        
        restantes = cur.fetchone()[0]
        
        if restantes == 0:
            print("\n🎉 TODAS AS TABELAS FORAM DELETADAS COM SUCESSO!")
            print("✅ Banco está limpo e pronto para recomeçar")
        else:
            print(f"\n⚠️ Ainda restam {restantes} tabelas")
        
        cur.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erro durante deleção: {e}")
        return False

def deletar_tabelas_especificas():
    """Deletar apenas as tabelas do projeto StartupFlow"""
    print("🗑️ DELETANDO TABELAS DO STARTUPFLOW")
    print("=" * 40)
    
    # Carregar variáveis
    load_dotenv()
    neon_url = os.getenv('NEON_DB_URL')
    
    if not neon_url:
        print("❌ NEON_DB_URL não encontrada no .env")
        return False
    
    try:
        conn = psycopg2.connect(neon_url)
        cur = conn.cursor()
        print("✅ Conectado ao Neon DB")
        
        # Tabelas específicas do projeto
        tabelas_projeto = [
            'business_plan',
            'plano_execucao', 
            'analise_mercado',
            'classificacao_potencial',
            'classificacao_vertical',
            'ideias_startup'
        ]
        
        print("🗑️ Deletando tabelas do projeto...")
        
        for tabela in tabelas_projeto:
            try:
                cur.execute(f"DROP TABLE IF EXISTS {tabela} CASCADE;")
                print(f"  ✅ {tabela} deletada")
            except Exception as e:
                print(f"  ❌ Erro ao deletar {tabela}: {e}")
        
        conn.commit()
        print("\n✅ Tabelas do StartupFlow deletadas!")
        
        cur.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        return False

def main():
    print("🚀 SCRIPT DE LIMPEZA DO NEON DATABASE")
    print("=" * 50)
    print("Escolha uma opção:")
    print("1. Deletar TODAS as tabelas (limpeza completa)")
    print("2. Deletar apenas tabelas do StartupFlow")
    print("3. Cancelar")
    
    opcao = input("\nDigite sua escolha (1, 2 ou 3): ")
    
    if opcao == "1":
        deletar_todas_tabelas()
    elif opcao == "2":
        deletar_tabelas_especificas()
    elif opcao == "3":
        print("❌ Operação cancelada.")
    else:
        print("❌ Opção inválida.")

if __name__ == "__main__":
    main()