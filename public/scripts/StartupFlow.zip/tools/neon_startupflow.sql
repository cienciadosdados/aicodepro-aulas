-- ===================================================================
-- STARTUPFLOW DATABASE SCHEMA
-- Sistema Inteligente de Validação de Startups Multi Agents
-- Transformado de: BugFlow -> StartupFlow
-- ===================================================================

/* Tabela principal de ideias de startup */
CREATE TABLE ideias_startup (
    id SERIAL PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT NOT NULL,
    empreendedor VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'Submetida' CHECK (status IN ('Submetida', 'Analisando', 'Validada', 'Rejeitada', 'Processado')),
    data_submissao TIMESTAMP DEFAULT NOW(),
    problema_resolve TEXT,
    publico_alvo VARCHAR(200),
    modelo_negocio VARCHAR(50) DEFAULT 'B2C' CHECK (modelo_negocio IN ('B2C', 'B2B', 'Marketplace', 'SaaS', 'Freemium'))
);

/* Classificacao por vertical de mercado */
CREATE TABLE classificacao_vertical (
    id SERIAL PRIMARY KEY,
    ideia_id INT REFERENCES ideias_startup(id),
    vertical VARCHAR(50) NOT NULL CHECK (vertical IN ('FinTech', 'EdTech', 'HealthTech', 'E-commerce', 'SaaS', 'Marketplace', 'Gaming', 'Social')),
    justificativa TEXT,
    data_classificacao TIMESTAMP DEFAULT NOW()
);

/* Classificacao por potencial de sucesso */
CREATE TABLE classificacao_potencial (
    id SERIAL PRIMARY KEY,
    ideia_id INT REFERENCES ideias_startup(id),
    potencial VARCHAR(20) NOT NULL CHECK (potencial IN ('Alto', 'Médio', 'Baixo')),
    score_viabilidade INT CHECK (score_viabilidade BETWEEN 1 AND 10),
    fatores_positivos TEXT,
    fatores_negativos TEXT,
    data_classificacao TIMESTAMP DEFAULT NOW()
);

/* Analise de mercado e competicao */
CREATE TABLE analise_mercado (
    id SERIAL PRIMARY KEY,
    ideia_id INT REFERENCES ideias_startup(id),
    tamanho_mercado TEXT,
    principais_concorrentes TEXT,
    diferencial_competitivo TEXT,
    barreiras_entrada TEXT,
    oportunidades TEXT,
    ameacas TEXT,
    validacao_mercado TEXT,
    data_analise TIMESTAMP DEFAULT NOW()
);

/* Plano de execucao e roadmap */
CREATE TABLE plano_execucao (
    id SERIAL PRIMARY KEY,
    ideia_id INT REFERENCES ideias_startup(id),
    perfil_equipe_ideal TEXT,
    investimento_necessario TEXT,
    tempo_desenvolvimento TEXT,
    milestones TEXT,
    canais_aquisicao TEXT,
    modelo_receita TEXT,
    responsavel VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL CHECK (status IN ('MVP', 'Validação', 'Investimento', 'Pivot', 'Abandon')),
    data_atualizacao TIMESTAMP DEFAULT NOW()
);

/* Business plan final gerado */
CREATE TABLE business_plan (
    id SERIAL PRIMARY KEY,
    ideia_id INT REFERENCES ideias_startup(id),
    pitch_deck TEXT NOT NULL,
    projecao_financeira TEXT,
    estrategia_go_to_market TEXT,
    riscos_identificados TEXT,
    recomendacao_final TEXT,
    viavel BOOLEAN DEFAULT FALSE,
    data_conclusao TIMESTAMP DEFAULT NOW()
);

-- ===================================================================
-- ÍNDICES PARA PERFORMANCE
-- ===================================================================

CREATE INDEX idx_ideias_status ON ideias_startup(status);
CREATE INDEX idx_ideias_data ON ideias_startup(data_submissao);
CREATE INDEX idx_classificacao_vertical ON classificacao_vertical(vertical);
CREATE INDEX idx_classificacao_potencial ON classificacao_potencial(potencial);

-- ===================================================================
-- DADOS DE EXEMPLO PARA DEMONSTRAÇÃO
-- ===================================================================

INSERT INTO ideias_startup (titulo, descricao, empreendedor, problema_resolve, publico_alvo, modelo_negocio) VALUES
('PetDelivery', 'App de delivery exclusivo para produtos pets com entrega em 30 minutos', 'Maria Silva', 'Donos de pets precisam sair para comprar ração em emergências', 'Donos de cães e gatos classe A/B', 'Marketplace'),
('EduMentor AI', 'Plataforma de mentoria educacional com IA que conecta alunos a mentores', 'João Santos', 'Estudantes têm dificuldade para encontrar mentores qualificados', 'Estudantes universitários e pré-vestibular', 'SaaS'),
('FinPlan Pro', 'Software de planejamento financeiro pessoal com análise preditiva', 'Ana Costa', 'Pessoas não sabem como planejar finanças pessoais', 'Classe média que quer organizar finanças', 'Freemium'),
('HealthTrack', 'Wearable que monitora saúde em tempo real e alerta médicos', 'Carlos Oliveira', 'Idosos vivem sozinhos sem monitoramento de saúde', 'Famílias com idosos, planos de saúde', 'B2B'),
('GameHub Social', 'Rede social exclusiva para gamers com torneios e streaming', 'Fernanda Lima', 'Gamers não têm rede social específica para sua comunidade', 'Gamers de 16-35 anos', 'B2C');