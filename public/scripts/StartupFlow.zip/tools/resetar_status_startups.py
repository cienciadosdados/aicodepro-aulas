#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para resetar status das startups para 'Submetida'
Útil para demonstrações e reprocessamento dos agentes
"""

import psycopg2
import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()
NEON_DB_URL = os.getenv("NEON_DB_URL")

def resetar_status_startups():
    """Reseta o status de todas as startups para 'Submetida'"""
    print("🔄 RESETANDO STATUS DAS STARTUPS")
    print("=" * 50)
    
    if not NEON_DB_URL:
        print("❌ NEON_DB_URL não encontrada no .env")
        return False
    
    try:
        # Conectar ao banco
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Verificar status atual
        cur.execute("SELECT status, COUNT(*) FROM ideias_startup GROUP BY status ORDER BY COUNT(*) DESC;")
        status_antes = cur.fetchall()
        
        print("📊 STATUS ANTES DO RESET:")
        for status, count in status_antes:
            print(f"  {status}: {count} startups")
        
        # Confirmar ação
        print("\n⚠️ ATENÇÃO: Isso vai resetar TODAS as startups para 'Submetida'")
        confirmacao = input("Digite 'RESETAR' para confirmar: ")
        
        if confirmacao.upper() != "RESETAR":
            print("❌ Operação cancelada")
            return False
        
        # Resetar status
        cur.execute("UPDATE ideias_startup SET status = 'Submetida';")
        linhas_afetadas = cur.rowcount
        conn.commit()
        
        print(f"\n✅ {linhas_afetadas} startups resetadas para 'Submetida'")
        
        # Verificar resultado
        cur.execute("SELECT status, COUNT(*) FROM ideias_startup GROUP BY status ORDER BY COUNT(*) DESC;")
        status_depois = cur.fetchall()
        
        print("\n📊 STATUS APÓS O RESET:")
        for status, count in status_depois:
            print(f"  {status}: {count} startups")
        
        cur.close()
        conn.close()
        
        print("\n🎉 RESET CONCLUÍDO COM SUCESSO!")
        print("📋 Próximos passos:")
        print("   1. Execute: python agents/crewai_agents.py")
        print("   2. Observe o processamento dos agentes em tempo real")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        return False

def resetar_apenas_processadas():
    """Reseta apenas startups 'Processado' para 'Submetida'"""
    print("🔄 RESETANDO APENAS STARTUPS PROCESSADAS")
    print("=" * 50)
    
    if not NEON_DB_URL:
        print("❌ NEON_DB_URL não encontrada no .env")
        return False
    
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Contar processadas
        cur.execute("SELECT COUNT(*) FROM ideias_startup WHERE status = 'Processado';")
        count_processadas = cur.fetchone()[0]
        
        if count_processadas == 0:
            print("ℹ️ Nenhuma startup 'Processado' encontrada")
            return True
        
        print(f"📊 Encontradas {count_processadas} startups 'Processado'")
        
        # Confirmar
        confirmacao = input("Digite 'SIM' para resetar apenas as processadas: ")
        if confirmacao.upper() != "SIM":
            print("❌ Operação cancelada")
            return False
        
        # Resetar apenas processadas
        cur.execute("UPDATE ideias_startup SET status = 'Submetida' WHERE status = 'Processado';")
        linhas_afetadas = cur.rowcount
        conn.commit()
        
        print(f"✅ {linhas_afetadas} startups 'Processado' resetadas para 'Submetida'")
        
        cur.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        return False

def resetar_apenas_rejeitadas():
    """Reseta apenas startups 'Rejeitada' para 'Submetida'"""
    print("🔄 RESETANDO APENAS STARTUPS REJEITADAS")
    print("=" * 50)
    
    if not NEON_DB_URL:
        print("❌ NEON_DB_URL não encontrada no .env")
        return False
    
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Contar rejeitadas
        cur.execute("SELECT COUNT(*) FROM ideias_startup WHERE status = 'Rejeitada';")
        count_rejeitadas = cur.fetchone()[0]
        
        if count_rejeitadas == 0:
            print("ℹ️ Nenhuma startup 'Rejeitada' encontrada")
            return True
        
        print(f"📊 Encontradas {count_rejeitadas} startups 'Rejeitada'")
        
        # Confirmar
        confirmacao = input("Digite 'SIM' para resetar apenas as rejeitadas: ")
        if confirmacao.upper() != "SIM":
            print("❌ Operação cancelada")
            return False
        
        # Resetar apenas rejeitadas
        cur.execute("UPDATE ideias_startup SET status = 'Submetida' WHERE status = 'Rejeitada';")
        linhas_afetadas = cur.rowcount
        conn.commit()
        
        print(f"✅ {linhas_afetadas} startups 'Rejeitada' resetadas para 'Submetida'")
        
        cur.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Erro: {e}")
        return False

def main():
    """Menu principal"""
    print("🚀 RESETAR STATUS DAS STARTUPS")
    print("=" * 50)
    print("Escolha uma opção:")
    print("1. Resetar TODAS as startups para 'Submetida'")
    print("2. Resetar apenas startups 'Processado' para 'Submetida'")
    print("3. Resetar apenas startups 'Rejeitada' para 'Submetida'")
    print("4. Cancelar")
    
    opcao = input("\nDigite sua escolha (1, 2, 3 ou 4): ")
    
    if opcao == "1":
        resetar_status_startups()
    elif opcao == "2":
        resetar_apenas_processadas()
    elif opcao == "3":
        resetar_apenas_rejeitadas()
    elif opcao == "4":
        print("❌ Operação cancelada")
    else:
        print("❌ Opção inválida")

if __name__ == "__main__":
    main()