#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para testar as melhorias dos agentes CrewAI
Compara resultados antes/depois das melhorias
"""

import os
import sys
import psycopg2
import shutil
from datetime import datetime
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()
NEON_DB_URL = os.getenv("NEON_DB_URL")

def backup_arquivo_original():
    """Faz backup do arquivo original dos agentes"""
    try:
        if os.path.exists('agents/crewai_agents.py'):
            backup_path = f'agents/crewai_agents_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.py'
            shutil.copy2('agents/crewai_agents.py', backup_path)
            print(f"✅ Backup criado: {backup_path}")
            return backup_path
        else:
            print("⚠️  Arquivo original não encontrado")
            return None
    except Exception as e:
        print(f"❌ Erro ao criar backup: {str(e)}")
        return None

def aplicar_melhorias():
    """Substitui o arquivo original pelo melhorado"""
    try:
        if os.path.exists('agents/crewai_agents_melhorado.py'):
            shutil.copy2('agents/crewai_agents_melhorado.py', 'agents/crewai_agents.py')
            print("✅ Melhorias aplicadas com sucesso")
            return True
        else:
            print("❌ Arquivo melhorado não encontrado")
            return False
    except Exception as e:
        print(f"❌ Erro ao aplicar melhorias: {str(e)}")
        return False

def resetar_startup_teste(startup_id=20):
    """Reseta uma startup específica para teste"""
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        # Resetar status da startup
        cur.execute("UPDATE ideias_startup SET status = 'Submetida' WHERE id = %s", (startup_id,))
        
        # Limpar dados processados anteriores
        cur.execute("DELETE FROM classificacao_vertical WHERE ideia_id = %s", (startup_id,))
        cur.execute("DELETE FROM classificacao_potencial WHERE ideia_id = %s", (startup_id,))
        cur.execute("DELETE FROM analise_mercado WHERE ideia_id = %s", (startup_id,))
        cur.execute("DELETE FROM plano_execucao WHERE ideia_id = %s", (startup_id,))
        cur.execute("DELETE FROM business_plan WHERE ideia_id = %s", (startup_id,))
        
        conn.commit()
        cur.close()
        conn.close()
        
        print(f"✅ Startup {startup_id} resetada para teste")
        return True
        
    except Exception as e:
        print(f"❌ Erro ao resetar startup: {str(e)}")
        return False

def verificar_dados_startup(startup_id=20):
    """Verifica os dados específicos da startup de teste"""
    try:
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        cur.execute("""
            SELECT id, titulo, descricao, empreendedor, problema_resolve, publico_alvo, modelo_negocio, status
            FROM ideias_startup 
            WHERE id = %s
        """, (startup_id,))
        
        startup = cur.fetchone()
        cur.close()
        conn.close()
        
        if startup:
            print(f"\n📋 DADOS DA STARTUP {startup_id} PARA TESTE:")
            print(f"🏢 Título: {startup[1]}")
            print(f"📝 Descrição: {startup[2][:100]}...")
            print(f"👤 Empreendedor: {startup[3]}")
            print(f"🎯 Problema: {startup[4]}")
            print(f"👥 Público: {startup[5]}")
            print(f"💼 Modelo: {startup[6]}")
            print(f"📊 Status: {startup[7]}")
            return startup
        else:
            print(f"❌ Startup {startup_id} não encontrada")
            return None
            
    except Exception as e:
        print(f"❌ Erro ao verificar dados: {str(e)}")
        return None

def executar_processamento():
    """Executa o processamento dos agentes"""
    try:
        print("\n🚀 Executando processamento dos agentes...")
        
        # Importar e executar o processamento
        sys.path.append('agents')
        import crewai_agents
        
        # Verificar se as tabelas existem
        if crewai_agents.verificar_tabelas():
            crewai_agents.processar_startups()
            print("✅ Processamento concluído")
            return True
        else:
            print("❌ Problemas com as tabelas do banco")
            return False
            
    except Exception as e:
        print(f"❌ Erro no processamento: {str(e)}")
        return False

def verificar_resultados(startup_id=20):
    """Verifica os resultados gerados"""
    try:
        # Verificar arquivos gerados
        business_plan_file = f'startup_{startup_id}_business_plan.md'
        pitch_deck_file = f'startup_{startup_id}_pitch_deck.html'
        
        resultados = {
            'business_plan_existe': os.path.exists(business_plan_file),
            'pitch_deck_existe': os.path.exists(pitch_deck_file),
            'business_plan_conteudo': '',
            'pitch_deck_conteudo': ''
        }
        
        # Ler conteúdo do business plan
        if resultados['business_plan_existe']:
            with open(business_plan_file, 'r', encoding='utf-8') as f:
                resultados['business_plan_conteudo'] = f.read()
        
        # Ler conteúdo do pitch deck
        if resultados['pitch_deck_existe']:
            with open(pitch_deck_file, 'r', encoding='utf-8') as f:
                resultados['pitch_deck_conteudo'] = f.read()
        
        # Verificar dados no banco
        conn = psycopg2.connect(NEON_DB_URL)
        cur = conn.cursor()
        
        cur.execute("""
            SELECT i.status, cv.vertical, cp.potencial, bp.viavel
            FROM ideias_startup i
            LEFT JOIN classificacao_vertical cv ON i.id = cv.ideia_id
            LEFT JOIN classificacao_potencial cp ON i.id = cp.ideia_id
            LEFT JOIN business_plan bp ON i.id = bp.ideia_id
            WHERE i.id = %s
        """, (startup_id,))
        
        dados_banco = cur.fetchone()
        cur.close()
        conn.close()
        
        if dados_banco:
            resultados.update({
                'status': dados_banco[0],
                'vertical': dados_banco[1],
                'potencial': dados_banco[2],
                'viavel': dados_banco[3]
            })
        
        return resultados
        
    except Exception as e:
        print(f"❌ Erro ao verificar resultados: {str(e)}")
        return None

def analisar_qualidade(resultados, dados_startup):
    """Analisa a qualidade dos resultados gerados"""
    print("\n📊 ANÁLISE DE QUALIDADE:")
    
    qualidade = {
        'score': 0,
        'problemas': [],
        'sucessos': []
    }
    
    # Verificar se arquivos foram gerados
    if resultados['business_plan_existe']:
        qualidade['sucessos'].append("✅ Business plan gerado")
        qualidade['score'] += 20
    else:
        qualidade['problemas'].append("❌ Business plan não gerado")
    
    if resultados['pitch_deck_existe']:
        qualidade['sucessos'].append("✅ Pitch deck gerado")
        qualidade['score'] += 20
    else:
        qualidade['problemas'].append("❌ Pitch deck não gerado")
    
    # Verificar se dados específicos foram usados
    if resultados['business_plan_conteudo']:
        conteudo = resultados['business_plan_conteudo']
        
        # Verificar se título específico foi usado
        if dados_startup[1] in conteudo:
            qualidade['sucessos'].append(f"✅ Título específico usado: {dados_startup[1]}")
            qualidade['score'] += 15
        else:
            qualidade['problemas'].append(f"❌ Título específico não encontrado: {dados_startup[1]}")
        
        # Verificar se empreendedor específico foi usado
        if dados_startup[3] in conteudo:
            qualidade['sucessos'].append(f"✅ Empreendedor específico usado: {dados_startup[3]}")
            qualidade['score'] += 15
        else:
            qualidade['problemas'].append(f"❌ Empreendedor específico não encontrado: {dados_startup[3]}")
        
        # Verificar se problema específico foi usado
        if dados_startup[4] and dados_startup[4] in conteudo:
            qualidade['sucessos'].append("✅ Problema específico usado")
            qualidade['score'] += 10
        else:
            qualidade['problemas'].append("❌ Problema específico não encontrado")
        
        # Verificar se não há placeholders genéricos
        if '[Título da Startup]' not in conteudo:
            qualidade['sucessos'].append("✅ Sem placeholders genéricos")
            qualidade['score'] += 10
        else:
            qualidade['problemas'].append("❌ Ainda contém placeholders genéricos")
        
        # Verificar se há conteúdo substancial
        if len(conteudo) > 500:
            qualidade['sucessos'].append("✅ Conteúdo substancial gerado")
            qualidade['score'] += 10
        else:
            qualidade['problemas'].append("❌ Conteúdo muito curto")
    
    # Verificar dados no banco
    if resultados.get('status') == 'Processado':
        qualidade['sucessos'].append("✅ Status atualizado para 'Processado'")
        qualidade['score'] += 10
    else:
        qualidade['problemas'].append("❌ Status não atualizado corretamente")
    
    return qualidade

def main():
    """Função principal do teste"""
    print("🧪 TESTE DAS MELHORIAS DOS AGENTES CREWAI")
    print("=" * 50)
    
    # Passo 1: Verificar dados da startup de teste
    print("\n📋 PASSO 1: Verificando dados da startup de teste...")
    dados_startup = verificar_dados_startup()
    if not dados_startup:
        print("❌ Não foi possível continuar sem dados da startup")
        return
    
    # Passo 2: Fazer backup do arquivo original
    print("\n💾 PASSO 2: Fazendo backup do arquivo original...")
    backup_path = backup_arquivo_original()
    
    # Passo 3: Aplicar melhorias
    print("\n🔧 PASSO 3: Aplicando melhorias...")
    if not aplicar_melhorias():
        print("❌ Não foi possível aplicar as melhorias")
        return
    
    # Passo 4: Resetar startup para teste
    print("\n🔄 PASSO 4: Resetando startup para teste...")
    if not resetar_startup_teste():
        print("❌ Não foi possível resetar a startup")
        return
    
    # Passo 5: Executar processamento
    print("\n🚀 PASSO 5: Executando processamento com melhorias...")
    if not executar_processamento():
        print("❌ Processamento falhou")
        return
    
    # Passo 6: Verificar resultados
    print("\n📊 PASSO 6: Verificando resultados...")
    resultados = verificar_resultados()
    if not resultados:
        print("❌ Não foi possível verificar os resultados")
        return
    
    # Passo 7: Analisar qualidade
    print("\n🎯 PASSO 7: Analisando qualidade...")
    qualidade = analisar_qualidade(resultados, dados_startup)
    
    # Relatório final
    print("\n" + "=" * 50)
    print("📋 RELATÓRIO FINAL")
    print("=" * 50)
    
    print(f"\n🎯 SCORE DE QUALIDADE: {qualidade['score']}/100")
    
    if qualidade['sucessos']:
        print("\n✅ SUCESSOS:")
        for sucesso in qualidade['sucessos']:
            print(f"  {sucesso}")
    
    if qualidade['problemas']:
        print("\n❌ PROBLEMAS:")
        for problema in qualidade['problemas']:
            print(f"  {problema}")
    
    # Recomendações
    print("\n💡 RECOMENDAÇÕES:")
    if qualidade['score'] >= 80:
        print("  🎉 Excelente! As melhorias funcionaram muito bem.")
    elif qualidade['score'] >= 60:
        print("  👍 Bom progresso, mas ainda há espaço para melhorias.")
    else:
        print("  ⚠️  Melhorias precisam de mais ajustes.")
    
    # Informações sobre arquivos gerados
    if resultados['business_plan_existe']:
        print(f"\n📄 Business Plan gerado: startup_20_business_plan.md")
    if resultados['pitch_deck_existe']:
        print(f"🎨 Pitch Deck gerado: startup_20_pitch_deck.html")
    
    if backup_path:
        print(f"\n💾 Backup do arquivo original: {backup_path}")
    
    print("\n🎓 PARA ALUNOS:")
    print("  - Compare os arquivos gerados antes/depois das melhorias")
    print("  - Analise como prompts específicos melhoram a qualidade")
    print("  - Observe a importância de passar contexto correto para IA")

if __name__ == "__main__":
    main()