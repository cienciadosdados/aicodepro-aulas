# teste_conexao.py
import psycopg2
import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

def testar_neon():
    """Testa conexão com Neon Database"""
    try:
        # Conectar ao banco
        conn = psycopg2.connect(os.getenv('NEON_DB_URL'))
        print("✅ Conexão com Neon DB estabelecida com sucesso!")
        
        # Testar uma query simples
        cur = conn.cursor()
        cur.execute("SELECT version();")
        version = cur.fetchone()
        print(f"📊 Versão do PostgreSQL: {version[0]}")
        
        # Fechar conexão
        cur.close()
        conn.close()
        print("🔒 Conexão Neon fechada.")
        return True
        
    except Exception as e:
        print(f"❌ Erro na conexão Neon: {e}")
        print("\n🔧 POSSÍVEIS SOLUÇÕES:")
        print("1. Verifique se o arquivo .env existe e tem NEON_DB_URL")
        print("2. Confirme se a URL do Neon está correta")
        print("3. Verifique se o projeto Neon não foi pausado")
        print("4. Teste a conexão no console web do Neon")
        return False

def testar_openai():
    """Testa conexão com OpenAI API"""
    try:
        from openai import OpenAI
        
        # Limpar qualquer variável de ambiente global
        if 'OPENAI_API_KEY' in os.environ:
            del os.environ['OPENAI_API_KEY']
        
        # Recarregar .env para garantir que está usando o local
        load_dotenv(override=True)
        
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            print("❌ OPENAI_API_KEY não encontrada no .env")
            return False
        
        print(f"🔑 Usando chave do .env: {api_key[:20]}...")
        print(f"🔑 Tamanho da chave: {len(api_key)} caracteres")
        
        # Forçar uso da chave do .env (ignorar variáveis globais)
        client = OpenAI(
            api_key=api_key,
            base_url=os.getenv('OPENAI_API_BASE', 'https://api.openai.com/v1')
        )
        
        # Fazer uma chamada simples para testar
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Teste"}],
            max_tokens=5
        )
        
        print("✅ OpenAI API funcionando!")
        print(f"📊 Modelo testado: gpt-3.5-turbo")
        print(f"🔑 Chave válida e com créditos")
        return True
        
    except ImportError:
        print("❌ Biblioteca openai não instalada")
        print("💡 Execute: pip install openai")
        return False
    except Exception as e:
        print(f"❌ Erro na OpenAI API: {e}")
        print("\n🔧 POSSÍVEIS SOLUÇÕES:")
        print("1. Verifique se OPENAI_API_KEY está correta no .env")
        print("2. Confirme se a chave tem créditos disponíveis")
        print("3. Verifique se a chave não expirou")
        print("4. Teste no site da OpenAI: platform.openai.com")
        return False

def testar_pinecone():
    """Testa conexão com Pinecone"""
    try:
        import pinecone
        
        api_key = os.getenv('PINECONE_API_KEY')
        if not api_key:
            print("❌ PINECONE_API_KEY não encontrada no .env")
            return False
            
        pc = pinecone.Pinecone(api_key=api_key)
        index = pc.Index("startupflow")
        
        # Testar conexão
        stats = index.describe_index_stats()
        print("✅ Pinecone conectado com sucesso!")
        print(f"📊 Índice: startupflow")
        print(f"🔢 Total de vetores: {stats.total_vector_count}")
        print(f"📏 Dimensões: {stats.dimension}")
        return True
        
    except ImportError:
        print("❌ Biblioteca pinecone não instalada")
        print("💡 Execute: pip install pinecone-client")
        return False
    except Exception as e:
        print(f"❌ Erro no Pinecone: {e}")
        print("\n🔧 POSSÍVEIS SOLUÇÕES:")
        print("1. Verifique se PINECONE_API_KEY está correta no .env")
        print("2. Confirme se o índice 'startupflow' existe")
        print("3. Verifique no console do Pinecone: pinecone.io")
        return False

def main():
    """Testa todas as conexões"""
    print("🚀 TESTANDO TODAS AS CONEXÕES")
    print("=" * 40)
    
    resultados = {}
    
    print("\n1️⃣ TESTANDO NEON DATABASE:")
    resultados['neon'] = testar_neon()
    
    print("\n2️⃣ TESTANDO OPENAI API:")
    resultados['openai'] = testar_openai()
    
    print("\n3️⃣ TESTANDO PINECONE:")
    resultados['pinecone'] = testar_pinecone()
    
    print("\n" + "=" * 40)
    print("📋 RESUMO DOS TESTES:")
    print("=" * 40)
    
    for servico, sucesso in resultados.items():
        status = "✅ OK" if sucesso else "❌ FALHOU"
        print(f"{servico.upper()}: {status}")
    
    total_ok = sum(resultados.values())
    print(f"\n🎯 {total_ok}/3 serviços funcionando")
    
    if total_ok == 3:
        print("🎉 TODOS OS SERVIÇOS ESTÃO FUNCIONANDO!")
        print("✅ Ambiente pronto para usar")
    else:
        print("⚠️ Alguns serviços precisam de atenção")
        print("🔧 Verifique as soluções sugeridas acima")

if __name__ == "__main__":
    main()