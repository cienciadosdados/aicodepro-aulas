import App from "./app";

export default function Page() {
    return <App />
}
