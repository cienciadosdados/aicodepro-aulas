This is a response in markdown from the copilot.

This is some text.

I'm adding a tool `get_status()` below:

```copilot_change
// action: create_new
// config_type: tool
// name: get_status
{
	"change_description": "added a new tool...",
	"config_changes": {
		// same as before
	}
}
```

I'm also updating the example agent:

```copilot_change
// action: edit
// config_type: agent
// name: Example agent
{
	"change_description": "updated the instructions...",
	"config_changes": {
		// same as before
	}
}
```

This concludes my changes. Would you like some more help?