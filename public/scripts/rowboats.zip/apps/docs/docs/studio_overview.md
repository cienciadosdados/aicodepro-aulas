# Building Assistants in Studio
This is a guide to building your first assistant on RowBoat Studio, with examples.<br>

Prerequisite:

1. **Open Source Users:** Complete the [open-source installation steps](/oss_installation/) to set up RowBoat Studio.
2. **Hosted App Users:** Sign in to [https://app.rowboatlabs.com/](https://app.rowboatlabs.com/)