# Prompts

- Prompts are reusable pieces of agent instructions in Studio.
- Prompts can be defined once and reused across multiple agents.
- Common examples of prompts are style prompts which indicate brand voice and structured output prompts which specify a format for the agent to provide its output in (e.g. ReAct)