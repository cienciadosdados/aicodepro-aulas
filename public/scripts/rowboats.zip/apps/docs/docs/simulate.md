## Simulate real-world user scenarios
Create a test-bench of real-world scenarios in the simulator.
![Scenarios](img/scenarios.png)

Run the scenarios as simulated chats betweeen a user (role-played) and the assistant, in the playground.
![Simulation](img/simulate.png)