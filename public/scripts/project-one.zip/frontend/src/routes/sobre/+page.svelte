<script>
  // Página Sobre - Contratus AI
</script>

<div class="prose max-w-none">
  <h1>Sobre o Contratus AI</h1>
  
  <div class="card bg-base-100 shadow-xl mb-8">
    <div class="card-body">
      <h2 class="card-title">Nossa Solução</h2>
      <p>
        O Contratus AI é uma plataforma avançada de consulta de contratos que utiliza 
        tecnologia de busca semântica para facilitar o acesso e a compreensão de documentos jurídicos.
      </p>
      <p>
        Nosso sistema permite que você encontre informações específicas em contratos usando linguagem natural, 
        sem precisar conhecer os termos exatos ou navegar manualmente pelos documentos.
      </p>
    </div>
  </div>
  
  <div class="card bg-base-100 shadow-xl mb-8">
    <div class="card-body">
      <h2 class="card-title">Tecnologia</h2>
      <p>Nossa plataforma é construída com tecnologias modernas:</p>
      
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        <div>
          <h3 class="text-lg font-bold">Backend</h3>
          <ul>
            <li>Python com FastAPI</li>
            <li>MongoDB para armazenamento de dados</li>
            <li>Índice vetorial para busca semântica</li>
            <li>Modelo de embeddings Nomic para processamento de linguagem natural</li>
          </ul>
        </div>
        
        <div>
          <h3 class="text-lg font-bold">Frontend</h3>
          <ul>
            <li>SvelteKit para uma interface rápida e responsiva</li>
            <li>Tailwind CSS e DaisyUI para design moderno</li>
            <li>Interface intuitiva e amigável</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  
  <div class="card bg-base-100 shadow-xl">
    <div class="card-body">
      <h2 class="card-title">Como Funciona</h2>
      
      <div class="steps steps-vertical lg:steps-horizontal">
        <div class="step step-primary">
          <div class="text-left ml-2">
            <h3 class="font-bold">Upload</h3>
            <p class="text-sm">Os contratos são processados e armazenados no sistema</p>
          </div>
        </div>
        <div class="step step-primary">
          <div class="text-left ml-2">
            <h3 class="font-bold">Indexação</h3>
            <p class="text-sm">Criamos embeddings e índices vetoriais para busca semântica</p>
          </div>
        </div>
        <div class="step step-primary">
          <div class="text-left ml-2">
            <h3 class="font-bold">Consulta</h3>
            <p class="text-sm">Você faz perguntas em linguagem natural</p>
          </div>
        </div>
        <div class="step step-primary">
          <div class="text-left ml-2">
            <h3 class="font-bold">Resultados</h3>
            <p class="text-sm">O sistema encontra as informações mais relevantes nos contratos</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
