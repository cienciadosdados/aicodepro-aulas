-- Adicionar colunas para suporte a streaming de uploads
-- Data: 2025-10-29

-- Adicionar colunas na tabela knowledge_sources
ALTER TABLE knowledge_sources ADD COLUMN r2_path TEXT;
ALTER TABLE knowledge_sources ADD COLUMN total_chunks INTEGER DEFAULT 0;
ALTER TABLE knowledge_sources ADD COLUMN processed_chunks INTEGER DEFAULT 0;
ALTER TABLE knowledge_sources ADD COLUMN upload_id TEXT;

-- Índice para buscar uploads por upload_id
CREATE INDEX IF NOT EXISTS idx_knowledge_sources_upload_id ON knowledge_sources(upload_id);
