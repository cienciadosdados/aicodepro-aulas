// Query Pinecone para ver conteúdo de um chunk
import { Pinecone } from '@pinecone-database/pinecone';
import OpenAI from 'openai';

const PINECONE_API_KEY = 'pcsk_5g3BdS_Unue25dGhHu8NSWcftfmsZMYvT5zE3BXEXhBaauediuPgJ4SvWJapcKjTsNGm6P';
const OPENAI_API_KEY = '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';
const INDEX_NAME = 'mocha-rag';

async function queryChunk() {
  console.log('🔍 Consultando Pinecone...\n');
  
  const pinecone = new Pinecone({ apiKey: PINECONE_API_KEY });
  const index = pinecone.index(INDEX_NAME);
  
  // Fazer query semântica real
  console.log('Gerando embedding para query...\n');
  
  const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
  const embeddingResponse = await openai.embeddings.create({
    model: 'text-embedding-3-small',
    input: 'AutoAgent'
  });
  
  const queryVector = embeddingResponse.data[0].embedding;
  console.log('Buscando chunks do agent 40, source 38...\n');
  
  const results = await index.namespace('default').query({
    vector: queryVector,
    topK: 3,
    includeMetadata: true,
    filter: {
      agent_id: 40,
      knowledge_source_id: 38
    }
  });
  
  if (results.matches && results.matches.length > 0) {
    console.log(`✅ Encontrados ${results.matches.length} chunks!\n`);
    
    results.matches.forEach((match, i) => {
      console.log(`\n📄 CHUNK ${i + 1}:`);
      console.log(`ID: ${match.id}`);
      console.log(`Score: ${match.score}`);
      console.log(`Chunk Index: ${match.metadata.chunk_index}`);
      console.log(`\n📝 CONTEÚDO (primeiros 500 chars):`);
      console.log(match.metadata.content.substring(0, 500));
      console.log('\n' + '='.repeat(80));
    });
  } else {
    console.log('❌ Nenhum chunk encontrado');
    console.log('Resultado:', JSON.stringify(results, null, 2));
  }
}

queryChunk().catch(console.error);
