# 🔐 Configuração de Secrets - Guia Rápido

## 📋 Secrets Necessárias

### **1. OPENAI_API_KEY**
```bash
echo "sk-proj-SUA_KEY_AQUI" | npx wrangler secret put OPENAI_API_KEY
```

**Onde conseguir:**
- https://platform.openai.com/api-keys
- Criar nova key se necessário

---

### **2. PINECONE_API_KEY**
```bash
echo "pcsk_SUA_KEY_AQUI" | npx wrangler secret put PINECONE_API_KEY
```

**Onde conseguir:**
- https://app.pinecone.io/
- API Keys → Create API Key

---

## ✅ Verificar Secrets Configuradas

```bash
npx wrangler secret list
```

**Deve mostrar:**
```json
[
  { "name": "OPENAI_API_KEY", "type": "secret_text" },
  { "name": "PINECONE_API_KEY", "type": "secret_text" }
]
```

---

## 🔄 Quando Reconfigurar Secrets?

### **Situações que exigem reconfiguração:**

1. **Mudou nome do worker** no wrangler.jsonc
   - Secrets são por worker
   - Precisa configurar no novo worker

2. **Deploy em conta diferente**
   - Cada conta Cloudflare tem suas próprias secrets
   - Configurar na nova conta

3. **Rotação de keys** (segurança)
   - Recomendado a cada 90 dias
   - Gerar novas keys e atualizar

4. **Keys comprometidas**
   - Revogar keys antigas
   - Gerar novas imediatamente

---

## 🚨 Troubleshooting

### **Erro: "OPENAI_API_KEY is missing"**
```bash
# Verificar se existe
npx wrangler secret list

# Se não existir, adicionar
echo "sk-proj-..." | npx wrangler secret put OPENAI_API_KEY
```

### **Erro: "Invalid API key"**
```bash
# Key pode estar expirada ou inválida
# Gerar nova key em:
# - OpenAI: https://platform.openai.com/api-keys
# - Pinecone: https://app.pinecone.io/

# Atualizar secret
echo "nova-key" | npx wrangler secret put OPENAI_API_KEY
```

### **Erro: "Worker not found"**
```bash
# Verificar nome do worker no wrangler.jsonc
# Deve ser: "name": "aihubpro"

# Se mudou nome, configurar secrets no novo worker
```

---

## 📝 Checklist Pós-Deploy

Após cada deploy, verificar:

- [ ] Secrets configuradas: `npx wrangler secret list`
- [ ] Worker funcionando: Testar chat
- [ ] Logs sem erros: `npx wrangler tail`
- [ ] Pinecone conectado: Testar RAG

---

## 💾 Backup das Keys (Seguro)

**NÃO commitar no Git!**

Guardar em:
- ✅ Gerenciador de senhas (1Password, LastPass, etc)
- ✅ Arquivo local criptografado
- ✅ Variáveis de ambiente do sistema
- ❌ Arquivo .env no repositório
- ❌ Código fonte
- ❌ Comentários no código

---

## 🔒 Segurança

### **Boas Práticas:**

1. **Nunca commitar secrets no Git**
   ```bash
   # Adicionar ao .gitignore
   .env
   .secrets
   *.key
   ```

2. **Rotacionar keys regularmente**
   - OpenAI: A cada 90 dias
   - Pinecone: A cada 90 dias

3. **Usar keys diferentes por ambiente**
   - Desenvolvimento: Keys de teste
   - Produção: Keys de produção

4. **Monitorar uso**
   - OpenAI: https://platform.openai.com/usage
   - Pinecone: Dashboard de uso

5. **Revogar keys antigas**
   - Após rotação
   - Se suspeitar de comprometimento

---

## 📊 Custo das APIs

### **OpenAI:**
- Embeddings: ~$0.0001/1K tokens
- Chat: ~$0.002/1K tokens
- Limite recomendado: $50/mês

### **Pinecone:**
- Plano gratuito: 1 index, 100K vectors
- Plano pago: $70/mês (1M vectors)

---

## 🆘 Suporte

**Se continuar com problemas:**

1. Ver logs: `npx wrangler tail --format pretty`
2. Verificar dashboard Cloudflare
3. Testar keys manualmente:
   ```bash
   curl https://api.openai.com/v1/models \
     -H "Authorization: Bearer sk-proj-..."
   ```

---

**Última atualização:** 29/10/2025
