#!/usr/bin/env node

/**
 * Development Setup Script
 * Aut