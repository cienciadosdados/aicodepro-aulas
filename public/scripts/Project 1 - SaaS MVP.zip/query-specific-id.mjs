// Consultar ID específico
import { Pinecone } from '@pinecone-database/pinecone';

const PINECONE_API_KEY = 'pcsk_RvekY_7AzxzrNmswdWmPh8XjG3i4tkSFNgRX48W2omzLRViUBcTUMLZZw3AnVs5JNoSEN';
const INDEX_NAME = 'mocha-rag';
const VECTOR_ID = '10_17_0_1757107233402';

async function queryById() {
  console.log(`🔍 Buscando vector ID: ${VECTOR_ID}\n`);
  
  try {
    const pinecone = new Pinecone({ apiKey: PINECONE_API_KEY });
    const index = pinecone.index(INDEX_NAME);
    
    const result = await index.namespace('default').fetch([VECTOR_ID]);
    
    if (result.records && result.records[VECTOR_ID]) {
      const record = result.records[VECTOR_ID];
      console.log('✅ VECTOR ENCONTRADO!\n');
      console.log('📊 METADATA:');
      console.log(JSON.stringify(record.metadata, null, 2));
      console.log('\n📝 CONTEÚDO:');
      console.log(record.metadata.content);
    } else {
      console.log('❌ Vector não encontrado');
      console.log('Resultado:', JSON.stringify(result, null, 2));
    }
    
  } catch (error) {
    console.error('❌ ERRO:', error.message);
  }
}

queryById();
