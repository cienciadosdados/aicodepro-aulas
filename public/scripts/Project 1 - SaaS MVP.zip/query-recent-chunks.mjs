// Buscar chunks mais recentes do agent 40
import { Pinecone } from '@pinecone-database/pinecone';
import OpenAI from 'openai';

const PINECONE_API_KEY = 'pcsk_RvekY_7AzxzrNmswdWmPh8XjG3i4tkSFNgRX48W2omzLRViUBcTUMLZZw3AnVs5JNoSEN';
const OPENAI_API_KEY = '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';
const INDEX_NAME = 'mocha-rag';

async function queryRecentChunks() {
  console.log('🔍 Buscando chunks mais recentes do agent 40...\n');
  
  try {
    const pinecone = new Pinecone({ apiKey: PINECONE_API_KEY });
    const index = pinecone.index(INDEX_NAME);
    const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
    
    // Gerar embedding para busca
    console.log('Gerando embedding...');
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: 'cronograma de estudos gestor IA'
    });
    const queryVector = embeddingResponse.data[0].embedding;
    
    // Buscar chunks do agent 40
    console.log('Buscando no Pinecone...\n');
    const results = await index.namespace('default').query({
      vector: queryVector,
      topK: 5,
      includeMetadata: true,
      filter: {
        agent_id: 41,
        knowledge_source_id: 40
      }
    });
    
    if (results.matches && results.matches.length > 0) {
      console.log(`✅ Encontrados ${results.matches.length} chunks do agent 40!\n`);
      
      results.matches.forEach((match, i) => {
        console.log(`📄 CHUNK ${i + 1}:`);
        console.log(`   ID: ${match.id}`);
        console.log(`   Score: ${match.score.toFixed(4)}`);
        console.log(`   Agent ID: ${match.metadata.agent_id}`);
        console.log(`   Source ID: ${match.metadata.knowledge_source_id}`);
        console.log(`   Chunk Index: ${match.metadata.chunk_index}`);
        console.log(`   Created: ${match.metadata.created_at}`);
        console.log(`   Content (100 chars): ${match.metadata.content.substring(0, 100)}...`);
        console.log('');
      });
    } else {
      console.log('❌ Nenhum chunk encontrado para agent 40');
      console.log('\nTentando buscar SEM filtro...\n');
      
      const allResults = await index.namespace('default').query({
        vector: queryVector,
        topK: 3,
        includeMetadata: true
      });
      
      console.log(`Encontrados ${allResults.matches.length} chunks no total:`);
      allResults.matches.forEach((match, i) => {
        console.log(`${i + 1}. Agent ${match.metadata.agent_id}, Source ${match.metadata.knowledge_source_id}, Score: ${match.score.toFixed(4)}`);
      });
    }
    
  } catch (error) {
    console.error('❌ ERRO:', error.message);
    console.error(error.stack);
  }
}

queryRecentChunks();
