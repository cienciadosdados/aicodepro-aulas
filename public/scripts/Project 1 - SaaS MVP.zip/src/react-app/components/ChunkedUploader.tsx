import React, { useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react';

const CHUNK_SIZE = 5 * 1024 * 1024; // 5 MB

interface ChunkedUploaderProps {
  agentId: string;
  onUploadComplete: (sourceId: number) => void;
  onClose: () => void;
}

export const ChunkedUploader: React.FC<ChunkedUploaderProps> = ({
  agentId,
  onUploadComplete,
  onClose
}) => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentChunk, setCurrentChunk] = useState(0);
  const [totalChunks, setTotalChunks] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const uploadFile = async (file: File) => {
    setUploading(true);
    setProgress(0);
    setError(null);
    
    const uploadId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const chunks = Math.ceil(file.size / CHUNK_SIZE);
    setTotalChunks(chunks);
    
    console.log(`🚀 Starting chunked upload: ${file.name} (${chunks} chunks of ${CHUNK_SIZE / 1024 / 1024} MB)`);
    
    try {
      for (let chunkIndex = 0; chunkIndex < chunks; chunkIndex++) {
        const start = chunkIndex * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, file.size);
        const chunk = file.slice(start, end);
        
        setCurrentChunk(chunkIndex + 1);
        
        const formData = new FormData();
        formData.append('chunk', chunk);
        formData.append('chunk_index', chunkIndex.toString());
        formData.append('total_chunks', chunks.toString());
        formData.append('upload_id', uploadId);
        formData.append('file_name', file.name);
        
        const user = JSON.parse(localStorage.getItem('auth_user') || '{}');
        
        const response = await fetch(`/api/agents/${agentId}/upload-chunk`, {
          method: 'POST',
          headers: {
            'X-User-Data': JSON.stringify(user)
          },
          body: formData
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `Chunk ${chunkIndex} upload failed`);
        }
        
        const result = await response.json();
        
        // Atualizar progresso
        setProgress(Math.floor(((chunkIndex + 1) / chunks) * 100));
        
        console.log(`✅ Chunk ${chunkIndex + 1}/${chunks} uploaded`);
        
        if (result.complete) {
          console.log(`🎉 Upload complete! Source ID: ${result.sourceId}`);
          onUploadComplete(result.sourceId);
          setTimeout(() => {
            onClose();
          }, 2000);
          break;
        }
      }
      
    } catch (err) {
      console.error('Upload failed:', err);
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleUpload = () => {
    if (selectedFile) {
      uploadFile(selectedFile);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl p-6 max-w-md w-full mx-4 border border-white/10">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Upload PDF Grande (Streaming)
          </h3>
          <button
            onClick={onClose}
            disabled={uploading}
            className="text-white/60 hover:text-white disabled:opacity-50"
          >
            ✕
          </button>
        </div>

        {!selectedFile ? (
          <div className="border-2 border-dashed border-white/20 rounded-lg p-8 text-center">
            <Upload className="w-12 h-12 text-white/40 mx-auto mb-3" />
            <p className="text-white/60 mb-4">
              Selecione um PDF grande para upload
            </p>
            <input
              type="file"
              accept=".pdf"
              onChange={handleFileSelect}
              className="hidden"
              id="chunked-file-upload"
            />
            <label
              htmlFor="chunked-file-upload"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg cursor-pointer inline-block transition-colors"
            >
              Selecionar PDF
            </label>
            <p className="text-xs text-white/50 mt-3">
              Suporta PDFs de até 500 MB
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-white/5 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-blue-400 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">
                    {selectedFile.name}
                  </p>
                  <p className="text-white/60 text-sm">
                    {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
                  </p>
                </div>
              </div>
            </div>

            {uploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-white/80">
                  <span>Enviando chunk {currentChunk} de {totalChunks}</span>
                  <span>{progress}%</span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-blue-600 h-full transition-all duration-300 rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-xs text-white/50 text-center">
                  Processamento continuará em background após upload
                </p>
              </div>
            )}

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-red-400 text-sm font-medium">Erro no upload</p>
                  <p className="text-red-400/80 text-xs mt-1">{error}</p>
                </div>
              </div>
            )}

            {progress === 100 && !error && (
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <p className="text-green-400 text-sm">
                  Upload completo! Processando documento...
                </p>
              </div>
            )}

            <div className="flex gap-3">
              {!uploading && progress < 100 && (
                <>
                  <button
                    onClick={() => setSelectedFile(null)}
                    className="flex-1 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={handleUpload}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors font-medium"
                  >
                    Iniciar Upload
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
