import { Env } from './index';
import { PineconeRAGProcessor } from './pinecone-rag';

export class StreamingPDFProcessor {
  constructor(
    private env: Env,
    private openaiKey: string,
    private pineconeKey: string,
    private indexName: string
  ) {}

  async processStreamingPDF(
    sourceId: number,
    agentId: number,
    uploadId: string,
    totalChunks: number
  ): Promise<{ success: boolean; total_text_chunks: number }> {
    console.log(`🌊 [STREAMING] Starting streaming processing for source ${sourceId}`);
    
    try {
      // Atualizar status
      await this.env.DB.prepare(`
        UPDATE knowledge_sources 
        SET status = 'processing', 
            progress_percentage = 0,
            progress_message = 'Starting streaming processing...'
        WHERE id = ?
      `).bind(sourceId).run();
      
      // PASSO 1: Baixar e JUNTAR todos os chunks primeiro
      console.log(`📥 [STREAMING] Downloading ${totalChunks} chunks from R2...`);
      const chunkBuffers: ArrayBuffer[] = [];
      
      // Download em paralelo para ser mais rápido (máximo 5 por vez)
      const batchSize = 5;
      for (let i = 0; i < totalChunks; i += batchSize) {
        const batch = [];
        for (let j = i; j < Math.min(i + batchSize, totalChunks); j++) {
          const chunkKey = `uploads/${uploadId}/chunk_${j.toString().padStart(4, '0')}.bin`;
          batch.push(
            this.env.UPLOADS.get(chunkKey).then((obj: any) => {
              if (!obj) throw new Error(`Chunk ${j} not found: ${chunkKey}`);
              return obj.arrayBuffer();
            })
          );
        }
        
        const batchBuffers = await Promise.all(batch);
        chunkBuffers.push(...batchBuffers);
        
        console.log(`📦 [STREAMING] Downloaded ${chunkBuffers.length}/${totalChunks} chunks`);
      }
      
      // Update progress apenas uma vez
      await this.env.DB.prepare(`
        UPDATE knowledge_sources 
        SET progress_percentage = 30,
            progress_message = 'All chunks downloaded, joining PDF...'
        WHERE id = ?
      `).bind(sourceId).run();
      
      console.log(`✅ [STREAMING] All chunks downloaded, joining into single PDF...`);
      
      // PASSO 2: Juntar chunks em um único ArrayBuffer
      const totalSize = chunkBuffers.reduce((sum, buf) => sum + buf.byteLength, 0);
      
      // Validar tamanho para garantir processamento em 60s
      const maxSizeMB = 50; // Reduzido para garantir processamento dentro do limite
      const maxSizeBytes = maxSizeMB * 1024 * 1024;
      if (totalSize > maxSizeBytes) {
        throw new Error(
          `PDF too large for processing: ${(totalSize / (1024 * 1024)).toFixed(2)} MB. ` +
          `Maximum supported: ${maxSizeMB} MB (Cloudflare 60s limit). Please split the PDF into smaller files.`
        );
      }
      
      const fullPdfBuffer = new Uint8Array(totalSize);
      let offset = 0;
      
      for (const buffer of chunkBuffers) {
        fullPdfBuffer.set(new Uint8Array(buffer), offset);
        offset += buffer.byteLength;
      }
      
      console.log(`✅ [STREAMING] PDF joined: ${totalSize} bytes`);
      
      // Atualizar progresso
      await this.env.DB.prepare(`
        UPDATE knowledge_sources 
        SET progress_percentage = 40,
            progress_message = 'PDF joined, extracting text...'
        WHERE id = ?
      `).bind(sourceId).run();
      
      // PASSO 3: Extrair texto do PDF COMPLETO
      console.log(`📄 [STREAMING] Extracting text from complete PDF...`);
      let fullText: string;
      
      try {
        const { extractText, getDocumentProxy } = await import('unpdf');
        const document = await getDocumentProxy(fullPdfBuffer);
        const { text } = await extractText(document, { mergePages: true });
        fullText = text.replace(/\s+/g, ' ').trim();
        
        if (!fullText || fullText.length < 100) {
          throw new Error('PDF text extraction returned empty or very short content');
        }
        
        console.log(`✅ [STREAMING] Text extracted: ${fullText.length} characters`);
      } catch (unpdfError) {
        console.error('❌ [STREAMING] unpdf failed:', unpdfError);
        throw new Error(
          `Failed to extract text from PDF: ${unpdfError instanceof Error ? unpdfError.message : 'Unknown error'}. ` +
          `The PDF may be corrupted, scanned (requires OCR), or use unsupported features. ` +
          `Please try a different PDF or convert it to a text-based format.`
        );
      }
      
      // PASSO 4: Limpar chunks do R2
      console.log(`🗑️ [STREAMING] Cleaning up R2 chunks...`);
      for (let i = 0; i < totalChunks; i++) {
        const chunkKey = `uploads/${uploadId}/chunk_${i.toString().padStart(4, '0')}.bin`;
        await this.env.UPLOADS.delete(chunkKey);
      }
      console.log(`✅ [STREAMING] R2 cleanup complete`);
      
      // Salvar texto completo no D1
      await this.env.DB.prepare(`
        UPDATE knowledge_sources 
        SET content = ?,
            progress_percentage = 60,
            progress_message = 'Text extraction complete, starting chunking...'
        WHERE id = ?
      `).bind(fullText, sourceId).run();
      
      // Verificar se content foi salvo corretamente
      const verification = await this.env.DB.prepare(`
        SELECT LENGTH(content) as content_length FROM knowledge_sources WHERE id = ?
      `).bind(sourceId).first();
      
      if (!verification || !verification.content_length) {
        throw new Error('Failed to save content to database - verification failed');
      }
      
      console.log(`✅ [STREAMING] Content saved to D1: ${verification.content_length} characters`);
      
      // Agora processar com pipeline RAG normal
      const ragProcessor = new PineconeRAGProcessor(
        this.openaiKey,
        this.pineconeKey,
        this.indexName
      );
      
      // Buscar settings do agent
      const settings = await this.env.DB.prepare(`
        SELECT chunk_size, chunk_overlap, chunking_strategy
        FROM agent_knowledge_settings
        WHERE agent_id = ?
      `).bind(agentId).first();
      
      const result = await ragProcessor.processKnowledgeSource(
        sourceId,
        agentId,
        {
          type: 'pdf',
          name: `Streaming upload ${uploadId}`,
          content: fullText
        },
        {
          chunk_size: settings?.chunk_size || 2000,
          chunk_overlap: settings?.chunk_overlap || 400,
          chunking_strategy: settings?.chunking_strategy || 'recursive'
        }
      );
      
      console.log(`🎉 [STREAMING] Processing complete: ${result.chunks_count} chunks created`);
      
      // Atualizar status final para completed
      await this.env.DB.prepare(`
        UPDATE knowledge_sources 
        SET status = 'completed',
            progress_percentage = 100,
            progress_message = 'Processing complete'
        WHERE id = ?
      `).bind(sourceId).run();
      
      console.log(`✅ [STREAMING] Status updated to completed`);
      
      return {
        success: true,
        total_text_chunks: result.chunks_count
      };
      
    } catch (error) {
      console.error(`❌ [STREAMING] Processing failed for source ${sourceId}:`, error);
      
      await this.env.DB.prepare(`
        UPDATE knowledge_sources 
        SET status = 'failed',
            progress_message = ?
        WHERE id = ?
      `).bind(
        `Streaming processing failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
        sourceId
      ).run();
      
      throw error;
    }
  }
}
