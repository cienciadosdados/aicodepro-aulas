# 🔍 Fuzzy Search no MongoDB Atlas - Voice Agent

## 🎯 O Que É Fuzzy Search?

**Fuzzy Search** (busca difusa) é uma técnica que encontra resultados **mesmo com erros de digitação, variações ou aproximações** do termo buscado.

### **Exemplo Prático:**

```
Busca: "Eduardo Roxa"  ❌ (errado)
Encontra: "Eduardo Rocha" ✅ (correto)

Busca: "Edurdo"  ❌ (faltou 'a')
Encontra: "Eduardo" ✅

Busca: "Edurado"  ❌ (ordem trocada)
Encontra: "Eduardo" ✅
```

---

## 📍 Onde Está Implementado?

### **1. Setup do Índice** (`setup_database.py` - linhas 126-147)

```python
search_index_model = SearchIndexModel(
    definition={
        "mappings": {
            "dynamic": True  # Indexa todos os campos automaticamente
        }
    },
    name="default"
)

result = db.bookings.create_search_index(model=search_index_model)
```

**O que faz:**
- Cria um **Atlas Search Index** na collection `bookings`
- `dynamic: True` = indexa todos os campos (name, payment_method, date, etc.)
- Nome do índice: `"default"`

---

### **2. Uso na Tool** (`tools.py` - linhas 123-127)

```python
@tool
def get_booking_by_name(name: str) -> Dict[str, Any]:
    """Get a booking by name."""
    
    booking = list(
        bookings_collection.aggregate([
            {
                "$search": {
                    "text": {
                        "query": name,      # Nome buscado (pode ter erro)
                        "path": "name",     # Campo onde buscar
                        "fuzzy": {}         # 🔥 Ativa fuzzy search!
                    }
                }
            }
        ])
    )
```

---

## 🧠 Como Funciona o Fuzzy Search?

### **Algoritmo: Levenshtein Distance**

Mede quantas **edições** são necessárias para transformar uma palavra em outra:

```
"Eduardo" → "Edurdo"
Operações: 1 (trocar 'a' e 'r' de lugar)
Distância: 1 ✅ (aceito)

"Eduardo" → "João"
Operações: 7 (trocar todas as letras)
Distância: 7 ❌ (muito diferente, rejeitado)
```

### **Parâmetros do Fuzzy (MongoDB Atlas)**

```python
"fuzzy": {
    "maxEdits": 2,        # Máximo de edições permitidas (padrão: 2)
    "prefixLength": 0,    # Quantos caracteres iniciais devem ser exatos
    "maxExpansions": 50   # Máximo de termos similares a considerar
}
```

No nosso código, usamos `"fuzzy": {}` = **valores padrão** (maxEdits=2).

---

## 🎭 Casos de Uso no Voice Agent

### **Cenário 1: Transcrição Errada do Whisper**

```
👤 Usuário fala: "Eduardo Rocha"
🎤 Whisper transcreve: "Eduardo Roxa" (erro comum em português)
🔍 Fuzzy Search encontra: "Eduardo Rocha" ✅
```

### **Cenário 2: Sotaque ou Pronúncia**

```
👤 Usuário fala: "Rafaela" (com sotaque)
🎤 Whisper transcreve: "Rafaéla" ou "Rafaella"
🔍 Fuzzy Search encontra: "Rafaela" ✅
```

### **Cenário 3: Nomes Compostos**

```
👤 Usuário fala: "João Pedro"
🎤 Whisper transcreve: "João Pedru"
🔍 Fuzzy Search encontra: "João Pedro" ✅
```

---

## 📊 Comparação: Com vs Sem Fuzzy Search

| Busca | Sem Fuzzy | Com Fuzzy |
|-------|-----------|-----------|
| "Eduardo Rocha" | ✅ Encontra | ✅ Encontra |
| "Eduardo Roxa" | ❌ Não encontra | ✅ Encontra |
| "Edurdo Rocha" | ❌ Não encontra | ✅ Encontra |
| "Eduardo" | ❌ Não encontra (parcial) | ✅ Encontra |
| "João" (buscando "Eduardo") | ❌ Não encontra | ❌ Não encontra (muito diferente) |

---

## 🔧 Configuração Avançada (Opcional)

Se quiser ajustar a sensibilidade do fuzzy search:

```python
# Mais tolerante (aceita até 2 erros)
"fuzzy": {
    "maxEdits": 2,
    "prefixLength": 0
}

# Menos tolerante (aceita apenas 1 erro)
"fuzzy": {
    "maxEdits": 1,
    "prefixLength": 0
}

# Exige que as 3 primeiras letras sejam exatas
"fuzzy": {
    "maxEdits": 2,
    "prefixLength": 3  # "Edu" deve ser exato
}
```

---

## 🎯 Por Que É Importante para Voice Agents?

### **1. Transcrição de Voz Não É Perfeita**
- Whisper pode errar nomes próprios
- Sotaques e ruídos afetam a transcrição
- Fuzzy search compensa esses erros

### **2. Experiência do Usuário**
```
❌ Sem Fuzzy:
👤 "Quero ver minha reserva, Eduardo Rocha"
🤖 "Desculpe, não encontrei nenhuma reserva para Eduardo Roxa"
😡 Usuário frustrado

✅ Com Fuzzy:
👤 "Quero ver minha reserva, Eduardo Rocha"
🤖 "Encontrei sua reserva, Eduardo Rocha! ..."
😊 Usuário satisfeito
```

### **3. Robustez**
- Sistema funciona mesmo com erros de transcrição
- Reduz necessidade de correções manuais
- Aumenta taxa de sucesso das buscas

---

## 🔍 Diferença: Fuzzy Search vs Vector Search

| Aspecto | Fuzzy Search | Vector Search |
|---------|--------------|---------------|
| **Tipo** | Busca textual | Busca semântica |
| **Uso** | Nomes, IDs, textos exatos | Descrições, conceitos |
| **Erro** | Tolera erros de digitação | Entende sinônimos |
| **Exemplo** | "Eduardo" → "Edurdo" | "casa na praia" → "imóvel beira-mar" |
| **Campo** | `bookings.name` | `rentals.description` |
| **Índice** | Atlas Search Index | Vector Search Index |

---

## 📝 Resumo

### **Fuzzy Search no Sistema:**

1. **Onde:** Collection `bookings`, campo `name`
2. **Quando:** Tool `get_booking_by_name` é chamada
3. **Como:** MongoDB Atlas Search com `fuzzy: {}`
4. **Por quê:** Compensar erros de transcrição de voz
5. **Resultado:** Busca mais robusta e tolerante a erros

### **Fluxo Completo:**

```
👤 Usuário fala → 🎤 Whisper transcreve (com erro) → 
🧠 GPT-4o chama get_booking_by_name → 
🔍 MongoDB Fuzzy Search encontra (mesmo com erro) → 
🤖 Retorna reserva correta
```

---

## 🚀 Melhorias Futuras

1. **Ajustar maxEdits** baseado no tamanho do nome
2. **Adicionar score threshold** para rejeitar matches muito ruins
3. **Combinar com phonetic search** para sotaques fortes
4. **Implementar autocomplete** para sugestões em tempo real

---

## 📚 Referências

- [MongoDB Atlas Search - Fuzzy](https://www.mongodb.com/docs/atlas/atlas-search/text/#fuzzy-examples)
- [Levenshtein Distance](https://en.wikipedia.org/wiki/Levenshtein_distance)
- [OpenAI Whisper Limitations](https://platform.openai.com/docs/guides/speech-to-text)
