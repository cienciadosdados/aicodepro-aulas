import os
from dotenv import load_dotenv

print("=== Verificação de Variáveis de Ambiente ===\n")

# 1. Verificar se existe variável GLOBAL (antes do load_dotenv)
global_key = os.environ.get('OPENAI_API_KEY')
if global_key:
    print(f"✅ OPENAI_API_KEY GLOBAL encontrada:")
    print(f"   {global_key[:20]}...{global_key[-10:]}\n")
else:
    print("❌ Nenhuma OPENAI_API_KEY GLOBAL encontrada\n")

# 2. Carregar do .env (como faz o app.py)
load_dotenv(override=True)

# 3. Verificar após load_dotenv
dotenv_key = os.environ.get('OPENAI_API_KEY')
if dotenv_key:
    print(f"✅ OPENAI_API_KEY após load_dotenv:")
    print(f"   {dotenv_key[:20]}...{dotenv_key[-10:]}\n")
else:
    print("❌ Nenhuma OPENAI_API_KEY após load_dotenv\n")

# 4. Comparar
if global_key and dotenv_key:
    if global_key == dotenv_key:
        print("✅ As keys são IGUAIS (usando a mesma)")
    else:
        print("⚠️  As keys são DIFERENTES!")
        print("   A aplicação usará a do .env (override=True)")
elif dotenv_key and not global_key:
    print("✅ Usando apenas a key do .env (sem global)")
elif global_key and not dotenv_key:
    print("⚠️  Usando apenas a key GLOBAL (problema no .env!)")
else:
    print("❌ NENHUMA key encontrada!")

# 5. Verificar MongoDB também
print("\n=== MongoDB URI ===")
mongo_uri = os.environ.get('MONGODB_ATLAS_URI')
if mongo_uri:
    # Extrair apenas o host para não expor senha
    if '@' in mongo_uri:
        host_part = mongo_uri.split('@')[1].split('/')[0]
        print(f"✅ MongoDB URI encontrada")
        print(f"   Host: {host_part}")
    else:
        print(f"✅ MongoDB URI encontrada (formato não padrão)")
else:
    print("❌ MONGODB_ATLAS_URI não encontrada")
